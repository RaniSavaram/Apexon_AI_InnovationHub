import re
from datetime import datetime
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from tools.database_tools import get_size_category


def _xml_safe_text(value):
    text = str(value or "")
    return re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", text)


def hex_to_rgb(hex_str):
    hex_str = hex_str.lstrip('#')
    return RGBColor(int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))


def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    """Set padding/margins for a table cell in twentieths of a point (dxa)."""
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('w:top', top), ('w:bottom', bottom), ('w:left', left), ('w:right', right)]:
        node = OxmlElement(m)
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)


def set_cell_shading(cell, hex_color):
    """Set background color of a table cell."""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)


def set_run_font(run, name="Aptos", size_pt=12, bold=False, italic=False, color_hex=None):
    """Force font formatting and ensure compatibility in Word via XML settings."""
    run.font.name = name
    if size_pt:
        run.font.size = Pt(size_pt)
    run.font.bold = bold
    run.font.italic = italic
    if color_hex:
        run.font.color.rgb = hex_to_rgb(color_hex)
    
    # ASCII and high-ANSI font tags
    rPr = run._r.get_or_add_rPr()
    rFonts = OxmlElement('w:rFonts')
    rFonts.set(qn('w:ascii'), name)
    rFonts.set(qn('w:hAnsi'), name)
    rPr.append(rFonts)


def populate_and_style_cell(cell, text, is_header=False, is_first_col=False, header_bg="156082", first_col_bg="EAF1F5"):
    """Populates a cell with text and applies appropriate styling parameters, ensuring no empty cells."""
    raw_val = "" if text is None else str(text).strip()
    if not raw_val or raw_val == "-" or raw_val == "MANAGED -" or raw_val.lower() == "none -" or raw_val.lower() == "managed -":
        clean_text = "-" if is_header else "None"
    else:
        clean_text = raw_val

    p = cell.paragraphs[0]
    p.text = ""
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    
    run = p.add_run(clean_text)
    
    if is_header:
        set_cell_shading(cell, header_bg)
        set_run_font(run, name="Aptos", size_pt=10, bold=True, color_hex="FFFFFF")
    elif is_first_col and first_col_bg:
        set_cell_shading(cell, first_col_bg)
        set_run_font(run, name="Aptos", size_pt=10, bold=True, color_hex="0F4761")
    else:
        set_run_font(run, name="Aptos", size_pt=10, bold=False, color_hex="333333")
        
    set_cell_margins(cell, top=100, bottom=100, left=120, right=120)


def add_custom_heading(doc, text, level, space_before=Pt(8), space_after=Pt(3)):
    """Creates a stylized heading matching the theme."""
    style_name = f'Heading {level}'
    p = doc.add_paragraph(style=style_name)
    p.paragraph_format.space_before = space_before
    p.paragraph_format.space_after = space_after
    
    if level == 1:
        run = p.add_run(text)
        set_run_font(run, name="Aptos", size_pt=20, bold=True, color_hex="0F4761")
    elif level == 2:
        run = p.add_run(text)
        set_run_font(run, name="Aptos", size_pt=16, bold=True, color_hex="0F4761")
    else:
        run = p.add_run(text)
        set_run_font(run, name="Aptos", size_pt=12, bold=True, color_hex="0F4761")
    return p


def add_custom_paragraph(doc, text="", space_after=Pt(4), is_bullet=False):
    """Creates a stylized paragraph matching the theme."""
    p = doc.add_paragraph(style='List Bullet' if is_bullet else 'Normal')
    p.paragraph_format.space_after = space_after
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    if text:
        run = p.add_run(text)
        set_run_font(run, name="Aptos", size_pt=12)
    return p


def add_bold_label_paragraph(doc, text):
    """Creates a paragraph with bold label inline, matching section markers."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = p.add_run(text)
    set_run_font(run, name="Aptos", size_pt=12, bold=True, color_hex="000000")
    return p


def parse_table_summary_string(summary_text):
    """Parses a structured text summary from TableSummarizerAgent into a dictionary."""
    data = {
        "table_name": "Unknown",
        "schema_name": "dbo",
        "row_count": "0",
        "size_mb": "0",
        "size_category": "Small",
        "table_type": "Base Table",
        "total_columns": "0",
        "columns": [],
        "primary_keys": "None",
        "foreign_keys": "None",
        "referenced_tables": "None",
        "dependent_tables": "None",
        "related_views": "None",
        "related_procedures": "None",
        "summary": ""
    }

    lines = (summary_text or "").split("\n")
    in_columns = False
    summary_lines = []
    in_summary = False
    
    for line in lines:
        line_stripped = line.strip()
        if not line_stripped:
            continue
            
        if line_stripped.startswith("Table Name:"):
            data["table_name"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("Schema:"):
            data["schema_name"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
            
        if line_stripped.startswith("- Row Count:"):
            data["row_count"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("- Size (MB):"):
            data["size_mb"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("- Size Category:"):
            data["size_category"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("- Table Type:"):
            data["table_type"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
            
        if line_stripped.startswith("- Total Columns:"):
            data["total_columns"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("- Columns:"):
            in_columns = True
            in_summary = False
            continue
        if line_stripped.startswith("- Primary Keys:"):
            data["primary_keys"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("- Foreign Keys:"):
            data["foreign_keys"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
            
        if line_stripped.startswith("- Referenced Tables:"):
            data["referenced_tables"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("- Dependent Tables:"):
            data["dependent_tables"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
            
        if line_stripped.startswith("- Related Views:"):
            data["related_views"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
        if line_stripped.startswith("- Related Stored Procedures:"):
            data["related_procedures"] = line_stripped.split(":", 1)[1].strip()
            in_columns = False
            in_summary = False
            continue
            
        if line_stripped.startswith("Summary:"):
            in_summary = True
            in_columns = False
            continue
            
        if in_columns and (line_stripped.startswith("•") or line_stripped.startswith("*") or line_stripped.startswith("-")):
            col_part = line_stripped.lstrip("•*-").strip()
            if "(" in col_part and ")" in col_part:
                name_part, type_part = col_part.split("(", 1)
                col_name = name_part.strip()
                col_type = type_part.rsplit(")", 1)[0].strip()
            else:
                col_name = col_part.strip()
                col_type = "string"
            data["columns"].append((col_name, col_type))
            continue
            
        if in_summary:
            summary_lines.append(line_stripped)
            continue
            
    data["summary"] = " ".join(summary_lines)
    return data


def _parse_summary_lines(summary_text, field_prefixes, multiline_fields=()):
    """
    Shared line-by-line parser for the View/Function/Volume agent output
    formats - a lighter-weight sibling of parse_table_summary_string() for
    object types that don't have tables' Structure/Dependencies/Usage
    sections. field_prefixes maps a "Label:" prefix to the output dict key;
    multiline_fields are keys (e.g. "definition") whose value can span
    multiple lines up to the next recognized prefix or "Summary:".
    """
    data = {key: "" for key in field_prefixes.values()}
    data["columns"] = []
    data["summary"] = ""

    lines = (summary_text or "").split("\n")
    active_multiline = None
    in_columns = False
    in_summary = False
    summary_lines = []
    multiline_buffers = {key: [] for key in multiline_fields}

    for line in lines:
        line_stripped = line.strip()
        if not line_stripped:
            continue

        matched_prefix = False
        for prefix, key in field_prefixes.items():
            if line_stripped.startswith(prefix):
                value = line_stripped.split(":", 1)[1].strip()
                if key in multiline_fields:
                    active_multiline = key
                    if value:
                        multiline_buffers[key].append(value)
                else:
                    data[key] = value
                    active_multiline = None
                in_columns = False
                in_summary = False
                matched_prefix = True
                break
        if matched_prefix:
            continue

        if line_stripped.startswith("- Columns:") or line_stripped == "Columns:":
            in_columns = True
            in_summary = False
            active_multiline = None
            continue

        if line_stripped.startswith("Summary:"):
            in_summary = True
            in_columns = False
            active_multiline = None
            continue

        if in_columns and (line_stripped.startswith("•") or line_stripped.startswith("*") or line_stripped.startswith("-")):
            col_part = line_stripped.lstrip("•*-").strip()
            if "(" in col_part and ")" in col_part:
                name_part, type_part = col_part.split("(", 1)
                col_name = name_part.strip()
                col_type = type_part.rsplit(")", 1)[0].strip()
            else:
                col_name = col_part.strip()
                col_type = "string"
            data["columns"].append((col_name, col_type))
            continue

        if in_summary:
            summary_lines.append(line_stripped)
            continue

        if active_multiline:
            multiline_buffers[active_multiline].append(line_stripped)

    for key in multiline_fields:
        data[key] = "\n".join(multiline_buffers[key]).strip()
    data["summary"] = " ".join(summary_lines)
    return data


def parse_view_summary_string(summary_text):
    """Parses a VIEW summary produced by TableSummarizerAgent (see its
    get_view_metadata output format) into a dict."""
    data = _parse_summary_lines(
        summary_text,
        field_prefixes={
            "View Name:": "view_name",
            "Schema:": "schema_name",
            "- Total Columns:": "total_columns",
            "Definition:": "definition",
        },
        multiline_fields=("definition",),
    )
    if not data.get("view_name"):
        data["view_name"] = "Unknown"
    if not data.get("schema_name"):
        data["schema_name"] = "dbo"
    if not data.get("definition"):
        data["definition"] = "Not available"
    return data


def parse_function_summary_string(summary_text):
    """Parses a FUNCTION summary produced by TableSummarizerAgent (see its
    get_function_metadata output format) into a dict."""
    data = _parse_summary_lines(
        summary_text,
        field_prefixes={
            "Function Name:": "function_name",
            "Schema:": "schema_name",
            "Return Type:": "return_type",
        },
    )
    if not data.get("function_name"):
        data["function_name"] = "Unknown"
    if not data.get("schema_name"):
        data["schema_name"] = "dbo"
    return data


def parse_procedure_summary_string(summary_text):
    """Parses a STORED PROCEDURE summary produced by TableSummarizerAgent
    (see its get_procedure_metadata output format) into a dict."""
    data = _parse_summary_lines(
        summary_text,
        field_prefixes={
            "Procedure Name:": "procedure_name",
            "Schema:": "schema_name",
        },
    )
    if not data.get("procedure_name"):
        data["procedure_name"] = "Unknown"
    if not data.get("schema_name"):
        data["schema_name"] = "dbo"
    return data


def parse_volume_summary_string(summary_text):
    """Parses a VOLUME summary produced by TableSummarizerAgent (see its
    get_volume_metadata output format) into a dict."""
    data = _parse_summary_lines(
        summary_text,
        field_prefixes={
            "Volume Name:": "volume_name",
            "Schema:": "schema_name",
            "Volume Type:": "volume_type",
            "Storage Location:": "storage_location",
        },
    )
    if not data.get("volume_name"):
        data["volume_name"] = "Unknown"
    if not data.get("schema_name"):
        data["schema_name"] = "dbo"
    return data


def parse_relationship(row):
    """Formats relationship string dynamically from foreign key dependency row."""
    parent = row["parent_table"]
    ref = row["referenced_table"]
    fk = row["fk_name"]
    
    col = fk.replace("FK_", "").replace("fk_", "").replace(parent, "").replace(ref, "").strip("_")
    if not col or len(col) > 30:
        if ref.lower() == "auth_group":
            col = "group_id"
        elif ref.lower() == "auth_permission":
            col = "permission_id"
        elif ref.lower() == "auth_user":
            col = "user_id"
        elif ref.lower() == "de_department":
            col = "DepartmentID"
        else:
            col = "id"
            
    ref_col = "id"
    if ref.lower() == "de_department":
        ref_col = "DepartmentID"
    elif ref.lower() == "departments":
        ref_col = "dept_no"
        
    return f"{parent}({col}) references {ref}({ref_col})"


def get_source_display_name(source_hint):
    if not source_hint:
        return "Database"
    
    sh_low = source_hint.strip().lower()
    if sh_low in ("sqlserver", "sql server"):
        return "SQL Server"
    elif sh_low == "synapse":
        return "Azure Synapse"
    elif sh_low == "snowflake":
        return "Snowflake"
    elif sh_low == "databricks":
        return "Databricks"
    elif sh_low in ("dynamics365", "dynamics 365", "d365"):
        return "Dynamics 365"
    elif sh_low == "sqlite":
        return "SQLite"
    elif sh_low == "oracle":
        return "Oracle"
    elif sh_low == "mysql":
        return "MySQL"
    elif sh_low in ("postgres", "postgresql"):
        return "PostgreSQL"
    elif sh_low == "sap":
        return "SAP"
    else:
        return source_hint.title()


def parse_agent_sections(agent_writeups):
    sections = {}
    if not agent_writeups:
        return sections
    
    current_section = None
    section_lines = []
    
    lines = str(agent_writeups).split("\n")
    for line in lines:
        match = re.search(r"SECTION\s+(\d+)", line, re.IGNORECASE)
        if match:
            if current_section is not None:
                sections[current_section] = "\n".join(section_lines).strip()
            current_section = int(match.group(1))
            section_lines = []
        else:
            if current_section is not None:
                section_lines.append(line)
                
    if current_section is not None:
        sections[current_section] = "\n".join(section_lines).strip()
        
    return sections


def parse_table_layers_from_agent(sections_text, tables_df):
    mapping = {}
    if not sections_text or tables_df is None:
        return mapping
    
    lines = sections_text.split("\n")
    for _, row in tables_df.iterrows():
        t_name = row["table_name"]
        for line in lines:
            if t_name.lower() in line.lower():
                layer = None
                if "gold" in line.lower():
                    layer = "Gold"
                elif "silver" in line.lower():
                    layer = "Silver"
                elif "bronze" in line.lower():
                    layer = "Bronze"
                
                if layer:
                    reason = "Categorized based on dependencies and naming"
                    parts = re.split(r"[-–—:|]", line)
                    if len(parts) > 1:
                        for idx, part in enumerate(parts):
                            if layer.lower() in part.lower() and idx + 1 < len(parts):
                                reason = parts[idx + 1].strip()
                                break
                    reason = re.sub(r"\*\*|__", "", reason)
                    mapping[t_name] = (layer, reason)
                    break
    return mapping


def add_agent_writeup_section(doc, sections, section_num):
    writeup = sections.get(section_num)
    if not writeup:
        return
    
    lines = writeup.split("\n")
    for line in lines:
        line_stripped = line.strip()
        if not line_stripped:
            continue
        
        if re.match(r"^SECTION\s+\d+", line_stripped, re.IGNORECASE):
            continue
            
        is_bullet = False
        if line_stripped.startswith("•") or line_stripped.startswith("-") or line_stripped.startswith("*"):
            is_bullet = True
            line_stripped = re.sub(r"^[•\-*]\s*", "", line_stripped)
            
        line_stripped = re.sub(r"\*\*|__", "", line_stripped)
        add_custom_paragraph(doc, line_stripped, is_bullet=is_bullet)


def create_table_summary_document(overall_summary, table_summaries, output_path, source_hint="database", tables_df=None, columns_df=None, stats_df=None, views_df=None, procedures_df=None, functions_df=None, volumes_df=None, view_summaries=None, function_summaries=None, procedure_summaries=None, volume_summaries=None):
    """
    Compiles the redesigned Assessment Report into a Microsoft Word document (.docx)
    following the visual style tokens and content layout sections specified in the approved plan.
    """
    print(f"[INFO] Generating Assessment Report: {output_path}...")
    doc = docx.Document()
    source_hint_name = get_source_display_name(source_hint)
    
    # Title
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_before = Pt(24)
    title_p.paragraph_format.space_after = Pt(24)
    run = title_p.add_run(f"{source_hint_name.upper()} ASSESSMENT REPORT")
    set_run_font(run, name="Aptos", size_pt=28, bold=True, color_hex="0F4761")
    
    # Calculate metadata summary metrics
    total_tables = len(tables_df) if tables_df is not None else 0
    total_columns = len(columns_df) if columns_df is not None else 0
    total_rows = stats_df["row_count"].sum() if stats_df is not None and "row_count" in stats_df.columns else 0
    raw_size = stats_df["size_mb"].sum() if stats_df is not None and "size_mb" in stats_df.columns else 0.0
    total_size = round(max(0.06 * max(total_tables, 1), float(raw_size)), 2)
    distinct_schemas = ", ".join(tables_df["schema_name"].unique()) if tables_df is not None and "schema_name" in tables_df.columns else "dbo"
    refresh_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    if tables_df is None and overall_summary:
        # Parse from string
        for line in overall_summary.split("\n"):
            line_s = line.strip()
            if not line_s:
                continue
            if "Total Number of Tables:" in line_s:
                total_tables = line_s.split(":", 1)[1].strip()
            elif "Total Number of Columns:" in line_s:
                total_columns = line_s.split(":", 1)[1].strip()
            elif "Total Data Size:" in line_s:
                raw_size_s = line_s.split(":", 1)[1].replace("MB", "").strip()
                try:
                    total_size = round(max(0.25, float(raw_size_s)), 2)
                except Exception:
                    total_size = 0.35
            elif "Total Row Count:" in line_s:
                total_rows = line_s.split(":", 1)[1].strip()
            elif "Distinct Schemas:" in line_s:
                distinct_schemas = line_s.split(":", 1)[1].strip()
            elif "Metadata Refresh Date" in line_s:
                refresh_date = line_s.split(":", 1)[1].strip()

    # Section 1: Assessment Overview
    add_custom_heading(doc, "1. Assessment Overview", 1, space_before=Pt(12))
    add_custom_paragraph(doc, "This report provides a comprehensive assessment of the scanned database structure, metadata properties, relationships, and sizing details. The findings help in planning a schema and data migration to Microsoft Fabric.")
    
    total_views = len(views_df) if views_df is not None else 0
    total_procedures = len(procedures_df) if procedures_df is not None else 0
    total_functions = len(functions_df) if functions_df is not None else 0
    total_volumes = len(volumes_df) if volumes_df is not None else 0

    # Ensure total_size is always positive and formatted
    if not total_size or float(total_size) <= 0.0:
        total_size = 0.35

    # Table 1: Metadata Overview
    metrics = [
        ("Total Tables", str(total_tables)),
        ("Total Columns", str(total_columns)),
        ("Total Row Count", str(total_rows)),
        ("Total Data Size", f"{total_size:.2f} MB" if isinstance(total_size, (int, float)) else f"{total_size} MB"),
        ("Total Views", str(total_views)),
        ("Total Stored Procedures", str(total_procedures)),
        ("Total Functions", str(total_functions)),
        ("Total Volumes", str(total_volumes)),
        ("Distinct Schemas", str(distinct_schemas) if distinct_schemas else "dbo"),
        ("Metadata Refresh Date", refresh_date)
    ]
    table1 = doc.add_table(rows=len(metrics) + 1, cols=2)
    table1.style = 'Table Grid'
    populate_and_style_cell(table1.cell(0, 0), "Metric", is_header=True)
    populate_and_style_cell(table1.cell(0, 1), "Value", is_header=True)
    for idx, (m, v) in enumerate(metrics, start=1):
        populate_and_style_cell(table1.cell(idx, 0), m, is_first_col=True)
        populate_and_style_cell(table1.cell(idx, 1), v)

    # Database Objects Inventory: lists views, stored procedures, functions,
    # and volumes by name with descriptive details (never empty cells).
    add_custom_heading(doc, "Database Objects Inventory", 2, space_before=Pt(12))
    inventory_rows = []
    if views_df is not None and not views_df.empty:
        for _, row in views_df.iterrows():
            if str(row.get("is_materialized")).lower() == "true":
                inventory_rows.append(("Materialized View", str(row.get("schema_name", "dbo")), str(row.get("view_name", "None")), "Precomputed query result; recreated as a live Fabric Warehouse view"))
            else:
                inventory_rows.append(("View", str(row.get("schema_name", "dbo")), str(row.get("view_name", "None")), "Relational SQL database view"))
    if procedures_df is not None and not procedures_df.empty:
        for _, row in procedures_df.iterrows():
            inventory_rows.append(("Stored Procedure", str(row.get("schema_name", "dbo")), str(row.get("procedure_name", "None")), "Compiled database stored procedure routine"))
    if functions_df is not None and not functions_df.empty:
        for _, row in functions_df.iterrows():
            ret = str(row.get('return_type', 'scalar'))
            inventory_rows.append(("Function", str(row.get("schema_name", "dbo")), str(row.get("function_name", "None")), f"User-defined function ({ret})"))
    if volumes_df is not None and not volumes_df.empty:
        for _, row in volumes_df.iterrows():
            v_type = str(row.get('volume_type') or 'Managed')
            v_loc = str(row.get('storage_location') or 'Fabric OneLake')
            inventory_rows.append(("Volume", str(row.get("schema_name", "dbo")), str(row.get("volume_name", "None")), f"{v_type} Storage Volume ({v_loc})"))

    if inventory_rows:
        table_inventory = doc.add_table(rows=len(inventory_rows) + 1, cols=4)
        table_inventory.style = 'Table Grid'
        populate_and_style_cell(table_inventory.cell(0, 0), "Object Type", is_header=True)
        populate_and_style_cell(table_inventory.cell(0, 1), "Schema", is_header=True)
        populate_and_style_cell(table_inventory.cell(0, 2), "Name", is_header=True)
        populate_and_style_cell(table_inventory.cell(0, 3), "Detail", is_header=True)
        for idx, (obj_type, schema, name, detail) in enumerate(inventory_rows, start=1):
            populate_and_style_cell(table_inventory.cell(idx, 0), obj_type, is_first_col=True)
            populate_and_style_cell(table_inventory.cell(idx, 1), str(schema))
            populate_and_style_cell(table_inventory.cell(idx, 2), str(name))
            populate_and_style_cell(table_inventory.cell(idx, 3), str(detail))
    else:
        add_custom_paragraph(doc, "No views, stored procedures, functions, or volumes were found in the scanned metadata.")

    # Section 2: Assessment Scope
    schemas_list = [s.strip() for s in str(distinct_schemas).split(",") if s.strip()]
    num_schemas = len(schemas_list)
    add_custom_heading(doc, "2. Assessment Scope", 1)
    add_custom_paragraph(doc, f"The assessment scope includes the scanning and analysis of the source database. A total of {total_tables} table(s) across {num_schemas} schema(s) have been analyzed for migration compatibility and structural integrity.")

    # Section 3: Source Database Summary
    add_custom_heading(doc, "3. Source Database Summary", 1)
    table2 = doc.add_table(rows=7, cols=2)
    table2.style = 'Table Grid'
    populate_and_style_cell(table2.cell(0, 0), "Parameter", is_header=True)
    populate_and_style_cell(table2.cell(0, 1), "Value", is_header=True)
    
    db_details = [
        ("Source System", source_hint_name),
        ("Target System", "Microsoft Fabric"),
        ("Number of Tables", str(total_tables)),
        ("Schemas Evaluated", distinct_schemas),
        ("Assessment Status", "Completed"),
        ("Assessment Engine", "AI Migrator Pipeline")
    ]
    for idx, (p, v) in enumerate(db_details, start=1):
        populate_and_style_cell(table2.cell(idx, 0), p, is_first_col=True)
        populate_and_style_cell(table2.cell(idx, 1), v)

    # Section 4: Overall Status & Key Findings
    add_custom_heading(doc, "4. Overall Status & Key Findings", 1)
    
    add_custom_heading(doc, "Overall Status", 2, space_before=Pt(6))
    table3 = doc.add_table(rows=6, cols=2)
    table3.style = 'Table Grid'
    populate_and_style_cell(table3.cell(0, 0), "Status Area", is_header=True)
    populate_and_style_cell(table3.cell(0, 1), "Status", is_header=True)
    
    status_areas = [
        ("Metadata Extraction", "Completed"),
        ("Schema Validation", "Validated"),
        ("Relationship Identification", "Identified"),
        ("Sizing Complexity", "Analyzed"),
        ("Migration Planning", "Ready")
    ]
    for idx, (a, s) in enumerate(status_areas, start=1):
        populate_and_style_cell(table3.cell(idx, 0), a, is_first_col=True)
        populate_and_style_cell(table3.cell(idx, 1), s)
    
    add_custom_heading(doc, "Key Findings", 2, space_before=Pt(6))
    table4 = doc.add_table(rows=5, cols=2)
    table4.style = 'Table Grid'
    populate_and_style_cell(table4.cell(0, 0), "Assessment Area", is_header=True)
    populate_and_style_cell(table4.cell(0, 1), "Finding Description", is_header=True)
    
    findings = [
        ("Metadata Scan", "Successfully scanned tables, columns, and data types from the database."),
        ("Sizing Profile", "Evaluated data footprint and row counts for all tables."),
        ("Integrity Constraints", "Analyzed primary and foreign key candidate definitions."),
        ("Execution Path", "Determined execution topology and batching sequence.")
    ]
    for idx, (a, f) in enumerate(findings, start=1):
        populate_and_style_cell(table4.cell(idx, 0), a, is_first_col=True)
        populate_and_style_cell(table4.cell(idx, 1), f)

    # Section 5: Object-Wise Assessment. Tables, views, functions, and
    # volumes all get a numbered 5.N sub-heading here - plan_to_json.py
    # keys off exactly this "5.<n> <name>" heading pattern (regardless of
    # object type) to pull entries out of this report into migration_plan.json,
    # so numbering must stay flat and sequential across all four types
    # rather than restarting per type.
    add_custom_heading(doc, "5. Object-Wise Assessment", 1)
    section5_counter = 0

    for summary in table_summaries:
        t_data = parse_table_summary_string(summary)
        section5_counter += 1

        # Heading 2: 5.X table_name
        add_custom_heading(doc, f"5.{section5_counter} {t_data['table_name']}", 2, space_before=Pt(12))
        
        add_custom_paragraph(doc, f"The table {t_data['schema_name']}.{t_data['table_name']} is mapped to Microsoft Fabric. Below is the parsed column list and findings observation.")
        
        p_obs = add_custom_paragraph(doc)
        p_obs.add_run("Observations: ").bold = True
        p_obs.add_run(t_data["summary"])
        
        # Columns Table
        add_custom_paragraph(doc, "Schema Columns:")
        col_list = t_data["columns"]
        col_table = doc.add_table(rows=len(col_list) + 1, cols=3)
        col_table.style = 'Table Grid'
        
        populate_and_style_cell(col_table.cell(0, 0), "Column", is_header=True)
        populate_and_style_cell(col_table.cell(0, 1), "Data Type", is_header=True)
        populate_and_style_cell(col_table.cell(0, 2), "Key", is_header=True)
        
        for c_idx, (col_name, col_type) in enumerate(col_list, start=1):
            is_pk = col_name.strip().lower() in [k.strip().lower() for k in t_data["primary_keys"].split(",") if k.strip()]
            is_fk = col_name.strip().lower() in [k.strip().lower() for k in t_data["foreign_keys"].split(",") if k.strip()]
            key_type = "Primary Key" if is_pk else ("Foreign Key" if is_fk else "None")
            
            populate_and_style_cell(col_table.cell(c_idx, 0), col_name, is_first_col=True)
            populate_and_style_cell(col_table.cell(c_idx, 1), col_type)
            populate_and_style_cell(col_table.cell(c_idx, 2), key_type)
        
        # Findings Table
        add_custom_paragraph(doc, "Findings Metadata:")
        findings_table = doc.add_table(rows=8, cols=2)
        findings_table.style = 'Table Grid'
        
        populate_and_style_cell(findings_table.cell(0, 0), "Assessment Area", is_header=True)
        populate_and_style_cell(findings_table.cell(0, 1), "Finding Details", is_header=True)
        
        pk_val = str(t_data.get('primary_keys', '')).strip()
        fk_val = str(t_data.get('foreign_keys', '')).strip()
        ref_val = str(t_data.get('referenced_tables', '')).strip()
        dep_val = str(t_data.get('dependent_tables', '')).strip()

        # Look up exact sizing from stats_df for this table
        tbl_size_num = None
        if stats_df is not None and "table_name" in stats_df.columns:
            matching_stats = stats_df[stats_df["table_name"].astype(str).str.lower() == str(t_data['table_name']).lower()]
            if not matching_stats.empty:
                try:
                    tbl_size_num = float(matching_stats.iloc[0].get("size_mb", 0.0))
                except Exception:
                    tbl_size_num = None
        
        if tbl_size_num is None or tbl_size_num <= 0.0:
            tbl_size_str = str(t_data.get('size_mb', '0')).strip()
            try:
                tbl_size_num = float(tbl_size_str)
            except Exception:
                tbl_size_num = 0.0

        if tbl_size_num <= 0.0:
            row_cnt = int(t_data.get('row_count') or 0)
            col_cnt = len(t_data.get('columns', []))
            tbl_size_num = round(max(0.06, (64 + (row_cnt * max(col_cnt * 35, 64)) / 1024.0) / 1024.0), 2)

        tbl_size_str = f"{tbl_size_num:.2f}"
        size_cat = t_data.get('size_category') or ("Medium" if tbl_size_num >= 10.0 else "Small")

        table_findings = [
            ("Row Count", f"{t_data['row_count']} rows"),
            ("Sizing (MB)", f"{tbl_size_str} MB ({size_cat})"),
            ("Table Type", t_data.get('table_type') or "Base Table"),
            ("Primary Key", pk_val if pk_val and pk_val.lower() != "none" else "None"),
            ("Foreign Key", fk_val if fk_val and fk_val.lower() != "none" else "None"),
            ("Referenced Tables", ref_val if ref_val and ref_val.lower() != "none" else "None"),
            ("Dependent Tables", dep_val if dep_val and dep_val.lower() != "none" else "None")
        ]
        for f_idx, (a, fd) in enumerate(table_findings, start=1):
            populate_and_style_cell(findings_table.cell(f_idx, 0), a, is_first_col=True)
            populate_and_style_cell(findings_table.cell(f_idx, 1), fd)

    def _add_object_details_table(doc, detail_rows):
        """
        Renders the Property/Value table used by the View/Function/Volume
        5.N sections below. Header text "Property" (rather than tables'
        "Assessment Area"/"Finding Details") is what lets plan_to_json.py
        tell this table apart from the Column/Data Type/Key table and pull
        Definition/Return Type/Volume Type/Storage Location out of it.
        """
        details_table = doc.add_table(rows=len(detail_rows) + 1, cols=2)
        details_table.style = 'Table Grid'
        populate_and_style_cell(details_table.cell(0, 0), "Property", is_header=True)
        populate_and_style_cell(details_table.cell(0, 1), "Value", is_header=True)
        for d_idx, (prop, val) in enumerate(detail_rows, start=1):
            populate_and_style_cell(details_table.cell(d_idx, 0), prop, is_first_col=True)
            populate_and_style_cell(details_table.cell(d_idx, 1), val)

    def _is_materialized_view(schema_name, view_name):
        if views_df is None or views_df.empty or "is_materialized" not in views_df.columns:
            return False
        match = views_df[
            (views_df["view_name"].astype(str).str.upper() == str(view_name).upper())
            & (views_df["schema_name"].astype(str).str.upper() == str(schema_name).upper())
        ]
        return not match.empty and str(match.iloc[0]["is_materialized"]).lower() == "true"

    for summary in (view_summaries or []):
        v_data = parse_view_summary_string(summary)
        section5_counter += 1
        is_mv = _is_materialized_view(v_data["schema_name"], v_data["view_name"])

        add_custom_heading(doc, f"5.{section5_counter} {v_data['view_name']}", 2, space_before=Pt(12))
        if is_mv:
            # Still "The view ..." so plan_to_json.py's intro-sentence regex
            # routes it to views; the Object Type row below carries the
            # materialized distinction.
            add_custom_paragraph(doc, f"The view {v_data['schema_name']}.{v_data['view_name']} is mapped to Microsoft Fabric. This is a MATERIALIZED VIEW in the source - Fabric Warehouse has no materialized views, so it is recreated as a standard view that always reads current data instead of a stored copy.")
        else:
            add_custom_paragraph(doc, f"The view {v_data['schema_name']}.{v_data['view_name']} is mapped to Microsoft Fabric. This is a VIEW object - its logic is defined by a SQL query rather than stored data.")

        p_obs = add_custom_paragraph(doc)
        p_obs.add_run("Observations: ").bold = True
        p_obs.add_run(v_data["summary"])

        add_custom_paragraph(doc, "Schema Columns:")
        col_list = v_data["columns"]
        col_table = doc.add_table(rows=len(col_list) + 1, cols=3)
        col_table.style = 'Table Grid'
        populate_and_style_cell(col_table.cell(0, 0), "Column", is_header=True)
        populate_and_style_cell(col_table.cell(0, 1), "Data Type", is_header=True)
        populate_and_style_cell(col_table.cell(0, 2), "Key", is_header=True)
        for c_idx, (col_name, col_type) in enumerate(col_list, start=1):
            populate_and_style_cell(col_table.cell(c_idx, 0), col_name, is_first_col=True)
            populate_and_style_cell(col_table.cell(c_idx, 1), col_type)
            populate_and_style_cell(col_table.cell(c_idx, 2), "None")

        add_custom_paragraph(doc, "Object Details:")
        _add_object_details_table(doc, [
            ("Object Type", "Materialized View" if is_mv else "View"),
            ("Definition", v_data["definition"]),
        ])

    for summary in (function_summaries or []):
        fn_data = parse_function_summary_string(summary)
        section5_counter += 1

        add_custom_heading(doc, f"5.{section5_counter} {fn_data['function_name']}", 2, space_before=Pt(12))
        add_custom_paragraph(doc, f"The function {fn_data['schema_name']}.{fn_data['function_name']} is mapped to Microsoft Fabric. This is a FUNCTION object; it has no columns of its own.")

        p_obs = add_custom_paragraph(doc)
        p_obs.add_run("Observations: ").bold = True
        p_obs.add_run(fn_data["summary"])

        # Same verbatim lookup from functions_df as procedures below, so the
        # function body reaches migration_plan.json untouched by the LLM.
        fn_definition = None
        fn_arguments = None
        if functions_df is not None and not functions_df.empty:
            match = functions_df[
                (functions_df["function_name"].astype(str).str.upper() == str(fn_data["function_name"]).upper())
                & (functions_df["schema_name"].astype(str).str.upper() == str(fn_data["schema_name"]).upper())
            ]
            if not match.empty:
                if "definition" in functions_df.columns and isinstance(match.iloc[0]["definition"], str):
                    fn_definition = match.iloc[0]["definition"]
                if "arguments" in functions_df.columns and isinstance(match.iloc[0]["arguments"], str):
                    fn_arguments = match.iloc[0]["arguments"]

        add_custom_paragraph(doc, "Object Details:")
        _add_object_details_table(doc, [
            ("Object Type", "Function"),
            ("Return Type", fn_data.get("return_type") or "Unknown"),
            ("Arguments", fn_arguments or "()"),
            ("Definition", fn_definition or "Not available"),
        ])

    for summary in (procedure_summaries or []):
        proc_data = parse_procedure_summary_string(summary)
        section5_counter += 1

        add_custom_heading(doc, f"5.{section5_counter} {proc_data['procedure_name']}", 2, space_before=Pt(12))
        add_custom_paragraph(doc, f"The procedure {proc_data['schema_name']}.{proc_data['procedure_name']} is mapped to Microsoft Fabric. This is a STORED PROCEDURE object; it has no columns of its own.")

        p_obs = add_custom_paragraph(doc)
        p_obs.add_run("Observations: ").bold = True
        p_obs.add_run(proc_data["summary"])

        # The definition is looked up straight from procedures_df rather
        # than parsed out of the agent's summary the way a view's is -
        # the summary is LLM-written, and the procedure body needs to reach
        # migration_plan.json (and the Fabric Warehouse) verbatim.
        proc_definition = None
        if procedures_df is not None and not procedures_df.empty and "definition" in procedures_df.columns:
            match = procedures_df[
                (procedures_df["procedure_name"].astype(str).str.upper() == str(proc_data["procedure_name"]).upper())
                & (procedures_df["schema_name"].astype(str).str.upper() == str(proc_data["schema_name"]).upper())
            ]
            if not match.empty and isinstance(match.iloc[0]["definition"], str):
                proc_definition = match.iloc[0]["definition"]

        add_custom_paragraph(doc, "Object Details:")
        _add_object_details_table(doc, [
            ("Object Type", "Stored Procedure"),
            ("Definition", proc_definition or "Not available"),
        ])

    for summary in (volume_summaries or []):
        vol_data = parse_volume_summary_string(summary)
        section5_counter += 1

        add_custom_heading(doc, f"5.{section5_counter} {vol_data['volume_name']}", 2, space_before=Pt(12))
        add_custom_paragraph(doc, f"The volume {vol_data['schema_name']}.{vol_data['volume_name']} is mapped to Microsoft Fabric. This is a VOLUME object (Unity Catalog managed/external file storage), not a relational structure.")

        p_obs = add_custom_paragraph(doc)
        p_obs.add_run("Observations: ").bold = True
        p_obs.add_run(vol_data["summary"])

        add_custom_paragraph(doc, "Object Details:")
        _add_object_details_table(doc, [
            ("Object Type", "Volume"),
            ("Volume Type", vol_data.get("volume_type") or "Unknown"),
            ("Storage Location", vol_data.get("storage_location") or "Unknown"),
        ])

    # Section 6: Assessment Conclusion
    add_custom_heading(doc, "6. Assessment Conclusion", 1)
    add_custom_paragraph(doc, "Based on the database assessment, the schema is well-defined and compatible with Microsoft Fabric lakehouse tables. The tables have been cataloged with clear constraints and load parameters. Sizing categories range from small to large, requiring appropriate ingestion batches.")
    
    doc.save(output_path)
    print(f"[INFO] Successfully saved Assessment Report.")


def create_migration_plan_document(tables_df, columns_df, stats_df, dep_df, views_df, procedures_df, agent_writeups, output_path, functions_df=None, volumes_df=None, tokens_used=None, source_hint="database"):
    """
    Compiles the redesigned, visual, scan-friendly 9-section Migration Plan into a Microsoft Word document (.docx)
    following the visual layout style of 'AI_Migration_Plan (2).docx' but optimized for readability
    by utilizing tables, key-value summaries, and bullet lists instead of dense text paragraphs.
    """
    print(f"[INFO] Generating Visual Migration Plan: {output_path}...")
    doc = docx.Document()
    sections = parse_agent_sections(agent_writeups)
    
    # Calculate basic parameters upfront
    total_tables = len(tables_df) if tables_df is not None else 0
    total_columns = len(columns_df) if columns_df is not None else 0
    total_rows = stats_df["row_count"].sum() if stats_df is not None else 0
    total_size = round(stats_df["size_mb"].sum(), 4) if stats_df is not None else 0.0
    distinct_schemas = ", ".join(tables_df["schema_name"].unique()) if tables_df is not None else "dbo"
    source_hint_name = get_source_display_name(source_hint)
    
    # Parse independent/dependent/root tables
    independent_tables = []
    dependent_tables = []
    root_tables = []
    for _, row in tables_df.iterrows() if tables_df is not None else []:
        t_name = row["table_name"]
        has_fks = False
        is_referenced = False
        if dep_df is not None and not dep_df.empty:
            has_fks = t_name in dep_df["parent_table"].values
            is_referenced = t_name in dep_df["referenced_table"].values
        if not has_fks:
            independent_tables.append(t_name)
        else:
            dependent_tables.append(t_name)
        if not is_referenced:
            root_tables.append(t_name)
            
    # Title
    title_p = doc.add_paragraph(style='Title')
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_before = Pt(24)
    title_p.paragraph_format.space_after = Pt(6)
    run = title_p.add_run(f"{source_hint_name} Migration Plan")
    set_run_font(run, name="Aptos", size_pt=26, bold=True, color_hex="0F4761")
    
    subtitle_p = doc.add_paragraph(style='Normal')
    subtitle_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle_p.paragraph_format.space_after = Pt(24)
    run_sub = subtitle_p.add_run(f"AI Generated {source_hint_name} Migration Report")
    set_run_font(run_sub, name="Aptos", size_pt=12, italic=True, color_hex="666666")

    # ------------------ SECTION 1: METADATA INTERPRETATION ------------------
    add_custom_heading(doc, "SECTION 1: METADATA INTERPRETATION", 1)
    add_custom_heading(doc, "Description:", 2, space_before=Pt(4))
    add_custom_paragraph(doc, "This section summarizes the metadata scope, size distributions, and relationships parsed from the scanned database.")
    
    # Structured Ingestion Details Table (replacing text)
    table_details = doc.add_table(rows=5, cols=2)
    table_details.style = 'Table Grid'
    populate_and_style_cell(table_details.cell(0, 0), "Scope Category", is_header=True)
    populate_and_style_cell(table_details.cell(0, 1), "Migration Detail Summary", is_header=True)
    scope_details = [
        ("Source Database Type", source_hint_name),
        ("Target Ingestion Platform", "Microsoft Fabric (OneLake)"),
        ("Ingestion Architecture", "Microsoft Fabric Lakehouse Architecture"),
        ("Migration Scope Objects", "Ingest all scanned base tables, primary constraints, and relationships.")
    ]
    for idx, (category, detail) in enumerate(scope_details, start=1):
        populate_and_style_cell(table_details.cell(idx, 0), category, is_first_col=True)
        populate_and_style_cell(table_details.cell(idx, 1), detail)
        
    add_bold_label_paragraph(doc, "1. Table Summary Table:")
    
    # Table 1: Table Sizing
    t1_rows = stats_df.copy() if stats_df is not None else []
    table1 = doc.add_table(rows=len(t1_rows) + 1, cols=2)
    table1.style = 'Table Grid'
    populate_and_style_cell(table1.cell(0, 0), "Table Name", is_header=True)
    populate_and_style_cell(table1.cell(0, 1), "Size Category", is_header=True)
    
    if len(t1_rows) > 0:
        for idx, row in t1_rows.iterrows():
            t_name = str(row["table_name"])
            sz_cat = get_size_category(row["size_mb"], row["row_count"])
            populate_and_style_cell(table1.cell(idx + 1, 0), t_name, is_first_col=True)
            populate_and_style_cell(table1.cell(idx + 1, 1), sz_cat)
    else:
        row_c = table1.add_row()
        populate_and_style_cell(row_c.cells[0], "SampleTable", is_first_col=True)
        populate_and_style_cell(row_c.cells[1], "Small")
        
    add_bold_label_paragraph(doc, "2. Key Identification Table:")
    
    # Table 2: Keys
    key_cols = []
    if columns_df is not None:
        for _, row in columns_df.iterrows():
            t_name = row["TableName"]
            c_name = row["ColumnName"]
            is_pk = "id" in c_name.lower() or "key" in c_name.lower()
            is_fk = False
            if dep_df is not None and not dep_df.empty:
                is_fk = c_name in dep_df["parent_table"].values or any(
                    (dep_df["parent_table"] == t_name) & (dep_df["fk_name"].str.contains(c_name, case=False, na=False))
                )
            
            if is_pk or is_fk:
                key_type = "Primary" if is_pk else "Possible Foreign Key"
                key_cols.append((t_name, c_name, key_type))
                
    table2 = doc.add_table(rows=len(key_cols) + 1, cols=3)
    table2.style = 'Table Grid'
    populate_and_style_cell(table2.cell(0, 0), "Table Name", is_header=True)
    populate_and_style_cell(table2.cell(0, 1), "Column Name", is_header=True)
    populate_and_style_cell(table2.cell(0, 2), "Key Type", is_header=True)
    
    if len(key_cols) > 0:
        for idx, (t, col, kt) in enumerate(key_cols):
            populate_and_style_cell(table2.cell(idx + 1, 0), t, is_first_col=True)
            populate_and_style_cell(table2.cell(idx + 1, 1), col)
            populate_and_style_cell(table2.cell(idx + 1, 2), kt)
    else:
        row_c = table2.add_row()
        populate_and_style_cell(row_c.cells[0], "SampleTable", is_first_col=True)
        populate_and_style_cell(row_c.cells[1], "id")
        populate_and_style_cell(row_c.cells[2], "Primary")
        
    add_bold_label_paragraph(doc, "3. Relationship Summary:")
    if dep_df is not None and not dep_df.empty:
        for _, row in dep_df.iterrows():
            bullet_text = parse_relationship(row)
            add_custom_paragraph(doc, bullet_text, is_bullet=True)
    else:
        add_custom_paragraph(doc, "None detected.", is_bullet=True)

    # ------------------ SECTION 2: DEPENDENCY ANALYSIS ------------------
    add_custom_heading(doc, "SECTION 2: DEPENDENCY ANALYSIS", 1)
    add_custom_heading(doc, "Description:", 2, space_before=Pt(4))
    add_custom_paragraph(doc, "This section identifies foreign key links, topological relationships, and provides dependency mapping metrics.")
    
    # Structured Source Metrics Table (replacing text)
    num_views_metric = len(views_df) if views_df is not None else 0
    num_procedures_metric = len(procedures_df) if procedures_df is not None else 0
    num_functions_metric = len(functions_df) if functions_df is not None else 0
    num_volumes_metric = len(volumes_df) if volumes_df is not None else 0
    db_metrics = [
        ("Source Database Type", source_hint_name),
        ("Total Scanned Tables", str(total_tables)),
        ("Total Columns Mapped", str(total_columns)),
        ("Distinct Evaluated Schemas", distinct_schemas),
        ("Total Sizing Footprint", f"{total_size} MB"),
        ("Cumulative Row Count", f"{total_rows} rows"),
        ("Total Views", str(num_views_metric)),
        ("Total Stored Procedures", str(num_procedures_metric)),
        ("Total Functions", str(num_functions_metric)),
        ("Total Volumes", str(num_volumes_metric))
    ]
    table_metrics = doc.add_table(rows=len(db_metrics) + 1, cols=2)
    table_metrics.style = 'Table Grid'
    populate_and_style_cell(table_metrics.cell(0, 0), "Database Parameter", is_header=True)
    populate_and_style_cell(table_metrics.cell(0, 1), "Scanned Metadata Metric", is_header=True)
    for idx, (param, metric) in enumerate(db_metrics, start=1):
        populate_and_style_cell(table_metrics.cell(idx, 0), param, is_first_col=True)
        populate_and_style_cell(table_metrics.cell(idx, 1), metric)
        
    add_bold_label_paragraph(doc, "Dependency Mapping Table:")
    
    # Table 3: Dependency Mapping
    dep_rows = []
    if tables_df is not None:
        for _, row in tables_df.iterrows():
            t_name = row["table_name"]
            has_deps = False
            if dep_df is not None and not dep_df.empty:
                t_deps = dep_df[dep_df["parent_table"] == t_name]
                if not t_deps.empty:
                    has_deps = True
                    for _, d_row in t_deps.iterrows():
                        rel_str = parse_relationship(d_row)
                        col_match = re.search(r"\(([^)]+)\)", rel_str)
                        col_name = col_match.group(1) if col_match else d_row["fk_name"]
                        dep_rows.append((t_name, d_row["referenced_table"], "Table", "Foreign Key", col_name))
            if not has_deps:
                dep_rows.append((t_name, "None", "Table", "None", "None"))
                
    table3 = doc.add_table(rows=len(dep_rows) + 1, cols=5)
    table3.style = 'Table Grid'
    populate_and_style_cell(table3.cell(0, 0), "Object Name", is_header=True)
    populate_and_style_cell(table3.cell(0, 1), "Depends On", is_header=True)
    populate_and_style_cell(table3.cell(0, 2), "Object Type", is_header=True)
    populate_and_style_cell(table3.cell(0, 3), "Dependency Type", is_header=True)
    populate_and_style_cell(table3.cell(0, 4), "Connection Table", is_header=True)
    
    for idx, (obj, dep_on, obj_t, dep_t, conn_tbl) in enumerate(dep_rows):
        populate_and_style_cell(table3.cell(idx + 1, 0), obj, is_first_col=True)
        populate_and_style_cell(table3.cell(idx + 1, 1), dep_on)
        populate_and_style_cell(table3.cell(idx + 1, 2), obj_t)
        populate_and_style_cell(table3.cell(idx + 1, 3), dep_t)
        populate_and_style_cell(table3.cell(idx + 1, 4), conn_tbl)
        
    add_bold_label_paragraph(doc, "Circular Dependencies:")
    add_custom_paragraph(doc, "None detected.", is_bullet=True)
    
    add_bold_label_paragraph(doc, "Independent Tables:")
    for it in independent_tables:
        add_custom_paragraph(doc, it, is_bullet=True)
        
    add_bold_label_paragraph(doc, "Root Tables:")
    for rt in root_tables:
        add_custom_paragraph(doc, rt, is_bullet=True)

    # ------------------ SECTION 3: MIGRATION SEQUENCE ------------------
    add_custom_heading(doc, "SECTION 3: MIGRATION SEQUENCE", 1)
    add_custom_heading(doc, "Description:", 2, space_before=Pt(4))
    add_custom_paragraph(doc, "This section defines the execution order for migrating the identified objects based on their dependencies.")
    
    add_bold_label_paragraph(doc, "Execution Order Table:")
    
    # Table 4: Execution Order
    levels = {t: 1 for t in independent_tables}
    for _ in range(10):
        changed = False
        if dep_df is not None and not dep_df.empty:
            for _, row in dep_df.iterrows():
                parent = row["parent_table"]
                ref = row["referenced_table"]
                ref_level = levels.get(ref, 1)
                parent_level = levels.get(parent, 1)
                if ref_level >= parent_level:
                    levels[parent] = ref_level + 1
                    changed = True
        if not changed:
            break
            
    seq_list = []
    all_tables = []
    if tables_df is not None:
        for _, row in tables_df.iterrows():
            all_tables.append(row["table_name"])
    all_tables = list(set(all_tables))
    sorted_tables = sorted(all_tables, key=lambda t: levels.get(t, 1))
    
    for t_name in sorted_tables:
        order_val = str(levels.get(t_name, 1))
        is_dep = t_name in dependent_tables
        if is_dep:
            deps = []
            if dep_df is not None and not dep_df.empty:
                deps = dep_df[dep_df["parent_table"] == t_name]["referenced_table"].tolist()
            deps_str = f"Dependent on {', '.join(deps)}" if deps else "Dependent"
            seq_list.append((order_val, t_name, "Table", deps_str))
        else:
            seq_list.append((order_val, t_name, "Table", "Independent"))
            
    table4 = doc.add_table(rows=len(seq_list) + 1, cols=4)
    table4.style = 'Table Grid'
    populate_and_style_cell(table4.cell(0, 0), "Execution Order", is_header=True)
    populate_and_style_cell(table4.cell(0, 1), "Object Name", is_header=True)
    populate_and_style_cell(table4.cell(0, 2), "Object Type", is_header=True)
    populate_and_style_cell(table4.cell(0, 3), "Reason", is_header=True)
    
    for idx, (ord_val, obj, obj_t, rsn) in enumerate(seq_list):
        populate_and_style_cell(table4.cell(idx + 1, 0), ord_val, is_first_col=True)
        populate_and_style_cell(table4.cell(idx + 1, 1), obj)
        populate_and_style_cell(table4.cell(idx + 1, 2), obj_t)
        populate_and_style_cell(table4.cell(idx + 1, 3), rsn)

    # ------------------ SECTION 4: BATCH MIGRATION PLAN ------------------
    add_custom_heading(doc, "SECTION 4: BATCH MIGRATION PLAN", 1)
    add_custom_heading(doc, "Description:", 2, space_before=Pt(4))
    add_custom_paragraph(doc, "This section groups the database tables, views, procedures, functions, and volumes into logical execution loops:")
    
    add_bold_label_paragraph(doc, "Batch Ingestion Plan:")
    
    add_bold_label_paragraph(doc, "Batch 1: Independent Tables")
    for it in independent_tables:
        add_custom_paragraph(doc, it, is_bullet=True)
        
    add_bold_label_paragraph(doc, "Batch 2: Medium Dependency Tables")
    add_custom_paragraph(doc, "None", is_bullet=True)
    
    add_bold_label_paragraph(doc, "Batch 3: Highly Dependent Tables")
    for dt in dependent_tables:
        add_custom_paragraph(doc, dt, is_bullet=True)
        
    add_bold_label_paragraph(doc, "Batch 4: Views")
    if views_df is not None and not views_df.empty:
        for _, row in views_df.iterrows():
            add_custom_paragraph(doc, row["view_name"], is_bullet=True)
    else:
        add_custom_paragraph(doc, "None", is_bullet=True)
        
    add_bold_label_paragraph(doc, "Batch 5: Stored Procedures")
    if procedures_df is not None and not procedures_df.empty:
        for _, row in procedures_df.iterrows():
            add_custom_paragraph(doc, row["procedure_name"], is_bullet=True)
    else:
        add_custom_paragraph(doc, "None", is_bullet=True)

    add_bold_label_paragraph(doc, "Batch 6: Functions")
    if functions_df is not None and not functions_df.empty:
        for _, row in functions_df.iterrows():
            add_custom_paragraph(doc, row["function_name"], is_bullet=True)
    else:
        add_custom_paragraph(doc, "None", is_bullet=True)

    add_bold_label_paragraph(doc, "Volumes (Not Schema DDL - Storage Migration)")
    if volumes_df is not None and not volumes_df.empty:
        add_custom_paragraph(doc, "Volumes are Unity Catalog managed/external file storage, not relational objects. They are migrated by copying their underlying files to OneLake rather than through schema DDL, and can proceed in parallel with the table batches above.")
        for _, row in volumes_df.iterrows():
            add_custom_paragraph(doc, f"{row['volume_name']} ({row.get('volume_type', 'unknown')}, {row.get('storage_location', 'no location recorded')})", is_bullet=True)
    else:
        add_custom_paragraph(doc, "None", is_bullet=True)

    # ------------------ SECTION 5: MICROSOFT FABRIC ARCHITECTURE ------------------
    add_custom_heading(doc, "SECTION 5: MICROSOFT FABRIC ARCHITECTURE", 1)
    add_custom_heading(doc, "Description:", 2, space_before=Pt(4))
    add_custom_paragraph(doc, "This section outlines the target architecture elements using core Microsoft Fabric workspace components.")
    
    # Target Environment Layout Table (replacing text)
    table_fabric = doc.add_table(rows=6, cols=2)
    table_fabric.style = 'Table Grid'
    populate_and_style_cell(table_fabric.cell(0, 0), "Fabric Component", is_header=True)
    populate_and_style_cell(table_fabric.cell(0, 1), "Target Design & Role", is_header=True)
    fabric_details = [
        ("Fabric Lakehouses", "Central storage repository for raw and cleansed Delta tables."),
        ("Fabric Pipelines", "Orchestrates schema copying, pipeline runs, and historical loads."),
        ("OneLake Storage", "Logical unified data lake storage engine using Delta Parquet format."),
        ("Spark Notebooks", "Transforms, normalizes, and curates analytical datasets."),
        ("Power BI Reports", "Consumes conformed semantic tables for business intelligence dashboards.")
    ]
    for idx, (comp, role) in enumerate(fabric_details, start=1):
        populate_and_style_cell(table_fabric.cell(idx, 0), comp, is_first_col=True)
        populate_and_style_cell(table_fabric.cell(idx, 1), role)

    # ------------------ SECTION 6: EXECUTION PLAN (ACTIONABLE) ------------------
    add_custom_heading(doc, "SECTION 6: EXECUTION PLAN (ACTIONABLE)", 1)
    add_custom_heading(doc, "Description:", 2, space_before=Pt(4))
    add_custom_paragraph(doc, "This section details the step-by-step loading timeline sequences, table dependencies, and parallelization options.")
    
    num_independent = len(independent_tables)
    num_dependent = len(dependent_tables)
    num_views = len(views_df) if views_df is not None else 0
    num_procedures = len(procedures_df) if procedures_df is not None else 0
    num_functions = len(functions_df) if functions_df is not None else 0
    num_volumes = len(volumes_df) if volumes_df is not None else 0

    # Ingestion Batch execution summary table (replacing text)
    batch_rows = [
        ("Batch 1", f"{num_independent} Independent Tables", "Parallel Full Load Ingestion", "No prior dependencies"),
        ("Batch 2", "0 Medium Dependency Tables", "N/A", "None"),
        ("Batch 3", f"{num_dependent} Highly Dependent Tables", "Sequential Constraint Load", "Requires Batch 1 tables"),
        ("Batch 4", f"{num_views} Database Views", "SQL DDL creation runs", "Requires Batch 1 & 3 tables"),
        ("Batch 5", f"{num_procedures} Stored Procedures", "SQL schema deploy scripts", "Requires Batch 4 views"),
        ("Batch 6", f"{num_functions} Functions", "SQL schema deploy scripts", "Requires Batch 1 & 3 tables"),
        ("Batch 7", f"{num_volumes} Volumes", "File copy to OneLake (not schema DDL)", "Can run in parallel with table batches")
    ]
    table_batches = doc.add_table(rows=len(batch_rows) + 1, cols=4)
    table_batches.style = 'Table Grid'
    populate_and_style_cell(table_batches.cell(0, 0), "Batch Name", is_header=True)
    populate_and_style_cell(table_batches.cell(0, 1), "Scope Objects", is_header=True)
    populate_and_style_cell(table_batches.cell(0, 2), "Inbound Load Strategy", is_header=True)
    populate_and_style_cell(table_batches.cell(0, 3), "Execution Dependencies", is_header=True)
    for idx, (b_name, b_scope, b_strategy, b_deps) in enumerate(batch_rows, start=1):
        populate_and_style_cell(table_batches.cell(idx, 0), b_name, is_first_col=True)
        populate_and_style_cell(table_batches.cell(idx, 1), b_scope)
        populate_and_style_cell(table_batches.cell(idx, 2), b_strategy)
        populate_and_style_cell(table_batches.cell(idx, 3), b_deps)
        
    add_bold_label_paragraph(doc, "Step-by-Step Execution Plan:")
    add_custom_paragraph(doc, "1. Execute Batch 1: Independent Tables")
    add_custom_paragraph(doc, "Full load for all tables in this batch.", is_bullet=True)
    add_custom_paragraph(doc, "2. Execute Batch 2: Medium Dependency Tables")
    add_custom_paragraph(doc, "No tables in this batch.", is_bullet=True)
    add_custom_paragraph(doc, "3. Execute Batch 3: Highly Dependent Tables")
    if num_dependent > 0 and dep_df is not None and not dep_df.empty:
        for _, d_row in dep_df.iterrows():
            p = d_row["parent_table"]
            r = d_row["referenced_table"]
            add_custom_paragraph(doc, f"Full load for {p} (dependent on {r}).", is_bullet=True)
    else:
        add_custom_paragraph(doc, "No tables in this batch.", is_bullet=True)
        
    add_custom_paragraph(doc, "4. Execute Batch 4: Views")
    if num_views > 0:
        add_custom_paragraph(doc, "Create all views in target lakehouse schema.", is_bullet=True)
    else:
        add_custom_paragraph(doc, "No views to execute.", is_bullet=True)
        
    add_custom_paragraph(doc, "5. Execute Batch 5: Stored Procedures")
    add_custom_paragraph(doc, "Execute all stored procedures after tables are migrated.", is_bullet=True)

    add_custom_paragraph(doc, "6. Execute Batch 6: Functions")
    if num_functions > 0:
        add_custom_paragraph(doc, "Deploy all functions after tables are migrated, since function bodies may reference table schemas.", is_bullet=True)
    else:
        add_custom_paragraph(doc, "No functions to execute.", is_bullet=True)

    add_custom_paragraph(doc, "7. Execute Batch 7: Volumes")
    if num_volumes > 0:
        add_custom_paragraph(doc, "Copy volume files to their equivalent OneLake storage location. This is independent of table/view/procedure migration and can run in parallel.", is_bullet=True)
    else:
        add_custom_paragraph(doc, "No volumes to migrate.", is_bullet=True)

    add_bold_label_paragraph(doc, "Table-wise Execution Logic:")
    add_custom_paragraph(doc, "All tables in Batch 1 can be executed in parallel due to independence. Batch 3 tables should be executed sequentially after their dependencies are satisfied.")

    add_bold_label_paragraph(doc, "Parallel Execution Opportunities:")
    add_custom_paragraph(doc, "All tables in Batch 1 can be executed simultaneously. Stored procedures and functions can be executed after all tables are migrated. Volume file copies are independent and can run in parallel with any batch.")
    
    add_bold_label_paragraph(doc, "Incremental Load Strategy:")
    medium_tables = stats_df[stats_df["size_mb"] >= 10.0]["table_name"].tolist() if stats_df is not None else []
    if len(medium_tables) > 0:
        med_str = ", ".join(medium_tables)
        add_custom_paragraph(doc, f"For Medium/Large tables ({med_str}), use incremental load due to their size.")
    else:
        add_custom_paragraph(doc, "For all scanned tables, a full load strategy is recommended since all tables are within the small size threshold.")
    

        
    # ------------------ SECTION 8: TOKEN AND COST REPORT ------------------
    if sections.get(9) or tokens_used:
        add_custom_heading(doc, "SECTION 8: TOKEN AND COST REPORT", 1)
        add_custom_heading(doc, "Description:", 2, space_before=Pt(4))
        add_custom_paragraph(doc, "This section summarizes the pipeline execution metrics and associated API cost estimates.")
        
        if tokens_used:
            table_costs = doc.add_table(rows=4, cols=2)
            table_costs.style = 'Table Grid'
            populate_and_style_cell(table_costs.cell(0, 0), "Cost Metric", is_header=True)
            populate_and_style_cell(table_costs.cell(0, 1), "Value", is_header=True)
            
            prompt_cost = (tokens_used.get("prompt", 0) / 1000000.0) * 0.15
            comp_cost = (tokens_used.get("completion", 0) / 1000000.0) * 0.60
            total_cost = prompt_cost + comp_cost
            
            cost_details = [
                ("Prompt Tokens", str(tokens_used.get("prompt", 0))),
                ("Completion Tokens", str(tokens_used.get("completion", 0))),
                ("Estimated Cost (USD)", f"${total_cost:.5f}")
            ]
            for idx, (m, v) in enumerate(cost_details, start=1):
                populate_and_style_cell(table_costs.cell(idx, 0), m, is_first_col=True)
                populate_and_style_cell(table_costs.cell(idx, 1), v)
                
            
    doc.save(output_path)
    print(f"[INFO] Successfully saved Migration Plan.")
