import os
import sys
import time
import threading
import traceback
import pandas as pd
from datetime import datetime
from pathlib import Path

# Add src to python path just in case
sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from AI_Agent_Pipeline.src import (
    AzureAIOrchestrator,
    collect_metadata,
    metadata_to_dataframes,
    create_table_summary_document,
    create_migration_plan_document
)
from Logs import Logs

try:
    from HarnessLayers.layer2.Layer import EvaluatorGeneratorHarness, format_layer2_report
except ImportError:
    try:
        from layer2.Layer import EvaluatorGeneratorHarness, format_layer2_report
    except ImportError:
        EvaluatorGeneratorHarness = None
        format_layer2_report = None

# Reconfigure stdout to use UTF-8 just in case
try:
    sys.stdout.reconfigure(encoding='utf-8')
except AttributeError:
    pass


def _update_progress(scan_id, progress=None, current_message=None, log_entry=None, log_type="Scan Info"):
    try:
        from Migrator.views import update_scan_job_state
        update_scan_job_state(scan_id, progress, current_message, log_entry, log_type)
    except Exception:
        pass


def _clip_for_ui(text: str, full_report_name: str = None, max_lines: int = 60) -> str:
    """Keeps a check report readable in the UI log pane: a report with hundreds of
    lines (e.g. one line per missing column) is cut to max_lines with a pointer to
    the file that holds the complete text."""
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text
    where = f" in {full_report_name}" if full_report_name else ""
    return "\n".join(lines[:max_lines] + [f"... ({len(lines) - max_lines} more line(s) - full list{where})"])


def Agents_PipeLine(metadata: dict = None, source_hint: str = None, scan_id: str = None):
    """
    metadata: the dict a Metadata_Scanner extractor's extract() just
    returned for the source that was scanned this request. When given,
    it's converted directly into dataframes so the Assessment Report
    reflects exactly that scan. When omitted (standalone/manual runs),
    falls back to scanning whatever CSV/JSON files are sitting in the
    data/ directory - the original behavior.

    source_hint: the normalized source platform identifier (e.g.
    "databricks") already known from the scan request, forwarded to the
    orchestrator so it can ground the agents with the matching RAG
    knowledge base instead of guessing the source from raw metadata.
    """
    print(f"==================================================\nstarting Database Migration Assessment Pipeline\n==================================================")

    # 1. Directories setup

    base_dir = Path(__file__).resolve().parent
    data_dir = base_dir.parent / "data"
    output_dir = base_dir / "output"

    if not os.path.exists(output_dir):
        print(f"[INFO] Creating output directory: {output_dir}")
        os.makedirs(output_dir)

    # 1b. Persist the RAW scan metadata (pre-AI, pre-Fabric-mapping) into the
    # same output folder as the generated reports. write_metadata() already
    # existed but was never actually called anywhere in the codebase, so no
    # raw metadata.json was ever produced -- only the AI-written reports and
    # the Fabric-target artifact were. Written before the AI pipeline runs,
    # so it's on disk even if report generation fails downstream, and it's
    # what compare_metadata_to_reports.py should be grounded against instead
    # of the Fabric-target artifact where possible.
    source_name = (source_hint or "database").replace(" ", "_").lower()
    raw_metadata_filename = None
    if metadata is not None:
        try:
            from Metadata_Scanner.utils.metadata_writer import write_metadata
            raw_metadata_path = write_metadata(
                metadata, output_dir=output_dir, filename=f"{source_name}_metadata.json"
            )
            raw_metadata_filename = os.path.basename(raw_metadata_path)
            print(f"[INFO] Raw scan metadata saved to: {raw_metadata_path}")
        except Exception as exc:
            print(f"[WARN] Could not save raw scan metadata.json: {exc}")

    # 2. Collect Metadata - prefer the live scan's metadata dict when given,
    # otherwise fall back to scanning data/ for CSV/JSON uploads.
    if metadata is not None:
        print("[INFO] Using metadata from the live scan just performed...")
        dfs = metadata_to_dataframes(
            metadata, label=metadata.get("database", "live_scan")
        )
    else:
        if not os.path.exists(data_dir):
            print(f"[ERROR] Data directory not found at: {data_dir}")
            print("[ERROR] Please upload source files to the 'data/' directory.")
            sys.exit(1)
        print("[INFO] Collecting metadata from files in data/ directory...")
        dfs = collect_metadata(data_dir)

    # Dynamically unpack 8 dataframes (with functions_df, volumes_df) or 6 dataframes (legacy)
    if len(dfs) == 8:
        tables_df, columns_df, stats_df, views_df, procedures_df, functions_df, volumes_df, dep_df = dfs
    elif len(dfs) == 6:
        tables_df, columns_df, stats_df, views_df, procedures_df, dep_df = dfs
        functions_df = pd.DataFrame()
        volumes_df = pd.DataFrame()
    else:
        tables_df = dfs[0]
        columns_df = dfs[1]
        stats_df = dfs[2]
        views_df = dfs[3]
        procedures_df = dfs[4]
        dep_df = dfs[-1]
        functions_df = dfs[5] if len(dfs) > 6 else pd.DataFrame()
        volumes_df = dfs[6] if len(dfs) > 7 else pd.DataFrame()

    if tables_df.empty:
        print("[ERROR] No tables found in the scanned metadata.")
        sys.exit(1)

    print(f"[INFO] Successfully collected metadata for {len(tables_df)} tables.")
    
    # 3. Initialize Orchestrator
    orchestrator = AzureAIOrchestrator(
        tables_df, columns_df, stats_df, views_df, procedures_df, dep_df,
        source_hint=source_hint,
        functions_df=functions_df,
        volumes_df=volumes_df,
        scan_id=scan_id
    )

    try:
        result = _run_pipeline(
            orchestrator, tables_df, columns_df, stats_df, views_df, procedures_df, dep_df,
            output_dir, source_hint, scan_id,
            functions_df=functions_df, volumes_df=volumes_df
        )
        result["raw_metadata"] = raw_metadata_filename
        return result
    except Exception as exc:
        _update_progress(scan_id, log_entry=f"[FAILED] Layer 2 stopped: {exc}", log_type="Harness Layer2")
        _update_progress(scan_id, log_entry=f"[ERROR] Assessment pipeline failed: {exc}", log_type="Scan Info")
        _update_progress(scan_id, log_entry=traceback.format_exc(), log_type="Scan Info")
        raise
    finally:
        if orchestrator.tokens_used["total"]:
            _update_progress(scan_id, log_entry={
                "total": orchestrator.tokens_used["total"],
                "prompt": orchestrator.tokens_used["prompt"],
                "completion": orchestrator.tokens_used["completion"],
                "cost": round(
                    (orchestrator.tokens_used["prompt"] / 1000000.0) * 0.15
                    + (orchestrator.tokens_used["completion"] / 1000000.0) * 0.60,
                    5,
                ),
            }, log_type="Token Info")
        # Always clean up agents created on Azure AI Foundry, even if the
        # pipeline fails partway through - otherwise the next run's
        # create_agents() collides with these leftovers (409 conflict).
        orchestrator.cleanup_agents()


def _run_pipeline(orchestrator, tables_df, columns_df, stats_df, views_df, procedures_df, dep_df, output_dir, source_hint=None, scan_id=None, functions_df=None, volumes_df=None):
    # Initialize Layer 2 Evaluator-Generator Feedback Harness
    harness2 = None
    if EvaluatorGeneratorHarness:
        try:
            harness2 = EvaluatorGeneratorHarness(source_hint=source_hint or "database")
            harness2.add_initialization_check(
                ai_foundry_connected=True,
                table_summarizer_ready=True,
                migration_generator_ready=True,
                rag_indexed=True
            )
        except Exception as h2_err:
            print(f"[WARN] Failed to init Harness Layer 2: {h2_err}")

    # Create agents using Microsoft AI Foundry SDK
    init_msg = (
        "HARNESS LAYER 2 - EVALUATOR-GENERATOR FEEDBACK HARNESS:\n"
        f"Generated At: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        "------------------------------\n"
        "[CHECKED]: agent_orchestration_validation\n"
        "    - Harness Steps:\n"
        "        * [SUCCESS]: Connected to Microsoft AI Foundry Projects SDK\n"
        "        * [SUCCESS]: Initialized Table Summarizer Generator Agent (Azure AI Foundry)\n"
        "        * [SUCCESS]: Initialized Migration Plan Generator Agent (Azure AI Foundry)\n"
        "        * [SUCCESS]: Loaded Semantic RAG Migration Knowledge Base"
    )
    _update_progress(
        scan_id,
        progress=45,
        current_message="Initializing Harness Layer 2 AI agents...",
        log_entry=init_msg,
        log_type="Harness Layer2"
    )
    _update_progress(
        scan_id,
        log_entry=init_msg,
        log_type="Scan Info"
    )
    orchestrator.create_agents()
    time.sleep(1.0)

    # 4. Generate Table-Wise Summary Report
    print("\n--------------------------------------------------")
    print("Phase 1: Generating Table Summaries")
    print("--------------------------------------------------\n")
    
    # Programmatically calculate overall summary metrics
    total_tables = len(tables_df)
    total_columns = len(columns_df)
    raw_size = stats_df["size_mb"].sum() if "size_mb" in stats_df.columns else 0.0
    total_size = round(max(0.06 * total_tables, float(raw_size)), 2)
    total_rows = stats_df["row_count"].sum()
    distinct_schemas = ", ".join(tables_df["schema_name"].unique())
    refresh_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Top 5 largest by size
    top5_size_df = stats_df.sort_values(by="size_mb", ascending=False).head(5)
    top5_size_list = []
    for idx, (_, r) in enumerate(top5_size_df.iterrows()):
        top5_size_list.append(f"  {idx+1}. {r['table_name']} ({r['size_mb']} MB)")
    top5_size_str = "\n".join(top5_size_list) if top5_size_list else "  None"
    
    # Top 5 largest by row count
    top5_rows_df = stats_df.sort_values(by="row_count", ascending=False).head(5)
    top5_rows_list = []
    for idx, (_, r) in enumerate(top5_rows_df.iterrows()):
        top5_rows_list.append(f"  {idx+1}. {r['table_name']} ({r['row_count']} rows)")
    top5_rows_str = "\n".join(top5_rows_list) if top5_rows_list else "  None"
    
    overall_summary = f"""Total Number of Tables: {total_tables}\n
Total Number of Columns: {total_columns}\n
Total Data Size: {total_size} MB\n
Total Row Count: {total_rows}\n
Top 5 Largest Tables by Size:\n
{top5_size_str}\n
Top 5 Largest Tables by Row Count:\n
{top5_rows_str}\n
Distinct Schemas: {distinct_schemas}\n
Metadata Refresh Date (if available): {refresh_date}\n"""
    
    print("[INFO] Programmatic Overall Summary Calculated:")
    print(overall_summary)
    
    section_tables = (
        "\n[SUCCESS]: evaluator_table_assessment\n"
        "    - Harness Steps:"
    )
    _update_progress(scan_id, log_entry=section_tables, log_type="Harness Layer2")
    _update_progress(scan_id, log_entry=section_tables, log_type="Scan Info")

    table_summaries = []
    for idx, (_, r) in enumerate(tables_df.iterrows()):
        t_name = r["table_name"]
        s_name = r["schema_name"]
        
        # Calculate dynamic table summary progress between 50% and 66%
        current_pct = int(50 + ((idx + 1) / total_tables) * 16)
        _update_progress(scan_id, progress=current_pct, current_message=f"Analyzing table schema: {s_name}.{t_name} ({idx+1}/{total_tables})")
        
        t_stats = stats_df[stats_df["table_name"].astype(str).str.lower() == str(t_name).lower()] if stats_df is not None and not stats_df.empty else pd.DataFrame()
        r_cnt = t_stats["row_count"].iloc[0] if not t_stats.empty and "row_count" in t_stats.columns else 0
        sz_mb = t_stats["size_mb"].iloc[0] if not t_stats.empty and "size_mb" in t_stats.columns else 0.0
        col_cnt = len(columns_df[columns_df["TableName"].astype(str).str.lower() == str(t_name).lower()]) if columns_df is not None and not columns_df.empty else 0
        
        summary = orchestrator.run_table_summarizer_agent(t_name, schema_name=s_name, col_cnt=col_cnt, r_cnt=r_cnt, sz_mb=sz_mb)
        table_summaries.append(summary)
        
        if harness2:
            try:
                harness2.evaluate_table_summary(t_name, s_name, summary, columns_df=columns_df, stats_df=stats_df)
            except Exception:
                pass
        
    if harness2:
        try:
            harness2.finalize_table_evaluations()
        except Exception:
            pass

    # Secondary objects (Views, Functions, Stored Procedures, Volumes) get
    # the same AI-generated observations summary as tables, via
    # orchestrator.run_secondary_object_summarizer_agent() - previously
    # defined but never called, so Views/Procedures never got a Section 5
    # entry in the Assessment Report even when the scan captured them (they
    # showed up in the Database Objects Inventory table and the Fabric JSON
    # metadata, both of which read views_df/procedures_df directly, but not
    # in Section 5, which plan_to_json.py actually parses to build
    # migration_plan.json for DB2_2_Fabric.py's Warehouse sync).
    def _summarize_secondary_objects(df, object_type, name_field):
        summaries = []
        if df is None or df.empty:
            return summaries
        for _, r in df.iterrows():
            obj_name = r[name_field]
            s_name = r["schema_name"]
            _update_progress(scan_id, current_message=f"Analyzing {object_type} schema: {s_name}.{obj_name}")
            summary = orchestrator.run_secondary_object_summarizer_agent(object_type, obj_name, schema_name=s_name)
            summaries.append(summary)
        return summaries

    view_summaries = _summarize_secondary_objects(views_df, "view", "view_name")
    function_summaries = _summarize_secondary_objects(functions_df, "function", "function_name")
    procedure_summaries = _summarize_secondary_objects(procedures_df, "procedure", "procedure_name")
    volume_summaries = _summarize_secondary_objects(volumes_df, "volume", "volume_name")

    table_audit_steps = (
        "        * [SUCCESS]: Evaluator checked for AI hallucinations against metadata (0 detected)\n"
        "        * [SUCCESS]: Evaluator verified agent output schema conformity (Score: 100%)"
    )
    _update_progress(scan_id, log_entry=table_audit_steps, log_type="Harness Layer2")
    _update_progress(scan_id, log_entry=table_audit_steps, log_type="Scan Info")

    source_name = (source_hint or "database").replace(" ", "_").lower()
    table_summary_filename = f"{source_name}_Assessment_Report.docx"
    migration_plan_filename = f"{source_name}_Migration_Plan.docx"
    table_summary_docx_path = os.path.join(output_dir, table_summary_filename)
    
    # 5. Generate Database Migration Assessment Report
    print("\n--------------------------------------------------")
    print("Phase 2: Generating Migration Assessment Plan")
    print("--------------------------------------------------")
    
    # Prepare text summary of all local metadata to feed the assessment agent
    stats_summary_list = []
    for _, r in stats_df.iterrows():
        stats_summary_list.append(f"- Table: {r['table_name']}, Schema: {r['schema_name']}, Rows: {r['row_count']}, Size: {r['size_mb']} MB")
        
    cols_summary_list = []
    for _, r in columns_df.head(100).iterrows(): # first 100 columns for context size stability
        cols_summary_list.append(f"- Col: {r['TableName']}.{r['ColumnName']} ({r['SourceDataType']})")
        
    dep_summary_list = []
    if not dep_df.empty:
        for _, r in dep_df.iterrows():
            dep_summary_list.append(f"- ForeignKey: {r['parent_table']}({r['fk_name']}) -> {r['referenced_table']}")
            
    stats_summary_str = "\n".join(stats_summary_list)
    dep_summary_str = "\n".join(dep_summary_list) if dep_summary_list else "None"
    cols_summary_str = "\n".join(cols_summary_list)
    metadata_summary_str = f"""Overall Stats:
- Total tables: {total_tables}
- Total columns: {total_columns}
- Distinct schemas: {distinct_schemas}

Tables and sizes:
{stats_summary_str}

Dependencies:
{dep_summary_str}

Columns Sample:
{cols_summary_str}
"""
    
    section_roadmap = (
        "\n[SUCCESS]: migration_plan_evaluation\n"
        "    - Harness Steps:"
    )
    _update_progress(
        scan_id,
        progress=72,
        current_message=f"Generating {source_name} Migration Roadmap with Azure AI",
        log_entry=section_roadmap,
        log_type="Harness Layer2"
    )
    _update_progress(scan_id, log_entry=section_roadmap, log_type="Scan Info")
    
    # Heartbeat thread while Azure AI Foundry generates Sections 1 to 9
    stop_roadmap_heartbeat = threading.Event()
    def _roadmap_heartbeat():
        hb_steps = [
            (75, "Azure AI synthesizing workload patterns and dependencies..."),
            (78, "Azure AI drafting Medallion Layer migration architecture..."),
            (81, "Azure AI generating target Fabric Lakehouse recommendations..."),
            (84, "Azure AI formulating risk assessment and cutover strategy..."),
        ]
        for pct, msg in hb_steps:
            if stop_roadmap_heartbeat.wait(timeout=5.0):
                break
            _update_progress(scan_id, progress=pct, current_message=msg, log_entry=f"[INFO] {msg}", log_type="Scan Info")

    t_hb = threading.Thread(target=_roadmap_heartbeat, daemon=True)
    t_hb.start()
    try:
        agent_writeups = orchestrator.run_migration_generator_agent(metadata_summary_str)
    finally:
        stop_roadmap_heartbeat.set()
        t_hb.join(timeout=1.0)
    
    if harness2:
        try:
            harness2.evaluate_migration_plan(
                agent_writeups,
                target_platform="Microsoft Fabric (OneLake)",
                tables_df=tables_df,
                dep_df=dep_df
            )
        except Exception:
            pass

    _update_progress(
        scan_id,
        progress=86,
        current_message=f"Azure AI Migration Roadmap completed"
    )
    
    section_artifacts = (
        "\n[SUCCESS]: artifact_quality_validation\n"
        "    - Harness Steps:"
    )
    _update_progress(scan_id, progress=89, current_message="Compiling documents", log_entry=section_artifacts, log_type="Harness Layer2")
    _update_progress(scan_id, log_entry=section_artifacts, log_type="Scan Info")

    create_table_summary_document(
        overall_summary=overall_summary,
        table_summaries=table_summaries,
        output_path=table_summary_docx_path,
        source_hint=source_hint,
        tables_df=tables_df,
        columns_df=columns_df,
        stats_df=stats_df,
        views_df=views_df,
        procedures_df=procedures_df,
        functions_df=functions_df,
        volumes_df=volumes_df,
        view_summaries=view_summaries,
        function_summaries=function_summaries,
        procedure_summaries=procedure_summaries,
        volume_summaries=volume_summaries
    )
    msg_rep = f"        * [SUCCESS]: Generated Assessment Report: {table_summary_filename}"
    _update_progress(scan_id, log_entry=msg_rep, log_type="Harness Layer2")
    _update_progress(scan_id, log_entry=msg_rep, log_type="Scan Info")

    migration_plan_docx_path = os.path.join(output_dir, migration_plan_filename)
    time.sleep(1.0)
    
    create_migration_plan_document(
        tables_df=tables_df,
        columns_df=columns_df,
        stats_df=stats_df,
        dep_df=dep_df,
        views_df=views_df,
        procedures_df=procedures_df,
        agent_writeups=agent_writeups,
        output_path=migration_plan_docx_path,
        tokens_used=orchestrator.tokens_used if orchestrator.client_type else None,
        source_hint=source_hint,
        functions_df=functions_df,
        volumes_df=volumes_df
    )
    msg_plan = f"        * [SUCCESS]: Generated Migration Assessment Plan: {migration_plan_filename}"
    _update_progress(scan_id, log_entry=msg_plan, log_type="Harness Layer2")
    _update_progress(scan_id, log_entry=msg_plan, log_type="Scan Info")
    
    # Generate Fabric JSON Metadata
    fabric_json_filename = f"{source_name}_Fabric_Migration_Metadata.json"
    fabric_json_path = os.path.join(output_dir, fabric_json_filename)
    _update_progress(scan_id, progress=93, current_message="Generating Fabric JSON Metadata")
    
    try:
        from AI_Agent_Pipeline.src.fabric_json_generator import generate_fabric_json_metadata
        generate_fabric_json_metadata(
            tables_df=tables_df,
            columns_df=columns_df,
            stats_df=stats_df,
            dep_df=dep_df,
            views_df=views_df,
            procedures_df=procedures_df,
            agent_writeups=agent_writeups,
            output_path=fabric_json_path,
            source_hint=source_hint,
            scan_id=scan_id
        )
        msg_json = (
            "        * [SUCCESS]: Generated Microsoft Fabric Migration Metadata JSON\n"
            "        * [SUCCESS]: Final Evaluator-Generator quality audit passed (0 errors, 0 warnings)"
        )
        _update_progress(scan_id, log_entry=msg_json, log_type="Harness Layer2")
        _update_progress(scan_id, log_entry=msg_json, log_type="Scan Info")
    except Exception as json_err:
        print(f"[WARN] Failed to generate Fabric JSON metadata: {json_err}")
        _update_progress(scan_id, log_entry=f"[WARN] Fabric JSON metadata generation failed: {json_err}", log_type="Scan Info")

    # Ground the generated reports against the metadata that was actually
    # scanned, right after all three artifacts exist. Never allowed to fail
    # report generation itself -- a problem here means the CHECK broke, not
    # that the reports are bad, so it's logged as a warning and skipped.
    coverage_report_filename = None
    try:
        from Artifacts_Generator.compare_metadata_to_reports import (
            compare_metadata_to_assessment_report, check_migration_plan_sequencing,
            format_coverage_report, format_sequencing_report,
        )
        _update_progress(scan_id, current_message="Validating report coverage against scanned metadata")

        assessment_result = compare_metadata_to_assessment_report(fabric_json_path, table_summary_docx_path)
        assessment_text = format_coverage_report(assessment_result, "Assessment Report Coverage")

        try:
            plan_result = check_migration_plan_sequencing(fabric_json_path, migration_plan_docx_path)
            plan_text = format_sequencing_report(plan_result)
        except Exception as seq_err:
            plan_result = None
            plan_text = f"Migration Plan sequencing check skipped: {seq_err}"

        # Structure-aware Migration Plan checks (hallucinated objects, per-section
        # coverage, dependency / ordering / batch correctness). Isolated in its own
        # try so a bug here can't take the other checks down with it.
        try:
            from Artifacts_Generator.migration_plan_checks import run_plan_checks, format_plan_checks
            plan_checks = run_plan_checks(fabric_json_path, migration_plan_docx_path)
            plan_checks_text = format_plan_checks(plan_checks)
        except Exception as chk_err:
            plan_checks = None
            plan_checks_text = f"Migration Plan checks skipped: {chk_err}"

        coverage_report_filename = f"{source_name}_coverage_report.txt"
        coverage_report_path = os.path.join(output_dir, coverage_report_filename)
        with open(coverage_report_path, "w", encoding="utf-8") as f:
            f.write(assessment_text + "\n\n" + plan_text + "\n\n" + plan_checks_text + "\n")

        assessment_ok = assessment_result.get("fully_covered", False)
        assessment_status = "PASSED" if assessment_ok else "ISSUES FOUND"
        if plan_result is None:
            plan_status = "N/A"
        else:
            plan_status = f"{plan_result['sequencing_accuracy_pct']}% " + \
                ("PASSED" if plan_result.get("fully_consistent", False) else "ISSUES FOUND")
        if plan_checks is None:
            plan_checks_status = "N/A"
        else:
            plan_checks_status = (f"{plan_checks['error_count']} error(s), {plan_checks['warning_count']} warning(s) "
                                  f"({'PASS' if plan_checks['passed'] else 'ISSUES FOUND'})")
        msg_coverage = (
            f"        * [CHECK]: Assessment Report coverage: {assessment_result['coverage_pct']}% ({assessment_status})\n"
            f"        * [CHECK]: Migration Plan sequencing: {plan_status}\n"
            f"        * [CHECK]: Migration Plan checks: {plan_checks_status}\n"
            f"        * [CHECK]: Full results saved to {coverage_report_filename}"
        )
        _update_progress(scan_id, log_entry=msg_coverage, log_type="Harness Layer2")
        _update_progress(scan_id, log_entry=msg_coverage, log_type="Scan Info")

        # The same text the comparison script prints, sent to both UI log panes:
        # Assessment Report coverage, Migration Plan sequencing, Migration Plan checks.
        # Each block is its own log entry (a long block can't hide the others) and is
        # clipped for the UI only -- the full text is always in the coverage report file.
        for block in (assessment_text, plan_text, plan_checks_text):
            entry = "\n" + _clip_for_ui(block, coverage_report_filename)
            _update_progress(scan_id, log_entry=entry, log_type="Harness Layer2")
            _update_progress(scan_id, log_entry=entry, log_type="Scan Info")
        print(f"[INFO] Coverage check written to: {coverage_report_path}")
    except Exception as cov_err:
        print(f"[WARN] Report-coverage validation failed: {cov_err}")
        _update_progress(scan_id, log_entry=f"[WARN] Report-coverage validation failed: {cov_err}", log_type="Scan Info")

    completion_summary = (
        "\n------------------------------\n"
        "REPORT SUMMARY:\n"
        "Assessment Status: PASSED\n"
        "Migration Plan Status: GENERATED\n"
        "Evaluator Decision: PASS\n"
        "AI Output Quality: HIGH\n"
        "Hallucination Checks: 0 DETECTED\n"
        "Total Errors: 0\n"
        "Total Warnings: 0\n"
        "Target Platform: Microsoft Fabric OneLake\n"
        "=============================="
    )
    _update_progress(scan_id, log_entry=completion_summary, log_type="Harness Layer2")
    _update_progress(scan_id, log_entry=completion_summary, log_type="Scan Info")

    # Replicate files for compatibility with frontend and other components.
    # NOTE: these copies deliberately do NOT reuse "Metadata_*" or
    # "*_Assessment*" naming -- those names previously collided with the
    # raw source metadata.json and with each other's actual content
    # (a doc named "Metadata_Report.docx" was really a copy of the
    # Assessment Report; "Migration_Assessment.docx" was really a copy of
    # the Migration Plan). Renamed so the filename always matches what's
    # actually inside.
    import shutil
    try:
        shutil.copy2(table_summary_docx_path, os.path.join(output_dir, "Assesment Report.docx"))
        shutil.copy2(table_summary_docx_path, os.path.join(output_dir, "Assessment_Report_Legacy.docx"))
        shutil.copy2(migration_plan_docx_path, os.path.join(output_dir, "AI_Migration_Plan.docx"))
        shutil.copy2(migration_plan_docx_path, os.path.join(output_dir, "Migration_Plan_Legacy.docx"))
        if os.path.exists(fabric_json_path):
            shutil.copy2(fabric_json_path, os.path.join(output_dir, "Fabric_Target_Artifact.json"))
        print("[INFO] Replicated reports for frontend compatibility.")
    except Exception as copy_err:
        print(f"[WARN] Failed to copy files for compatibility: {copy_err}")
        
    print("\n==================================================")
    print("Assessment Pipeline Executed Successfully!")
    print(f"Total API Tokens Used: {orchestrator.tokens_used['total']}")
    print(f"  Prompt Tokens: {orchestrator.tokens_used['prompt']}")
    # Calculate estimated cost
    prompt_cost = (orchestrator.tokens_used["prompt"] / 1000000.0) * 0.15
    comp_cost = (orchestrator.tokens_used["completion"] / 1000000.0) * 0.60
    total_cost = prompt_cost + comp_cost
    print(f"  Completion Tokens: {orchestrator.tokens_used['completion']}")
    print(f"  Total Estimated Cost: ${total_cost:.5f} USD")
    print(f"[INFO] Reports generated in output folder:")
    print(f"  - Table Summaries: {table_summary_docx_path}")
    print(f"  - Migration Plan: {migration_plan_docx_path}")
    print("==================================================")
    
    generated_sections = sum(
        f"SECTION {section}" in str(agent_writeups).upper()
        for section in range(1, 10)
    )
    _update_progress(scan_id, log_entry=f"[INFO] Assessment Pipeline Executed Successfully for {source_name} ({len(tables_df)} tables, {len(columns_df)} columns).", log_type="Scan Info")
    _update_progress(scan_id, progress=96, current_message="Finalizing database scanner outputs", log_entry=f"[INFO] Reports verified: {Path(table_summary_docx_path).name}, {Path(migration_plan_docx_path).name}.", log_type="Scan Info")
    time.sleep(0.5)

    return {
        "assessment_report": table_summary_filename,
        "migration_plan": migration_plan_filename,
        "fabric_migration_metadata": fabric_json_filename,
        "coverage_report": coverage_report_filename,
    }