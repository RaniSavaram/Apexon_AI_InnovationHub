import json
import os
import time
import traceback
from pathlib import Path
from threading import Lock, Thread
from uuid import uuid4

from django.http import FileResponse, Http404
from rest_framework.decorators import api_view
from rest_framework.response import Response

from config.Credentials import PrivateVariables
from Migrator.connection_store import save_connection, get_saved_connection, get_saved_connections
from Migrator.er_diagram import build_er_model
from Metadata_Scanner.extractors.sqlserver import SQLServerExtractor
#from Metadata_Scanner.extractors.oracle import OracleExtractor
#from Metadata_Scanner.extractors.mysql import MySQLExtractor
#from Metadata_Scanner.extractors.postgres import PostgreSQLExtractor
#from Metadata_Scanner.extractors.sqlite import SQLiteExtractor
from Metadata_Scanner.extractors.synapse import SynapseExtractor
from Metadata_Scanner.extractors.snowflake_extractor import SnowflakeExtractor
from Metadata_Scanner.extractors.databricks_client import DatabricksExtractor
from Metadata_Scanner.extractors.dynamics365 import Dynamics365Extractor
#from Metadata_Scanner.extractors.sap import SAPExtractor
from AI_Agent_Pipeline.Agents_PipeLine import Agents_PipeLine
from HarnessLayers.layer1.Layer import layer1_Harness
from HarnessLayers.Harness_Json_Log_Formatter import format_harness_report
from Logs import Logs,reset_Logs

DEFAULT_HARNESS_LAYER2_LOGS = [
    "HARNESS LAYER 2:",
    "Waiting for the AI assessment and migration report generation to finish.",
]

Creds = PrivateVariables()
source = None
scan_jobs = {}
scan_jobs_lock = Lock()
import threading
thread_local = threading.local()
MAX_SCAN_TABLES = int(os.environ.get("MAX_SCAN_TABLES", "5"))


def _limit_metadata_tables(metadata, max_tables=None):
    """
    Caps physical/base tables to max_tables (default MAX_SCAN_TABLES = 5) across all schemas,
    while keeping all views, stored procedures, functions, and volumes completely intact.
    """
    if max_tables is None:
        max_tables = MAX_SCAN_TABLES

    budget = max_tables
    kept_base_tables_count = 0
    limited_schemas = []

    for schema in metadata.get("schemas", []):
        all_tables = schema.get("tables", [])
        limited_tables = []
        for table in all_tables:
            is_view = (table.get("type") or "").upper() in ("VIEW", "MATERIALIZED VIEW")
            if is_view:
                # Retain all views
                limited_tables.append(table)
            else:
                # Cap base tables to budget
                if kept_base_tables_count < budget:
                    limited_tables.append(table)
                    kept_base_tables_count += 1

        all_procedures = schema.get("procedures", [])
        all_functions = schema.get("functions", [])
        all_volumes = schema.get("volumes", [])

        # Include schema if it has any tables, views, procedures, functions, or volumes
        if limited_tables or all_procedures or all_functions or all_volumes:
            limited_schema = dict(schema)
            limited_schema["tables"] = limited_tables
            limited_schema["procedures"] = list(all_procedures)
            limited_schema["functions"] = list(all_functions)
            limited_schema["volumes"] = list(all_volumes)
            limited_schemas.append(limited_schema)

    limited_metadata = dict(metadata)
    limited_metadata["schemas"] = limited_schemas
    return limited_metadata


def _push_databricks_to_fabric(output_files, database_name):
    """
    Converts the just-generated Assessment Report + Migration Plan docx
    into migration_plan.json and pushes it straight into the pre-provisioned
    "Databricks_Lakehouse" in Fabric via databricks2_fabric.py - no manual
    CLI step needed for databricks scans. Only called for db_type ==
    "databricks"; other sources aren't wired up to a real Fabric Lakehouse
    yet.

    Returns the dict databricks2_fabric.Generator() returns
    (status/processed/errors). Raises on failure - callers should catch and
    log rather than fail the scan, since the docx reports themselves
    already succeeded by the time this runs.
    """
    from Artifacts_Generator.plan_to_json import build_plan
    from Artifacts_Generator import databricks2_fabric

    output_dir = Path(__file__).resolve().parent.parent / "AI_Agent_Pipeline" / "output"
    assessment_path = output_dir / output_files["assessment_report"]
    migration_plan_path = output_dir / output_files["migration_plan"]

    plan = build_plan(
        assessment_path=assessment_path,
        migration_plan_path=migration_plan_path,
        source_system="databricks",
        database_name=database_name,
    )

    json_path = output_dir / "migration_plan.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(plan, f, indent=2, ensure_ascii=False)

    return databricks2_fabric.Generator(
        json_path=json_path,
        dry_run=False,
        database_name=database_name,
    )


def _scan_status(scan_id):
    with scan_jobs_lock:
        return scan_jobs.get(scan_id)


def get_progress_from_log(log_entry):
    if not log_entry or not isinstance(log_entry, str):
        return None
    # Multi-line reports (e.g. Harness Layer 1 validation report) should not trigger single-line progress steps
    if "\n" in log_entry or len(log_entry) > 200:
        return None
    log_lower = log_entry.lower().strip()
    if "scan started" in log_lower:
        return 5
    if "connecting to" in log_lower or "connecting to database" in log_lower:
        return 12
    if "extracting metadata" in log_lower:
        return 18
    if "selected" in log_lower and "tables for analysis" in log_lower:
        return 26
    if "running harnnes layer-1" in log_lower or "running harness layer 1" in log_lower:
        return 34
    if "harness layer 1 validation completed" in log_lower:
        return 42
    if "starting evaluator-generator agents" in log_lower or "creating agents" in log_lower:
        return 45
    if "evaluator-generator agents created" in log_lower:
        return 48
    if "running table summarizer agent" in log_lower:
        return 55
    if "generating assessment report" in log_lower or "compiling table assessment report" in log_lower:
        return 68
    if "generating comprehensive migration roadmap" in log_lower or ("generating" in log_lower and "migration roadmap" in log_lower):
        return 72
    if "azure ai synthesizing workload patterns" in log_lower:
        return 75
    if "azure ai drafting medallion layer" in log_lower:
        return 78
    if "azure ai generating target fabric lakehouse" in log_lower:
        return 81
    if "azure ai formulating risk assessment" in log_lower:
        return 84
    if "successfully received migration roadmap" in log_lower or "azure ai migration roadmap completed" in log_lower:
        return 86
    if "compiling execution order and medallion plan" in log_lower:
        return 89
    if "generating fabric migration metadata" in log_lower:
        return 93
    if "fabric push completed" in log_lower or "auto-pushing assessment to microsoft fabric" in log_lower:
        return 97
    if "output is avaliable" in log_lower or "reports verified" in log_lower or "finalizing reports" in log_lower:
        return 99
    if log_lower.endswith("scan completed successfully.") or log_lower == "scan completed successfully":
        return 100
    return None


def update_scan_job_state(scan_id=None, progress=None, current_message=None, log_entry=None, log_type="Scan Info", skip_global=False):
    if progress is None and log_entry and isinstance(log_entry, str):
        detected_progress = get_progress_from_log(log_entry)
        if detected_progress is not None:
            progress = detected_progress

    if log_entry:
        if not skip_global:
            if log_type in Logs:
                Logs[log_type].append(log_entry)
            if log_type == "Scan Info" and log_type not in Logs:
                Logs["Scan Info"].append(log_entry)

    if progress is not None and not skip_global:
        current_global = Logs.get("Progress Percentage", 0)
        if not isinstance(current_global, (int, float)) or progress > current_global:
            Logs["Progress Percentage"] = progress

    if not scan_id:
        return

    with scan_jobs_lock:
        job = scan_jobs.get(scan_id)
        if not job:
            return
        if progress is not None:
            current_job_progress = job.get("progress", 0)
            if not isinstance(current_job_progress, (int, float)) or progress > current_job_progress:
                job["progress"] = progress
            
        if current_message is not None:
            clean_msg = current_message.strip()
            # Strip trailing dots so badge always shows a complete sentence
            while clean_msg.endswith("."):
                clean_msg = clean_msg[:-1].strip()
            job["current_message"] = clean_msg

        if log_entry:
            target_list = None
            if log_type == "Scan Info":
                target_list = job["logs"]
            elif log_type == "Harness Layer1":
                target_list = job["harness1_logs"]
            elif log_type == "Harness Layer2":
                target_list = job["harness2_logs"]
            elif log_type == "Token Info":
                target_list = job["token_info"]

            if target_list is not None:
                if not target_list or target_list[-1] != log_entry:
                    target_list.append(log_entry)


def _run_scan_in_background(scan_id, destination):
    try:
        thread_local.active_scan_id = scan_id
        job = None
        with scan_jobs_lock:
            job = scan_jobs.get(scan_id)
        job_source = job.get("source") if job else None
        
        # Pass scan_id down to _run_scan
        result = _run_scan(destination, job_source, scan_id)
        status = "Completed" if result.status_code < 400 else "Failed"
        error = result.data.get("message") if status == "Failed" else None
        result_data = dict(result.data)
    except Exception as exc:
        status = "Failed"
        error = str(exc)
        result_data = {}
        update_scan_job_state(scan_id, log_entry=f"[ERROR] Scan failed: {exc}", log_type="Scan Info")
        update_scan_job_state(scan_id, log_entry=traceback.format_exc(), log_type="Scan Info")
        update_scan_job_state(scan_id, log_entry=f"[FAILED] Scan stopped during Layer 2 or report generation: {exc}", log_type="Harness Layer2")

    with scan_jobs_lock:
        job = scan_jobs.get(scan_id)
        if job:
            job.update({
                "status": status,
                "error": error,
                "result": result_data,
                "phase": "completed" if status == "Completed" else "failed",
                "progress": 100 if status == "Completed" else job.get("progress", 0),
                "current_message": "Scan completed successfully." if status == "Completed" else "Scan failed."
            })


@api_view(["GET"])
def scan_status(request, scan_id):
    scan_id_str = str(scan_id)
    job = _scan_status(scan_id_str)
    if not job:
        return Response({"status": "Failed", "error": "Scan not found."}, status=404)

    response = {
        "status": job["status"],
        "progressbar": job.get("progress", 0),
        "scan_status_message": job.get("current_message", ""),
        "Logs": {
            "Token Info": job.get("token_info", []),
            "Scan Info": job.get("logs", []),
            "Harness Layer1": job.get("harness1_logs", []),
            "Harness Layer2": job.get("harness2_logs", []) or DEFAULT_HARNESS_LAYER2_LOGS,
        },
        "result": job.get("result"),
        "error": job.get("error")
    }
    return Response(response)


def serve_generated_document(request, filename):
    """Serve generated DOCX reports from the AI_Agent_Pipeline output folder."""
    output_dir = Path(__file__).resolve().parent.parent / "AI_Agent_Pipeline" / "output"
    file_path = (output_dir / filename).resolve()
    try:
        file_path.relative_to(output_dir.resolve())
    except ValueError as exc:
        raise Http404("Invalid file path.") from exc

    if file_path.suffix.lower() != ".docx" or not file_path.is_file():
        raise Http404("Document not found.")

    if request.GET.get("view") == "1":
        host = request.get_host()
        if "localhost" not in host and "127.0.0.1" not in host:
            from django.http import HttpResponseRedirect
            import urllib.parse
            public_url = request.build_absolute_uri(request.path)
            if public_url.startswith("http://"):
                public_url = "https://" + public_url[7:]
            viewer_url = f"https://view.officeapps.live.com/op/view.aspx?src={urllib.parse.quote(public_url)}"
            return HttpResponseRedirect(viewer_url)

    response = FileResponse(file_path.open("rb"), content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    disposition = "inline" if request.GET.get("view") == "1" else "attachment"
    response["Content-Disposition"] = f'{disposition}; filename="{file_path.name}"'
    response["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response["Pragma"] = "no-cache"
    response["Expires"] = "0"
    return response


@api_view(["GET"])
def er_diagram(request):
    """
    Entity-relationship model for the UI's "ER Diagrams" tab, built from a
    finished scan's Fabric metadata JSON (see Migrator/er_diagram.py).
    ?file= is the "fabric_migration_metadata" name Agents_PipeLine returns
    in output_files; it defaults to the copy of the most recent scan.
    """
    output_dir = (Path(__file__).resolve().parent.parent / "AI_Agent_Pipeline" / "output").resolve()
    filename = request.GET.get("file") or "Fabric_Migration_Metadata.json"
    file_path = (output_dir / filename).resolve()
    if file_path.parent != output_dir or not file_path.name.endswith("Fabric_Migration_Metadata.json"):
        return Response({"status": "error", "message": "Invalid metadata file."}, status=400)
    if not file_path.is_file():
        return Response({"status": "error", "message": f"{filename} not found - run a scan first."}, status=404)

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            model = build_er_model(json.load(f))
    except Exception as exc:
        return Response({"status": "error", "message": f"Could not build the ER diagram: {exc}"}, status=500)
    return Response({"status": "success", "file": file_path.name, **model})


def _get_connection_log_lines(db_type, creds):
    lines = []
    db_type_lower = (db_type or "").lower().replace(" ", "").replace("_", "")
    server = creds.get_servername()
    database = creds.get_database_name()
    username = creds.get_username()
    extra = creds.get_extra_dict() or {}

    if db_type_lower == "snowflake":
        account = extra.get("account") or server
        warehouse = extra.get("warehouse")
        role = extra.get("role")
        if account:
            lines.append(f"Account   : {repr(account)}")
        if database:
            lines.append(f"Database  : {repr(database)}")
        if warehouse:
            lines.append(f"Warehouse : {repr(warehouse)}")
        if username:
            lines.append(f"User      : {repr(username)}")
        if role:
            lines.append(f"Role      : {repr(role)}")
    elif db_type_lower == "databricks":
        catalog = database
        http_path = extra.get("http_path")
        if server:
            lines.append(f"Server   : {repr(server)}")
        if catalog:
            lines.append(f"Catalog  : {repr(catalog)}")
        if http_path:
            lines.append(f"HTTP Path: {repr(http_path)}")
        if username:
            lines.append(f"User     : {repr(username)}")
    elif db_type_lower in ("dynamics365", "dynamics 365", "d365", "dynamics"):
        if server:
            lines.append(f"Org URL  : {repr(server)}")
    elif db_type_lower == "sqlite":
        if database:
            lines.append(f"Database : {repr(database)}")
    else:
        if server:
            lines.append(f"Server   : {repr(server)}")
        if database:
            lines.append(f"Database : {repr(database)}")
        if username:
            lines.append(f"User     : {repr(username)}")
    return lines


@api_view(["POST"])
def connect_database(request):

    global source
    reset_Logs()

    print("[INFO]: Connect request received")
    Logs["Scan Info"].append("[INFO]: Connect request received")

    source = request.data.get("source")
    clean_source = (source or "").strip().lower().replace(" ", "").replace("_", "")
    remember_me = str(request.data.get("remember_me", "false")).strip().lower() == "true"
    Creds.set_servername(request.data.get("server"))
    Creds.set_database_name(request.data.get("database"))
    Creds.set_username (request.data.get("username"))
    Creds.set_password (request.data.get("password"))
    Creds.set_port(request.data.get("port") or None)
    Creds.set_extra_dict(request.data.get("extra") or {})
    print("[INFO]: Connection Details recieved")
    Logs["Scan Info"].append("[INFO]: Connection Details recieved")
    for conn_line in _get_connection_log_lines(source, Creds):
        Logs["Scan Info"].append(conn_line)

    try:
        server = Creds.get_servername()
        database = Creds.get_database_name()

        # Field requirements differ by DB type family:
        #   - SQLite: only needs a file path (in `database`)
        #   - Dynamics 365: needs the org URL (in `server`) + tenant/client
        #     id/secret in `extra` - no `database`/username/password
        #   - Everything else: needs both server and database
        if clean_source == "sqlite":
            if not database:
                Logs["Scan Info"].append("[Err]: Database file path is required.")
                return Response(
                    {"status": "error", "message": "Database file path is required."},
                    status=400
                )
        elif clean_source in ("dynamics365", "dynamics 365", "d365", "dynamics"):
            if not server:
                Logs["Scan Info"].append("[Err]: Org URL is required.")
                return Response(
                    {"status": "error", "message": "Org URL (Server field) is required."},
                    status=400
                )
        elif not server or not database:
            Logs["Scan Info"].append("[Err]: Server or database name are required.")
            return Response(
                {"status": "error", "message": "Server and database name are required."},
                status=400
            )

        db_type = clean_source

        if db_type in ("sqlserver", "mssql"):
            test_extractor = SQLServerExtractor(Creds)

        elif db_type in ("synapse", "azuresynapse"):
            test_extractor = SynapseExtractor(Creds)

        elif db_type == "snowflake":
            test_extractor = SnowflakeExtractor(Creds)

        elif db_type == "databricks":
            test_extractor = DatabricksExtractor(Creds)

        elif db_type in ("dynamics365", "dynamics 365", "d365", "dynamics"):
            test_extractor = Dynamics365Extractor(Creds)

        elif db_type == "sqlite":
            # SQLite uses local file, bypass connect check
            test_extractor = None

        else:
            Logs["Scan Info"].append(f"[Err]: Unsupported database type: '{source}'")
            return Response(
                {
                    "status": "error",
                    "message": (
                        f"Unsupported database type: '{source}'. Supported: sqlserver, "
                        f"oracle, mysql, postgres, sqlite, synapse, snowflake, "
                        f"databricks, dynamics365, sap"
                    )
                },
                status=400
            )

        if test_extractor:
            test_extractor.connect()
            print("[INFO]: Successfully Connected To the Database")
            Logs["Scan Info"].append("[INFO]: Successfully Connected To the Database")
            test_extractor.close()
        else:
            print("[INFO]: Successfully Connected To the Database")
            Logs["Scan Info"].append("[INFO]: Successfully Connected To the Database")

        # Remember-me is now handled on the browser side with localStorage so
        # credentials are never stored in the repo or committed to GitHub.
        # The backend only writes to a temp file when explicitly requested.
        if remember_me:
            save_connection(source, {
                "server": server,
                "database": database,
                "username": Creds.get_username(),
                "password": Creds.get_password(),
                "extra": Creds.get_extra_dict(),
            })

    except Exception as e:
         print(e)
         Logs["Scan Info"].append(str(e))
         return Response({"status": "error", "message": str(e)}, status=400)

    
    Logs["Scan Info"].append(f"[INFO] Connected to {database} on {server} successfully.")
    return Response({
        "status": "success",
        "message": f"Connected to {database} on {server} successfully.",
        "source": source,
        "Logs":Logs
    })

@api_view(["GET"])
def saved_connection(request):
    src = request.query_params.get("source")
    if not src:
        return Response(
            {"status": "error", "message": "Query param 'source' is required."},
            status=400
        )

    saved = get_saved_connection(src)
    if not saved:
        return Response({"status": "success", "found": False})

    return Response({"status": "success", "found": True, "connection": saved})


@api_view(["GET"])
def saved_connections(request):
    """Returns every saved profile for a source (e.g. all known Databricks
    servers), so the frontend can offer a picker instead of a single
    pre-filled form."""
    src = request.query_params.get("source")
    if not src:
        return Response(
            {"status": "error", "message": "Query param 'source' is required."},
            status=400
        )

    return Response({
        "status": "success",
        "connections": get_saved_connections(src),
    })


@api_view(["GET", "POST"])
def Db_Scanner(request):
    scan_id = str(uuid4())
    destination = request.data.get("destination")
    req_source = request.data.get("source") or source

    if request.data.get("server"):
        Creds.set_servername(request.data.get("server"))
    if request.data.get("database"):
        Creds.set_database_name(request.data.get("database"))
    if request.data.get("username"):
        Creds.set_username(request.data.get("username"))
    if request.data.get("password"):
        Creds.set_password(request.data.get("password"))
    if request.data.get("port"):
        Creds.set_port(request.data.get("port"))
    if request.data.get("extra"):
        Creds.set_extra_dict(request.data.get("extra"))

    with scan_jobs_lock:
        scan_jobs[scan_id] = {
            "status": "Running",
            "source": req_source,
            "destination": destination,
            "scan_id": scan_id,
            "error": None,
            "phase": "starting",
            "progress": 5,
            "current_message": "Initializing scan",
            "logs": ["[INFO] Scan job initialized."],
            "harness1_logs": [],
            "harness2_logs": [],
            "token_info": []
        }

    Thread(target=_run_scan_in_background, args=(scan_id, destination), daemon=True).start()
    return Response({
        "status": "started",
        "message": "Database scan started.",
        "scan_id": scan_id,
    }, status=202)


def get_db_display_name(source_slug):
    mapping = {
        "sqlserver": "SQL Server",
        "mssql": "SQL Server",
        "oracle": "Oracle",
        "mysql": "MySQL",
        "postgres": "PostgreSQL",
        "postgresql": "PostgreSQL",
        "sqlite": "SQLite",
        "synapse": "Azure Synapse",
        "azuresynapse": "Azure Synapse",
        "snowflake": "Snowflake",
        "databricks": "Databricks",
        "dynamics365": "Dynamics 365",
        "d365": "Dynamics 365",
        "dynamics": "Dynamics 365",
        "sap": "SAP HANA",
        "saphana": "SAP HANA"
    }
    clean = str(source_slug or "").strip().lower().replace(" ", "").replace("_", "")
    return mapping.get(clean, str(source_slug) or "Database")


def _run_scan(destination, scan_source=None, scan_id=None):

    # Some DB types don't populate both fields: SQLite has no server (just
    # a database file path), Dynamics 365 has no database (just an org
    # URL in server). Require at least one to confirm a connect happened.
    if not Creds.get_servername() and not Creds.get_database_name():
        return Response(
            {
                "status": "error",
                "message": "Connect to the database first."
            },
            status=400
        )
    
    db_clean = (scan_source or source or "").strip().lower().replace(" ", "").replace("_", "")
    db_name = get_db_display_name(db_clean)
    scan_started_msg = f"[INFO] {db_name} scan started for database '{Creds.get_database_name()}'."
    update_scan_job_state(scan_id, progress=5, current_message=f"Starting {db_name} scan...", log_entry=scan_started_msg)
    print(scan_started_msg)
    time.sleep(0.5)

    if db_clean in ("sqlserver", "mssql"):
        obj = SQLServerExtractor(Creds)

    elif db_clean in ("synapse", "azuresynapse"):
        obj = SynapseExtractor(Creds)

    elif db_clean == "snowflake":
        obj = SnowflakeExtractor(Creds)

    elif db_clean == "databricks":
        obj = DatabricksExtractor(Creds)

    elif db_clean in ("dynamics365", "dynamics 365", "d365", "dynamics"):
        obj = Dynamics365Extractor(Creds)

    else:
        update_scan_job_state(scan_id, log_entry=f"[ERROR] Unsupported database type: '{source}'.")
        return Response(
                {
                    "status": "error",
                    "message": (
                        f"Unsupported database type: '{source}'. Supported: sqlserver, "
                        f"oracle, mysql, postgres, sqlite, synapse, snowflake, "
                        f"databricks, dynamics365, sap"
                    )
                },
                status=400
            )
    try:
        connecting_msg = f"[INFO] Connecting to {db_name}..."
        update_scan_job_state(scan_id, progress=12, current_message=f"Connecting to {db_name}...", log_entry=connecting_msg)
        print(connecting_msg)

        extracting_msg = f"[INFO] Extracting schema and table metadata from {db_name}..."
        update_scan_job_state(scan_id, progress=18, current_message=f"Extracting {db_name} schema and table metadata...", log_entry=extracting_msg)
        print(extracting_msg)
        for conn_line in _get_connection_log_lines(db_clean, Creds):
            update_scan_job_state(scan_id, log_entry=conn_line)
        metadata = obj.extract()

        def _count_schema_objects(meta):
            schemas = meta.get("schemas", [])
            t_cnt = sum(
                1 for s in schemas for t in s.get("tables", [])
                if (t.get("type") or "").upper() not in ("VIEW", "MATERIALIZED VIEW")
            )
            v_cnt = sum(
                1 for s in schemas for t in s.get("tables", [])
                if (t.get("type") or "").upper() in ("VIEW", "MATERIALIZED VIEW")
            )
            p_cnt = sum(len(s.get("procedures", [])) for s in schemas)
            f_cnt = sum(len(s.get("functions", [])) for s in schemas)
            return t_cnt, v_cnt, p_cnt, f_cnt

        orig_tables, orig_views, orig_procs, orig_funcs = _count_schema_objects(metadata)

        # Cap physical tables to 5 (MAX_SCAN_TABLES) while leaving all views, stored procedures,
        # functions, and volumes untouched.
        # Snowflake and Dynamics 365 scans keep full schemas.
        if db_clean not in ("snowflake", "dynamics365", "dynamics 365", "d365"):
            metadata = _limit_metadata_tables(metadata, max_tables=5)

        selected_tables, selected_views, selected_procs, selected_funcs = _count_schema_objects(metadata)

        def _format_summary(t, v, p, f):
            parts = [f"{t} table{'s' if t != 1 else ''}"]
            if v > 0:
                parts.append(f"{v} view{'s' if v != 1 else ''}")
            if p > 0:
                parts.append(f"{p} stored procedure{'s' if p != 1 else ''}")
            if f > 0:
                parts.append(f"{f} function{'s' if f != 1 else ''}")
            return ", ".join(parts)

        selected_summary = _format_summary(selected_tables, selected_views, selected_procs, selected_funcs)

        if (orig_tables, orig_views, orig_procs, orig_funcs) != (selected_tables, selected_views, selected_procs, selected_funcs):
            orig_summary = _format_summary(orig_tables, orig_views, orig_procs, orig_funcs)
            selection_log = f"[INFO] Selected {selected_summary} for this scan (out of {orig_summary} available)."
        else:
            selection_log = f"[INFO] Extracted {selected_summary} from {db_name}."

        update_scan_job_state(scan_id, progress=26, current_message=f"Analyzing {selected_summary} from {db_name}...", log_entry="[INFO] Analyzing extracted schemas and objects")
        update_scan_job_state(scan_id, progress=32, current_message=f"{db_name} metadata extracted ({selected_summary})", log_entry=selection_log)
        time.sleep(0.5)

        harness_start_msg = f"[INFO] {db_name} metadata extracted. Running Harness Layer 1 validation..."
        update_scan_job_state(scan_id, progress=38, current_message=f"Running {db_name} Harness Layer 1 validation", log_entry=f"\n{'=' * 60}\n{harness_start_msg}\n{'=' * 60}")
        print(harness_start_msg)
        time.sleep(1.0)
        layer_result = layer1_Harness(metadata)
        temp = format_harness_report(layer_result)

        update_scan_job_state(scan_id, progress=42, current_message=f"{db_name} Harness Layer 1 validation completed", log_entry=temp, log_type="Scan Info")
        update_scan_job_state(scan_id, log_entry=temp, log_type="Harness Layer1")
        print(temp)
        time.sleep(0.8)

        if layer_result.get("decision") != "PASS":
            blocked_msg = "[ERROR] Destructive SQL (DDL/DML) statement identified in the scanned metadata - stopping before generating the Assessment Report / Migration Plan."
            update_scan_job_state(scan_id, log_entry=blocked_msg)
            print(blocked_msg)
            return Response(
                {
                    "status": "error",
                    "message": "Destructive SQL (DDL/DML) statement identified - stopping before generating the Assessment Report / Migration Plan.",
                    "source": source,
                    "destination": destination,
                    "Logs": Logs,
                    "harness_result": layer_result,
                },
                status=400
            )

        generating_msg = f"[INFO] Generating {db_name} Assessment Report and Migration Plan using the extracted metadata and Harness Layer 1 findings..."
        update_scan_job_state(scan_id, progress=45, current_message=f"Generating {db_name} Assessment Report and Migration Plan", log_entry=generating_msg)
        print(generating_msg)

        # Forward scan_id to Agents_PipeLine (advances progress from 45% to 96%)
        output_files = Agents_PipeLine(metadata, source_hint=(scan_source or source), scan_id=scan_id)

        fabric_push = None
        if db_clean == "databricks":
            update_scan_job_state(scan_id, progress=97, current_message="Syncing assessment with Microsoft Fabric OneLake...", log_entry="[INFO] Databricks source - auto-pushing assessment to Microsoft Fabric...")
            print("[INFO] Databricks source - auto-pushing assessment to Microsoft Fabric...")
            try:
                fabric_push = _push_databricks_to_fabric(output_files, Creds.get_database_name())
                update_scan_job_state(
                    scan_id,
                    progress=98,
                    current_message="Fabric OneLake artifacts synchronized.",
                    log_entry=(
                        f"[INFO] Fabric push completed: {len(fabric_push.get('processed', []) or [])} table(s) "
                        f"created/updated in '{fabric_push.get('lakehouse_name')}', "
                        f"{len(fabric_push.get('errors', []) or [])} error(s)."
                    ),
                )
                print(f"[INFO] Fabric push completed: {fabric_push}")
            except Exception as fabric_exc:
                fabric_push = {"status": "error", "error": str(fabric_exc)}
                update_scan_job_state(
                    scan_id,
                    progress=98,
                    current_message="Fabric artifact sync note recorded.",
                    log_entry=f"[WARN] Fabric artifact push failed (reports above are still available): {fabric_exc}",
                )
                print(f"[WARN] Fabric artifact push failed: {fabric_exc}")

        finalizing_msg = "[INFO] All output is available in the Logs panel below."
        update_scan_job_state(scan_id, progress=99, current_message="Finalizing reports and logs...", log_entry=finalizing_msg)
        print(finalizing_msg)
        time.sleep(0.4)

        completed_msg = f"[INFO] {db_name} scan completed successfully."
        update_scan_job_state(scan_id, progress=100, current_message=f"{db_name} scan completed successfully.", log_entry=completed_msg)
        print(completed_msg)
        
        # Retrieve logs for direct response compat
        with scan_jobs_lock:
            job = scan_jobs.get(scan_id)
            job_logs = job.get("logs", []) if job else list(Logs.get("Scan Info", []))
            job_tokens = job.get("token_info", []) if job else list(Logs.get("Token Info", []))

        return Response({
                "status": "success",
                "message": "Database scan completed successfully. Refer to View Output tab below ",
                "source": source,
                "destination": destination,
                "data": job_tokens,
                "Logs": {
                    "Scan Info": job_logs,
                    "Harness Layer1": job.get("harness1_logs", []) if job else list(Logs.get("Harness Layer1", [])),
                    "Harness Layer2": job.get("harness2_logs", []) if job else list(Logs.get("Harness Layer2", [])),
                },
                "output_files": output_files,
                "tables_found": selected_tables,
                "views_found": selected_views,
                "procedures_found": selected_procs,
            })
    except Exception as e:
        update_scan_job_state(scan_id, log_entry=str(e))
        return Response(
                        {
                            "status": "Error",
                            "message": str(e)
                        },
                        status=400
                    )


@api_view(["GET"])
def debug_view(request):
    with scan_jobs_lock:
        serialized_jobs = {}
        for k, v in scan_jobs.items():
            serialized_jobs[k] = {
                "status": v.get("status"),
                "progressbar": v.get("progress"),
                "scan_status_message": v.get("current_message"),
                "logs": v.get("logs"),
                "harness1_logs": v.get("harness1_logs"),
                "harness2_logs": v.get("harness2_logs"),
            }
        return Response({
            "scan_jobs": serialized_jobs,
            "Logs": {
                "Scan Info": list(Logs.get("Scan Info", [])),
                "Harness Layer1": list(Logs.get("Harness Layer1", [])),
                "Harness Layer2": list(Logs.get("Harness Layer2", [])),
            }
        })


@api_view(["POST", "GET"])
def generate_fabric_artifacts(request):
    """
    Executes one of the per-source BackEnd/Artifacts_Generator/*2_fabric.py
    scripts (databricks2_fabric.py, sqlserver2_fabric.py,
    dynamics3652_fabric.py, snowflake2_fabric.py) to create Delta tables,
    Views, Stored Procedures, Volumes, and a Data Pipeline scaffold
    directly in Microsoft Fabric, based on the selected source's
    Assessment Report/Migration Plan.

    All four are thin wrappers around the same
    fabric_generator_core.Generator() - see that module's docstring - each
    just pinning source_system and reporting its own filename back as
    generator_script.
    """
    try:
        global source
        source_param = (
            request.data.get("source") if request.method == "POST" else request.GET.get("source")
        ) or ""
        if not source_param and source:
            source_param = str(source)

        # Fallback to latest scan job source if available
        if not source_param:
            with scan_jobs_lock:
                if scan_jobs:
                    latest_job = list(scan_jobs.values())[-1]
                    source_param = latest_job.get("source") or ""

        # Fallback to Creds if databricks connection is configured
        if not source_param and Creds.get_extra("http_path"):
            source_param = "databricks"

        workspace_id = request.data.get("workspace_id") if request.method == "POST" else request.GET.get("workspace_id")

        source_clean = (source_param or "").strip().lower().replace(" ", "").replace("_", "")

        # Route based on source system - each source has its own thin
        # *2_fabric.py entry point (databricks2_fabric.py /
        # sqlserver2_fabric.py / dynamics3652_fabric.py), all backed by the
        # same fabric_generator_core.Generator(); only which one gets
        # imported, and therefore the resolved pre-provisioned
        # Lakehouse/report files, differs.
        if "databricks" in source_clean:
            source_display = "Databricks"
            from Artifacts_Generator import databricks2_fabric as fabric_script
            script_name = fabric_script.SCRIPT_NAME
            print(f"[INFO] Routing Generate Artifacts to: {script_name} for source: {source_display}")
            result = fabric_script.Generator(database_name=Creds.get_database_name(), workspace_id=workspace_id)
        elif "dynamics" in source_clean or source_clean == "d365":
            source_display = "Dynamics 365"
            from Artifacts_Generator import dynamics3652_fabric as fabric_script
            script_name = fabric_script.SCRIPT_NAME
            print(f"[INFO] Routing Generate Artifacts to: {script_name} for source: {source_display}")
            result = fabric_script.Generator(database_name=Creds.get_database_name(), workspace_id=workspace_id)
        elif "snowflake" in source_clean:
            source_display = "Snowflake"
            from Artifacts_Generator import snowflake2_fabric as fabric_script
            script_name = fabric_script.SCRIPT_NAME
            print(f"[INFO] Routing Generate Artifacts to: {script_name} for source: {source_display}")
            result = fabric_script.Generator(database_name=Creds.get_database_name(), workspace_id=workspace_id)
        else:
            source_display = "SQL Server"
            from Artifacts_Generator import sqlserver2_fabric as fabric_script
            script_name = fabric_script.SCRIPT_NAME
            print(f"[INFO] Routing Generate Artifacts to: {script_name} for source: {source_display}")
            result = fabric_script.Generator(database_name=Creds.get_database_name(), workspace_id=workspace_id)

        result["generator_script"] = script_name
        result["source_system"] = source_display
        if "logs" in result and isinstance(result.get("logs"), list):
            result["logs"].insert(0, f"Routing Generate Artifacts to: {script_name} for source: {source_display}")

        return Response(result, status=200)
    except Exception as exc:
        traceback.print_exc()
        return Response({
            "status": "error",
            "message": str(exc),
            "logs": [str(exc)],
            "generator_script": None
        }, status=200)
