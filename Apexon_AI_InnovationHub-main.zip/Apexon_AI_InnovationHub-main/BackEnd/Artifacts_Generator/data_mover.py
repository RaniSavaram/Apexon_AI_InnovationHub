"""
Companion to sync_table() in DB2_2_Fabric.py. sync_table() only ensures the
Delta table's SCHEMA exists at table_uri (see its own docstring). This
module is the piece that actually copies rows, source -> target, reusing
the exact table_uri / storage_options / target_pa_schema sync_table()
already computed -- no parallel path-building logic to drift out of sync.

Three sources are genuinely different shapes, not just different connection
strings:
  - SQL Server (pymssql)          -> DB-API cursor, SQL SELECT, fetchmany()
  - Databricks (databricks-sql)   -> same DB-API shape as SQL Server
  - Dynamics 365 (Dataverse)      -> NOT SQL. A paginated REST/OData API
                                      (Web API), auth via OAuth2 client
                                      credentials, follows @odata.nextLink.

So rather than force all three through one "connect + SELECT" function, each
source has its own row_batches() generator that yields plain dict-rows in
batches. A single shared core (write_batches_to_delta) turns any of those
batches into a pyarrow Table matching the target schema and appends it to
OneLake -- that part genuinely doesn't change per source.
"""

import pyarrow as pa
import requests


# ============================================================
# Shared core -- identical for every source
# ============================================================

def rows_to_arrow_batch(rows, target_pa_schema):
    """Converts one batch of dict-rows (from ANY source) into a pyarrow
    Table matching target_pa_schema exactly, since write_deltalake requires
    the incoming batch's schema to line up with the Delta table's schema on
    every append. Column-name matching is case-insensitive because target
    column names were cleaned via clean_identifier() when the Delta schema
    was built, while source rows still use original source column names."""
    columns = {field.name: [] for field in target_pa_schema}
    for row in rows:
        for field in target_pa_schema:
            value = next((v for k, v in row.items() if k.lower() == field.name.lower()), None)
            columns[field.name].append(value)
    arrays = [pa.array(columns[f.name], type=f.type) for f in target_pa_schema]
    return pa.Table.from_arrays(arrays, schema=target_pa_schema)


def write_batches_to_delta(table_uri, target_pa_schema, storage_options, row_batches, log_fn=print, label=""):
    """Drains a row_batches() generator (list-of-dicts per batch) into the
    Delta table at table_uri, one write_deltalake(mode="append") call per
    batch -- never holds the whole table in memory, same streaming approach
    regardless of which source produced the batches."""
    from deltalake import write_deltalake

    total_rows = 0
    for rows in row_batches:
        if not rows:
            continue
        batch_table = rows_to_arrow_batch(rows, target_pa_schema)
        write_deltalake(table_uri, batch_table, storage_options=storage_options, mode="append")
        total_rows += len(rows)
        log_fn(f"  [COPY] {label}: +{len(rows)} rows ({total_rows} total)")

    log_fn(f"  [DONE] {label}: {total_rows} rows copied")
    return total_rows


# ============================================================
# Source 1: SQL Server (pymssql) -- same pattern as
# Metadata_Scanner/extractors/sqlserver.py's SQLServerExtractor
# ============================================================

def sqlserver_row_batches(creds, schema_name, table_name, batch_size=10_000):
    import pymssql

    conn = pymssql.connect(
        server=creds.get_servername(),
        database=creds.get_database_name(),
        user=creds.get_username(),
        password=creds.get_password(),
        timeout=600,
        as_dict=True,
    )
    cur = conn.cursor()
    cur.arraysize = batch_size
    try:
        cur.execute(f"SELECT * FROM [{schema_name}].[{table_name}]")
        while True:
            rows = cur.fetchmany(batch_size)
            if not rows:
                break
            yield rows
    finally:
        cur.close()
        conn.close()


# ============================================================
# Source 2: Databricks (databricks-sql-connector) -- same
# connection fields as Metadata_Scanner/extractors/databricks_client.py
# ============================================================

def databricks_row_batches(creds, catalog, schema_name, table_name, batch_size=10_000):
    import databricks.sql as databricks_sql

    server_hostname = (creds.get_servername() or "").strip().strip('"').strip("'")
    http_path = (creds.get_extra("http_path") or "").strip()
    access_token = (creds.get_password() or "").strip()

    conn = databricks_sql.connect(
        server_hostname=server_hostname,
        http_path=http_path,
        access_token=access_token,
        catalog=catalog,
        schema=schema_name,
    )
    cur = conn.cursor()
    try:
        cur.execute(f"SELECT * FROM {catalog}.{schema_name}.{table_name}")
        col_names = [d[0] for d in cur.description]
        while True:
            batch = cur.fetchmany(batch_size)
            if not batch:
                break
            # databricks-sql-connector returns Row objects, not dicts --
            # zip against cursor.description to normalize to the same
            # dict-row shape sqlserver_row_batches() yields.
            yield [dict(zip(col_names, row)) for row in batch]
    finally:
        cur.close()
        conn.close()


# ============================================================
# Source 3: Dynamics 365 / Dataverse -- NOT SQL. Paginated
# OData Web API, same OAuth2 client-credentials flow as
# Metadata_Scanner/extractors/dynamics365.py's Dynamics365Extractor
# ============================================================

def _dataverse_get_token(org_url, tenant_id, client_id, client_secret):
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    response = requests.post(
        token_url,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": f"{org_url}/.default",
        },
    )
    response.raise_for_status()
    return response.json()["access_token"]


def _dataverse_resolve_entity_set_name(org_url, token, logical_name):
    """Dataverse's REST collection name isn't just the plural of the
    logical name (e.g. logical name 'company' -> set name 'accounts' isn't
    even a naming-convention case) -- it has to be looked up via
    EntityDefinitions. entity_set_name is already resolved once during the
    metadata scan (see dynamics365.py's extract()) but isn't persisted
    anywhere this module can read, so it's re-resolved here to keep this
    module independent of Metadata_Scanner internals."""
    url = f"{org_url}/api/data/v9.2/EntityDefinitions(LogicalName='{logical_name}')"
    resp = requests.get(
        url,
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        params={"$select": "EntitySetName"},
    )
    resp.raise_for_status()
    return resp.json()["EntitySetName"]


def dynamics365_row_batches(creds, entity_logical_name, batch_size=5_000):
    org_url = (creds.get_servername() or "").rstrip("/")
    tenant_id = creds.get_extra("tenant_id")
    client_id = creds.get_extra("client_id")
    client_secret = creds.get_extra("client_secret")

    token = _dataverse_get_token(org_url, tenant_id, client_id, client_secret)
    entity_set_name = _dataverse_resolve_entity_set_name(org_url, token, entity_logical_name)

    url = f"{org_url}/api/data/v9.2/{entity_set_name}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Prefer": f"odata.maxpagesize={batch_size}",
    }

    while url:
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        payload = resp.json()
        records = payload.get("value", [])
        if records:
            # Strip Dataverse's @odata.* annotation fields (e.g.
            # "_ownerid_value@OData.Community.Display.V1.FormattedValue")
            # so only real column values reach rows_to_arrow_batch().
            yield [{k: v for k, v in r.items() if not k.startswith("@") and "@" not in k} for r in records]
        url = payload.get("@odata.nextLink")
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}  # nextLink already has $-params baked in


# ============================================================
# One entry point that dispatches to the right source
# ============================================================

def copy_table_data(
    source_system,
    table_uri,
    schema_name,
    table_name,
    target_pa_schema,
    storage_options,
    source_creds,
    batch_size=10_000,
    log_fn=print,
    catalog=None,           # required for databricks
    entity_logical_name=None,  # required for dynamics365 (defaults to table_name)
):
    """
    Single entry point covering all three sources. Call this right after
    sync_table() in DB2_2_Fabric.py's per-table loop, passing through the
    exact same table_uri / target_pa_schema / storage_options sync_table()
    already computed.
    """
    source_system = (source_system or "").strip().lower()

    if source_system == "sqlserver":
        row_batches = sqlserver_row_batches(source_creds, schema_name, table_name, batch_size)

    elif source_system == "databricks":
        if not catalog:
            raise ValueError("copy_table_data(source_system='databricks') requires catalog=...")
        row_batches = databricks_row_batches(source_creds, catalog, schema_name, table_name, batch_size)

    elif source_system == "dynamics365":
        row_batches = dynamics365_row_batches(source_creds, entity_logical_name or table_name, batch_size)

    else:
        raise ValueError(f"copy_table_data: unsupported source_system '{source_system}'")

    label = f"{schema_name}.{table_name}"
    return write_batches_to_delta(table_uri, target_pa_schema, storage_options, row_batches, log_fn, label)
