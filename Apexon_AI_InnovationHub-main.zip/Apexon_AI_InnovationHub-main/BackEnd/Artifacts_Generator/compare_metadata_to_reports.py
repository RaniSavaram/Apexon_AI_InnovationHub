"""
Grounds the AI-generated Assessment Report and Migration Plan against the
scanned metadata.

Two possible metadata shapes exist in this codebase, and this module reads
EITHER one automatically:

  1. {source}_metadata.json - the RAW scan, shape {"database":...,
     "schemas": [{"name":..., "tables": [{"name":..., "columns": [...]}]}]}.
     Produced by write_metadata() since it was wired into Agents_PipeLine.py.
     Scans run before that change won't have this file.

  2. {source}_Fabric_Migration_Metadata.json - the Fabric-target artifact,
     shape {"metadata":..., "source":..., "objects": [{"name":...,
     "schema":..., "type": "table"|"procedure"|"view", "columns": [...]}]}.
     Produced by fabric_json_generator.py on every scan, so it always exists.

compare_metadata_to_assessment_report()/compare_metadata_to_migration_plan()
accept a metadata_path directly (works with either shape). find_metadata_file()
picks whichever is actually on disk for a given source, preferring the raw
scan when both exist since it predates any Fabric-target interpretation.
"""

import argparse
import json
import re
from pathlib import Path
from typing import Optional

import docx


def _find_backend_root(start: Path) -> Path:
    """Locates the BackEnd/ folder (identified by manage.py) regardless of
    exactly where this file happens to be saved under it, so a copy left in
    the wrong folder doesn't silently compute a broken output path -- that's
    exactly what happened with a stale duplicate of this file sitting one
    level too high."""
    for candidate in (start, *start.parents):
        if (candidate / "manage.py").exists():
            return candidate
    return start.parent.parent  # best-effort fallback if manage.py isn't found


DEFAULT_OUTPUT_DIR = _find_backend_root(Path(__file__).resolve().parent) / "AI_Agent_Pipeline" / "output"


def _latest_match(output_dir: Path, exact_name: str) -> Optional[Path]:
    """Finds exact_name, OR a numbered-duplicate variant of it (e.g. a
    second scan saved as "sqlserver_Assessment_Report_1.docx" instead of
    overwriting the first run's file). When more than one candidate exists,
    the most recently MODIFIED one wins -- not the highest number -- so this
    always picks the latest scan regardless of how the duplicate got named.
    Returns None if nothing matches at all."""
    stem, suffix = Path(exact_name).stem, Path(exact_name).suffix
    candidates = list(output_dir.glob(f"{stem}*{suffix}"))
    # Keep only the exact name and "<stem>_<number><suffix>" - not an
    # unrelated file that happens to share a prefix.
    candidates = [c for c in candidates if c.name == exact_name or re.fullmatch(rf"{re.escape(stem)}_\d+{re.escape(suffix)}", c.name)]
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


def find_fabric_artifact_file(source: str, output_dir: Path = DEFAULT_OUTPUT_DIR) -> Path:
    """Unlike find_metadata_file() (which prefers the raw metadata.json),
    this specifically looks for {source}_Fabric_Migration_Metadata.json -
    the only shape carrying relationships/execution_plan, which
    check_migration_plan_sequencing() needs."""
    artifact = _latest_match(Path(output_dir), f"{source}_Fabric_Migration_Metadata.json")
    if artifact is None:
        raise FileNotFoundError(
            f"No {source}_Fabric_Migration_Metadata.json found in {output_dir}."
        )
    return artifact


def find_metadata_file(source: str, output_dir: Path = DEFAULT_OUTPUT_DIR) -> Path:
    """Prefers {source}_metadata.json (raw scan); falls back to
    {source}_Fabric_Migration_Metadata.json (always present) when the raw
    file doesn't exist, e.g. for scans run before write_metadata() was wired
    up. Either name may also exist as a numbered duplicate (see
    _latest_match) if the output folder wasn't cleared between scans.
    Raises FileNotFoundError with both candidate paths if neither exists."""
    output_dir = Path(output_dir)
    raw = _latest_match(output_dir, f"{source}_metadata.json")
    if raw is not None:
        return raw
    artifact = _latest_match(output_dir, f"{source}_Fabric_Migration_Metadata.json")
    if artifact is not None:
        print(f"[INFO] {source}_metadata.json not found (scan predates raw-metadata saving) - "
              f"using {artifact.name} instead")
        return artifact
    raise FileNotFoundError(
        f"No {source}_metadata.json or {source}_Fabric_Migration_Metadata.json "
        f"(with or without a numbered suffix) found in {output_dir}. Run a scan for source '{source}' first."
    )


def _load_metadata_tables(metadata_path: str) -> list:
    """Loads either shape and returns a flat list of
    {schema_name, table_name, qualified_name, columns, row_count} table
    records, where columns is the list of actual column NAMES (not just a
    count) -- needed for the column-level coverage check. schema_name is
    kept separate from table_name (rather than only a combined
    "schema.table" string) so a missing-column message can say which schema
    a table belongs to."""
    with open(metadata_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if "schemas" in data:                          # raw metadata.json
        tables = []
        for schema in data.get("schemas", []):
            schema_name = schema.get("name", "")
            for table in schema.get("tables", []):
                tables.append({
                    "schema_name": schema_name,
                    "table_name": table["name"],
                    "qualified_name": f"{schema_name}.{table['name']}" if schema_name else table["name"],
                    "columns": [c["name"] for c in table.get("columns", []) if c.get("name")],
                    "row_count": table.get("row_count"),
                })
        return tables

    if "objects" in data:                           # *_Fabric_Migration_Metadata.json artifact
        tables = []
        for obj in data.get("objects", []):
            if obj.get("type") != "table":
                continue
            schema_name = obj.get("schema", "")
            table_name = obj.get("name", "")
            tables.append({
                "schema_name": schema_name,
                "table_name": table_name,
                "qualified_name": f"{schema_name}.{table_name}" if schema_name else table_name,
                "columns": [c["name"] for c in obj.get("columns", []) if c.get("name")],
                "row_count": obj.get("row_count"),
            })
        return tables

    raise ValueError(
        f"{metadata_path} doesn't match either known shape "
        f"(no top-level 'schemas' or 'objects' key)."
    )


def _extract_docx_text(path: str) -> str:
    d = docx.Document(path)
    chunks = [p.text for p in d.paragraphs]
    for table in d.tables:
        for row in table.rows:
            for cell in row.cells:
                chunks.append(cell.text)
    return " ".join(chunks).lower()


def _table_mentioned(name: str, doc_text: str) -> bool:
    return re.search(rf"\b{re.escape(name.lower())}\b", doc_text) is not None


# Column names at or below this length are treated as unreliable to check by
# plain text search -- "id", "name", "status", "date" etc. will match almost
# any report's prose regardless of whether that specific column was ever
# actually discussed, so a "covered" verdict for them doesn't mean much.
# They're still reported, just kept in a separate bucket instead of silently
# counting toward "fully covered".
_UNRELIABLE_COLUMN_NAME_LENGTH = 4


def _build_coverage_report(metadata_tables: list, doc_text: str) -> dict:
    """Checks every table AND every column. missing_tables and
    missing_columns are reported separately -- those are different problems:
    one is a dropped table, the other is a table the report DID address but
    didn't fully cover. missing_columns is a FLAT list, one entry per
    missing column (not grouped under its table), so each one carries its
    own schema_name/table_name/column_name and can be turned into an
    individual sentence rather than a nested JSON structure."""
    missing_tables = []
    missing_columns = []
    fully_covered_tables = []
    unreliable_columns = []

    for t in metadata_tables:
        if not _table_mentioned(t["table_name"], doc_text):
            missing_tables.append({"schema_name": t["schema_name"], "table_name": t["table_name"]})
            continue

        checkable = [c for c in t["columns"] if len(c) > _UNRELIABLE_COLUMN_NAME_LENGTH]
        unreliable = [c for c in t["columns"] if len(c) <= _UNRELIABLE_COLUMN_NAME_LENGTH]

        for c in unreliable:
            unreliable_columns.append({"schema_name": t["schema_name"], "table_name": t["table_name"], "column_name": c})

        found_missing = False
        for c in checkable:
            if not _table_mentioned(c, doc_text):
                missing_columns.append({"schema_name": t["schema_name"], "table_name": t["table_name"], "column_name": c})
                found_missing = True

        if not found_missing:
            fully_covered_tables.append({"schema_name": t["schema_name"], "table_name": t["table_name"]})

    total = len(metadata_tables)
    pct = round(100 * len(fully_covered_tables) / total, 1) if total else 100.0

    return {
        "total_tables_in_metadata": total,
        "fully_covered_tables": fully_covered_tables,
        "missing_tables": missing_tables,
        "missing_columns": missing_columns,
        "unreliable_columns": unreliable_columns,
        "coverage_pct": pct,
        "fully_covered": not missing_tables and not missing_columns,
    }


def format_coverage_report(result: dict, title: str) -> str:
    """Human-readable rendering of a coverage result, for the CLI -- the
    raw dict (returned by compare_metadata_to_assessment_report /
    compare_metadata_to_migration_plan) is still what callers get back for
    programmatic use; this is just how it's PRINTED. Each missing item gets
    its own plain sentence rather than being grouped into a JSON blob."""
    lines = [
        f"=== {title} ===",
        f"Tables in metadata:  {result['total_tables_in_metadata']}",
        f"Fully covered:       {len(result['fully_covered_tables'])} "
        f"({result['coverage_pct']}%)",
    ]

    if result["missing_tables"]:
        lines.append("")
        lines.append(f"MISSING TABLES ({len(result['missing_tables'])}):")
        for t in result["missing_tables"]:
            lines.append(f"  - Table '{t['table_name']}' is missing from the document "
                         f"(schema '{t['schema_name']}').")

    if result["missing_columns"]:
        lines.append("")
        lines.append(f"MISSING COLUMNS ({len(result['missing_columns'])}):")
        for c in result["missing_columns"]:
            lines.append(f"  - Column '{c['column_name']}' is missing from table '{c['table_name']}' "
                         f"related to schema '{c['schema_name']}'.")

    if result["unreliable_columns"]:
        lines.append("")
        lines.append(f"NOTE: {len(result['unreliable_columns'])} column name(s) were too short/common "
                     f"(<= {_UNRELIABLE_COLUMN_NAME_LENGTH} chars, e.g. 'id', 'name') to check reliably by "
                     f"text search and were skipped rather than risk a false 'covered'.")

    if result["fully_covered"]:
        lines.append("")
        lines.append("All tables and their (checkable) columns are accounted for.")

    return "\n".join(lines)


def compare_metadata_to_assessment_report(metadata_path: str, assessment_report_path: str) -> dict:
    tables = _load_metadata_tables(metadata_path)
    doc_text = _extract_docx_text(assessment_report_path)
    return _build_coverage_report(tables, doc_text)


def compare_metadata_to_migration_plan(metadata_path: str, migration_plan_path: str) -> dict:
    tables = _load_metadata_tables(metadata_path)
    doc_text = _extract_docx_text(migration_plan_path)
    return _build_coverage_report(tables, doc_text)


def _find_table_rows_by_headers(doc: "docx.Document", header_keywords: list) -> Optional[list]:
    """Returns a Word table's data rows (as lists of cell text, header row
    excluded) where the FIRST row's cells case-insensitively contain all of
    header_keywords -- located by header content rather than a fixed table
    index, since which numbered table in the document holds this content
    can shift between runs. Returns None if no matching table exists."""
    for table in doc.tables:
        if not table.rows:
            continue
        header_cells = [c.text.strip().lower() for c in table.rows[0].cells]
        if all(any(kw in cell for cell in header_cells) for kw in header_keywords):
            return [[c.text.strip() for c in row.cells] for row in table.rows[1:]]
    return None


def _load_relationships(metadata_path: str) -> list:
    """FK relationships using SHORT table names (matching how the Migration
    Plan's own dependency/execution-order tables reference objects -- by
    short name, not schema-qualified). Only the *_Fabric_Migration_Metadata.json
    artifact shape carries this; returns [] for the raw metadata.json shape."""
    with open(metadata_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    relationships = []
    for r in data.get("relationships", []):
        parent = r.get("referenced_table")   # the dependency - must be migrated first
        child = r.get("parent_table")        # the table with the FK - must come after
        if parent and child and parent.lower() != child.lower():
            relationships.append({"fk_name": r.get("fk_name", ""), "depends_on": parent, "dependent": child})
    return relationships


def check_migration_plan_sequencing(metadata_path: str, migration_plan_path: str) -> dict:
    """
    Migration-plan-specific checks, built on the plan's own STRUCTURED WORD
    TABLES (dependency analysis, execution order, batch plan) instead of
    searching prose for column names. That approach doesn't fit this
    document: the Migration Plan's job is sequencing and batching, not
    restating every column, so a column-presence check mostly flags things
    the plan was never supposed to contain in the first place.

    Three checks, each against real structured content in the plan:
      1. Dependency-table accuracy: does the plan's own "Depends On" table
         match the source schema's actual foreign keys? Flags BOTH omitted
         dependencies (a real FK the plan's table doesn't list) and
         hallucinated ones (the plan claims a dependency that doesn't exist).
      2. Execution-order correctness: using the plan's own NUMBERED execution
         order table, does every dependent table have a later (or equal, as
         a softer warning) order number than what it depends on?
      3. Batch-size accuracy: do the plan's batch object-counts match the
         source metadata's own batch breakdown?

    Requires the *_Fabric_Migration_Metadata.json artifact shape (the only
    shape carrying relationships/execution_plan) - raises ValueError
    against a raw metadata.json.
    """
    with open(metadata_path, "r", encoding="utf-8") as f:
        metadata = json.load(f)
    if "relationships" not in metadata or "execution_plan" not in metadata:
        raise ValueError(
            f"{metadata_path} has no 'relationships'/'execution_plan' data - this check "
            f"needs the *_Fabric_Migration_Metadata.json artifact shape, not a raw metadata.json."
        )

    relationships = _load_relationships(metadata_path)
    doc = docx.Document(migration_plan_path)

    # ---- Check 1: dependency table accuracy ----
    dep_rows = _find_table_rows_by_headers(doc, ["object", "depends"]) or []
    stated_deps = {}  # {object_name_lower: {depends_on_lower, ...}}
    for row in dep_rows:
        if len(row) < 2:
            continue
        obj, depends_on = row[0].strip(), row[1].strip()
        if not obj or depends_on.lower() in ("", "none", "n/a"):
            continue
        stated_deps.setdefault(obj.lower(), set()).add(depends_on.lower())

    known_table_names = {t["table_name"].lower() for t in _load_metadata_tables(metadata_path)}
    real_pairs = {(rel["dependent"].lower(), rel["depends_on"].lower()) for rel in relationships}

    omitted_dependencies, confirmed_dependencies = [], []
    for rel in relationships:
        if rel["depends_on"].lower() in stated_deps.get(rel["dependent"].lower(), set()):
            confirmed_dependencies.append(rel)
        else:
            omitted_dependencies.append(rel)

    hallucinated_dependencies = []
    for obj, deps in stated_deps.items():
        for dep in deps:
            # Only flag it against a REAL table name -- otherwise this is
            # more likely a parsing/name-format mismatch than a genuine
            # invented foreign key.
            if dep in known_table_names and (obj, dep) not in real_pairs:
                hallucinated_dependencies.append({"object": obj, "stated_depends_on": dep})

    # ---- Check 2: execution order correctness ----
    order_rows = _find_table_rows_by_headers(doc, ["execution order", "object"]) or []
    execution_order = {}  # {object_name_lower: int}
    for row in order_rows:
        if len(row) < 2:
            continue
        digits = re.sub(r"\D", "", row[0])
        if not digits:
            continue
        name = row[1].strip().lower()
        if name:
            execution_order[name] = int(digits)

    sequencing_violations, same_step_warnings, sequencing_unverifiable = [], [], []
    sequencing_verified = 0
    for rel in relationships:
        child, parent = rel["dependent"].lower(), rel["depends_on"].lower()
        if child not in execution_order or parent not in execution_order:
            sequencing_unverifiable.append(rel)
        elif execution_order[parent] > execution_order[child]:
            sequencing_violations.append(rel)
        elif execution_order[parent] == execution_order[child]:
            same_step_warnings.append(rel)
        else:
            sequencing_verified += 1

    # ---- Check 3: batch size accuracy ----
    batch_rows = _find_table_rows_by_headers(doc, ["batch", "scope objects"]) or []
    metadata_batches = metadata.get("execution_plan", {}).get("batches", {})
    batch_count_mismatches = []
    for row in batch_rows:
        if len(row) < 2:
            continue
        batch_label, scope_text = row[0].strip(), row[1].strip()
        count_match = re.match(r"(\d+)", scope_text)
        meta_entry = next((v for k, v in metadata_batches.items() if k.lower().startswith(batch_label.lower())), None)
        if not count_match or meta_entry is None:
            continue
        stated_count, actual_count = int(count_match.group(1)), len(meta_entry)
        if stated_count != actual_count:
            batch_count_mismatches.append({
                "batch": batch_label, "plan_stated_count": stated_count, "metadata_actual_count": actual_count,
            })

    total_checkable = sequencing_verified + len(sequencing_violations)
    sequencing_pct = round(100 * sequencing_verified / total_checkable, 1) if total_checkable else 100.0

    return {
        "total_relationships": len(relationships),
        "confirmed_dependencies": len(confirmed_dependencies),
        "omitted_dependencies": omitted_dependencies,
        "hallucinated_dependencies": hallucinated_dependencies,
        "sequencing_verified": sequencing_verified,
        "sequencing_violations": sequencing_violations,
        "sequencing_same_step_warnings": same_step_warnings,
        "sequencing_unverifiable": sequencing_unverifiable,
        "sequencing_accuracy_pct": sequencing_pct,
        "batch_count_mismatches": batch_count_mismatches,
        "fully_consistent": not (omitted_dependencies or hallucinated_dependencies
                                 or sequencing_violations or batch_count_mismatches),
    }


def format_sequencing_report(result: dict, title: str = "Migration Plan - Dependency & Sequencing Check") -> str:
    lines = [
        f"=== {title} ===",
        f"Foreign-key relationships in metadata: {result['total_relationships']}",
        f"Confirmed in the plan's dependency table: {result['confirmed_dependencies']}",
        f"Execution order correctly sequenced:    {result['sequencing_verified']} "
        f"({result['sequencing_accuracy_pct']}%)",
    ]

    if result["omitted_dependencies"]:
        lines.append("")
        lines.append(f"OMITTED DEPENDENCIES ({len(result['omitted_dependencies'])}) "
                     f"- real foreign keys the plan's dependency table doesn't list:")
        for d in result["omitted_dependencies"]:
            lines.append(f"  - Table '{d['dependent']}' depends on '{d['depends_on']}' "
                         f"(foreign key '{d['fk_name']}'), but this isn't reflected in the plan.")

    if result["hallucinated_dependencies"]:
        lines.append("")
        lines.append(f"HALLUCINATED DEPENDENCIES ({len(result['hallucinated_dependencies'])}) "
                     f"- the plan claims a dependency that doesn't exist in the source schema:")
        for d in result["hallucinated_dependencies"]:
            lines.append(f"  - Table '{d['object']}' is stated to depend on '{d['stated_depends_on']}', "
                         f"but no such foreign key exists.")

    if result["sequencing_violations"]:
        lines.append("")
        lines.append(f"SEQUENCING VIOLATIONS ({len(result['sequencing_violations'])}) "
                     f"- the plan's own execution order would migrate a table before its dependency:")
        for v in result["sequencing_violations"]:
            lines.append(f"  - Table '{v['dependent']}' is scheduled before '{v['depends_on']}', "
                         f"which it depends on (foreign key '{v['fk_name']}').")

    if result["sequencing_same_step_warnings"]:
        lines.append("")
        lines.append(f"NOTE: {len(result['sequencing_same_step_warnings'])} relationship(s) have both tables "
                     f"in the SAME execution step - not necessarily wrong, but worth a human check.")

    if result["sequencing_unverifiable"]:
        lines.append("")
        lines.append(f"NOTE: {len(result['sequencing_unverifiable'])} relationship(s) couldn't be checked "
                     f"because one or both tables weren't found in the plan's execution order table.")

    if result["batch_count_mismatches"]:
        lines.append("")
        lines.append(f"BATCH COUNT MISMATCHES ({len(result['batch_count_mismatches'])}):")
        for m in result["batch_count_mismatches"]:
            lines.append(f"  - {m['batch']}: plan states {m['plan_stated_count']} objects, "
                         f"but metadata shows {m['metadata_actual_count']}.")

    if result["fully_consistent"]:
        lines.append("")
        lines.append("The plan's dependency analysis, execution order, and batch counts are all "
                     "consistent with the source metadata.")

    return "\n".join(lines)


def _default_report_paths(source: str, output_dir: Path):
    """Each report has a source-prefixed filename (preferred - possibly with
    a numbered suffix if the output folder wasn't cleared between scans) and
    a legacy unprefixed fallback (see Agents_PipeLine.py)."""
    def pick(prefixed, legacy):
        return _latest_match(output_dir, prefixed) or _latest_match(output_dir, legacy) or (output_dir / legacy)

    assessment = pick(f"{source}_Assessment_Report.docx", "Assesment Report.docx")
    plan = pick(f"{source}_Migration_Plan.docx", "AI_Migration_Plan.docx")
    return assessment, plan


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", default="sqlserver",
                        help="source system prefix, e.g. sqlserver, databricks, dynamics365 (default: sqlserver)")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR),
                        help=f"folder holding the scan outputs (default: {DEFAULT_OUTPUT_DIR})")
    parser.add_argument("--metadata", help="explicit metadata JSON path (overrides --source/--output-dir lookup)")
    parser.add_argument("--assessment", help="explicit Assessment Report .docx path")
    parser.add_argument("--plan", help="explicit Migration Plan .docx path")
    parser.add_argument("--json", action="store_true",
                        help="print the raw JSON result instead of the formatted report (for scripting)")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    metadata_path = args.metadata or find_metadata_file(args.source, output_dir)
    default_assessment, default_plan = _default_report_paths(args.source, output_dir)
    assessment_path = args.assessment or default_assessment
    plan_path = args.plan or default_plan

    try:
        fabric_artifact_path = args.metadata or find_fabric_artifact_file(args.source, output_dir)
    except FileNotFoundError:
        fabric_artifact_path = None

    print(f"[INFO] metadata:   {metadata_path}")
    print(f"[INFO] assessment: {assessment_path}")
    print(f"[INFO] plan:       {plan_path}")
    print(f"[INFO] fabric artifact (for sequencing check): {fabric_artifact_path or 'not found'}\n")

    assessment_result = compare_metadata_to_assessment_report(str(metadata_path), str(assessment_path))
    plan_result = (
        check_migration_plan_sequencing(str(fabric_artifact_path), str(plan_path))
        if fabric_artifact_path else None
    )

    if args.json:
        print(json.dumps({"assessment_report": assessment_result, "migration_plan_sequencing": plan_result}, indent=2))
    else:
        print(format_coverage_report(assessment_result, "Assessment Report Coverage"))
        print()
        if plan_result:
            print(format_sequencing_report(plan_result))
        else:
            print("=== Migration Plan Coverage ===")
            print(f"Skipped: no {args.source}_Fabric_Migration_Metadata.json found, and the sequencing "
                 f"check needs its relationships/execution_plan data.")
