"""
Migration Plan checks: validates the AI-generated Migration Plan (.docx)
against the scanned metadata, using the plan's real layout (tables under
"Table Summary", "Key Identification", "Dependency Mapping", "Execution
Order", "Batch" lists, etc.) instead of searching the whole document text.

Called automatically from compare_metadata_to_reports.compare_metadata_to_migration_plan(),
which attaches the result under the "plan_checks" key. Can also be run alone:

    from migration_plan_checks import run_plan_checks
    result = run_plan_checks(metadata_path, plan_path)

Checks (each finding has a check id, severity, object and message):

  GROUNDING  (plan -> metadata, hallucination detection)
    unknown_table      a table/view/procedure the plan names that is not in the metadata
    wrong_object_type  e.g. a view listed under the table batches
    unknown_column     a column the plan names that is not on that table
  COVERAGE   (metadata -> plan, per section instead of anywhere-in-document)
    missing_in_table_summary / missing_in_execution_order / missing_in_batch
    missing_view / missing_procedure / missing_function
    missing_key_row    a table's primary key column has no row in Key Identification
  CORRECTNESS
    header_count_mismatch      totals in the summary table vs the metadata
    key_type_mismatch          column marked "Primary" that is not the metadata's primary key
    dependency_missing / dependency_invented
    execution_order_violation  an object scheduled at or before something it depends on
    circular_dependency_missed metadata has a dependency cycle but the plan says none
    batch_misplaced            independent table in the dependent batch or vice versa
    batch_count_mismatch       "60 Independent Tables" vs the real count / list length
    duplicate_name             same table name in several schemas, plan uses bare names
    size_category_inconsistent a "Small" table bigger than a "Medium" one, etc.
    duplicate_entry            same object listed twice in one list
"""

import json
import re
from collections import defaultdict
from pathlib import Path

import docx
from docx.table import Table
from docx.text.paragraph import Paragraph

SEVERITIES = ("error", "warning", "info")


# ---------------------------------------------------------------------------
# Metadata (richer than _load_metadata_tables: also views/procedures, PKs, deps)
# ---------------------------------------------------------------------------

def load_metadata_model(metadata_path: str) -> dict:
    """Normalises either metadata shape into:
       tables: list of dicts (schema, name, columns, primary_key, dependencies, size_mb)
       views / procedures / functions: set of lower-cased names
       header: totals from the metadata block (may be empty for the raw shape)"""
    with open(metadata_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    model = {"tables": [], "views": {}, "procedures": {}, "functions": {}, "header": {}, "schemas": []}

    if "objects" in data:
        model["header"] = data.get("metadata", {}) or {}
        model["schemas"] = (data.get("source", {}) or {}).get("schemas", []) or []
        for o in data["objects"]:
            kind = o.get("type")
            name, schema = o.get("name", ""), o.get("schema", "")
            if kind == "table":
                model["tables"].append({
                    "schema": schema, "name": name,
                    "columns": [c["name"] for c in o.get("columns", []) if c.get("name")],
                    "primary_key": o.get("primary_key"),
                    "dependencies": list(o.get("dependencies") or []),
                    "size_mb": o.get("size_mb"), "row_count": o.get("row_count"),
                })
            elif kind in ("view", "procedure", "function"):
                model[{"view": "views", "procedure": "procedures", "function": "functions"}[kind]][name.lower()] = schema
    elif "schemas" in data:                      # raw scan: only tables are guaranteed
        model["schemas"] = [s.get("name", "") for s in data["schemas"]]
        for s in data["schemas"]:
            for t in s.get("tables", []):
                pk = t.get("primary_key")
                if pk is None:
                    pks = [c["name"] for c in t.get("columns", []) if c.get("primary_key") or c.get("is_primary_key")]
                    pk = pks[0] if pks else None
                model["tables"].append({
                    "schema": s.get("name", ""), "name": t["name"],
                    "columns": [c["name"] for c in t.get("columns", []) if c.get("name")],
                    "primary_key": pk, "dependencies": list(t.get("dependencies") or []),
                    "size_mb": t.get("size_mb"), "row_count": t.get("row_count"),
                })
            for key, bucket in (("views", "views"), ("procedures", "procedures"), ("functions", "functions")):
                for it in s.get(key, []) or []:
                    if isinstance(it, dict) and it.get("name"):
                        model[bucket][it["name"].lower()] = s.get("name", "")
    else:
        raise ValueError(f"{metadata_path} doesn't match either known metadata shape.")
    return model


# ---------------------------------------------------------------------------
# Plan parsing - keeps tables and bullet lists tied to where they sit
# ---------------------------------------------------------------------------

def _clean(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


def parse_plan_layout(plan_path: str) -> dict:
    """Walks the body in document order. Returns:
       tables: [{headers, rows, label}]   label = last plain paragraph before it
       bullets: [{group, text}]           group = last non-bullet paragraph before it
       Table headers are lower-cased in 'key' so tables are found by header
       text, not by position (robust to sections being reordered)."""
    d = docx.Document(plan_path)
    tables, bullets = [], []
    last_text = ""
    for child in d.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            p = Paragraph(child, d)
            text = _clean(p.text)
            if not text:
                continue
            style = (p.style.name if p.style is not None else "") or ""
            if style.lower().startswith("list"):
                bullets.append({"group": last_text, "text": text})
            else:
                last_text = text
        elif tag == "tbl":
            t = Table(child, d)
            grid = [[_clean(c.text) for c in r.cells] for r in t.rows]
            if grid:
                tables.append({"headers": grid[0], "key": [h.lower() for h in grid[0]],
                               "rows": grid[1:], "label": last_text})
    return {"tables": tables, "bullets": bullets}


def _find_table(layout: dict, *header_words):
    """First table whose header row contains every word (case-insensitive)."""
    for t in layout["tables"]:
        joined = " | ".join(t["key"])
        if all(w in joined for w in header_words):
            return t
    return None


def _col(table: dict, word: str):
    for i, h in enumerate(table["key"]):
        if word in h:
            return i
    return None


def _bare(name: str) -> str:
    """'[dbo].[Orders]' / 'dbo.Orders' -> 'Orders'."""
    return name.replace("[", "").replace("]", "").replace("`", "").split(".")[-1].strip()


# ---------------------------------------------------------------------------
# Findings collector
# ---------------------------------------------------------------------------

class _Findings:
    def __init__(self):
        self.items = []
        self._seen = set()

    def add(self, check, severity, obj, message):
        key = (check, obj, message)
        if key in self._seen:
            return
        self._seen.add(key)
        self.items.append({"check": check, "severity": severity, "object": obj, "message": message})


# ---------------------------------------------------------------------------
# The checks
# ---------------------------------------------------------------------------

def _batch_groups(layout: dict) -> dict:
    """Maps each 'Batch N: ...' bullet group to (kind, [names]).
    kind is table / view / procedure / function / volume, taken from the label."""
    groups = defaultdict(list)
    for b in layout["bullets"]:
        if re.match(r"batch\s+\d+", b["group"], re.I):
            groups[b["group"]].append(b["text"])
    out = {}
    for label, items in groups.items():
        low = label.lower()
        kind = ("view" if "view" in low else "procedure" if "procedure" in low
                else "function" if "function" in low else "table")
        n = int(re.match(r"batch\s+(\d+)", label, re.I).group(1))
        out[label] = {"kind": kind, "batch": n, "names": [i for i in items if i.lower() not in ("none", "n/a")],
                      "independent": "independent" in low}
    return out


def run_plan_checks(metadata_path: str, plan_path: str) -> dict:
    model = load_metadata_model(metadata_path)
    layout = parse_plan_layout(plan_path)
    F = _Findings()

    tables = model["tables"]
    by_name = defaultdict(list)                       # lower name -> [table records]
    for t in tables:
        by_name[t["name"].lower()].append(t)
    views, procs, funcs = model["views"], model["procedures"], model["functions"]

    ctx = {"model": model, "layout": layout, "by_name": by_name, "F": F}

    size_t = _find_table(layout, "table name", "size")
    key_t = _find_table(layout, "table name", "column name", "key type")
    dep_t = _find_table(layout, "object name", "depends on")
    exec_t = _find_table(layout, "execution order", "object name")
    hdr_t = _find_table(layout, "database parameter")
    batch_t = _find_table(layout, "batch name", "scope objects")
    batches = _batch_groups(layout)

    for label, t in (("Table Summary (Table Name | Size Category)", size_t),
                     ("Key Identification (Table | Column | Key Type)", key_t),
                     ("Dependency Mapping (Object | Depends On)", dep_t),
                     ("Execution Order table", exec_t)):
        if t is None:
            F.add("plan_section_missing", "error", label, f"The plan has no '{label}' table.")
    if not batches:
        F.add("plan_section_missing", "error", "Batch plan", "The plan has no 'Batch N: ...' bullet lists.")

    # ---- GROUNDING + COVERAGE: table lists ---------------------------------
    def exists_table(name):
        return name.lower() in by_name

    def ground(names, where, expected="table"):
        for n in names:
            nl = _bare(n).lower()
            if not nl or nl in ("none", "n/a"):
                continue
            ok = {"table": nl in by_name, "view": nl in views, "procedure": nl in procs,
                  "function": nl in funcs}[expected]
            if ok:
                continue
            other = [k for k, d in (("table", by_name), ("view", views), ("procedure", procs), ("function", funcs))
                     if nl in d and k != expected]
            if other:
                F.add("wrong_object_type", "error", _bare(n),
                      f"'{_bare(n)}' is listed as a {expected} in {where}, but the metadata has it as a {other[0]}.")
            else:
                F.add("unknown_table", "error", _bare(n),
                      f"'{_bare(n)}' ({where}) is not a {expected} in the metadata - possible hallucination.")

    plan_table_names = {}                              # where -> lower-name set (for coverage)

    if size_t:
        c = _col(size_t, "table")
        names = [r[c] for r in size_t["rows"] if len(r) > c]
        ground(names, "Table Summary")
        plan_table_names["Table Summary"] = {_bare(n).lower() for n in names}
    if exec_t:
        c = _col(exec_t, "object name")
        names = [r[c] for r in exec_t["rows"] if len(r) > c]
        ground(names, "Execution Order")
        plan_table_names["Execution Order"] = {_bare(n).lower() for n in names}
    if dep_t:
        c0, c1 = _col(dep_t, "object name"), _col(dep_t, "depends on")
        ground([r[c0] for r in dep_t["rows"]], "Dependency Mapping (Object Name)")
        ground([r[c1] for r in dep_t["rows"] if r[c1].lower() != "none"], "Dependency Mapping (Depends On)")
    if key_t:
        ground([r[_col(key_t, "table")] for r in key_t["rows"]], "Key Identification")

    table_batch_names = set()
    for label, g in batches.items():
        where = f"'{label}'"
        ground(g["names"], where, g["kind"])
        if g["kind"] == "table":
            table_batch_names |= {n.lower() for n in g["names"]}
        seen = set()
        for n in g["names"]:
            if n.lower() in seen:
                F.add("duplicate_entry", "warning", n, f"'{n}' appears more than once in {where}.")
            seen.add(n.lower())

    # coverage: every metadata table in summary, execution order and a table batch
    for t in tables:
        nl = t["name"].lower()
        q = f"{t['schema']}.{t['name']}"
        for where, key in (("Table Summary", "missing_in_table_summary"), ("Execution Order", "missing_in_execution_order")):
            if where in plan_table_names and nl not in plan_table_names[where]:
                F.add(key, "error", q, f"Table '{q}' is not in the plan's {where}.")
        if batches and nl not in table_batch_names:
            F.add("missing_in_batch", "error", q, f"Table '{q}' is not in any table batch (Batch 1-3).")
    for kind, bucket, check in (("view", views, "missing_view"), ("procedure", procs, "missing_procedure"),
                                ("function", funcs, "missing_function")):
        listed = {n.lower() for g in batches.values() if g["kind"] == kind for n in g["names"]}
        for nl, schema in bucket.items():
            if nl not in listed:
                F.add(check, "error", f"{schema}.{nl}", f"The {kind} '{schema}.{nl}' is not in any {kind} batch.")

    # same name in more than one schema -> bare names in the plan are ambiguous
    for nl, recs in by_name.items():
        if len(recs) > 1:
            where = ", ".join(sorted(f"{r['schema']}.{r['name']}" for r in recs))
            F.add("duplicate_name", "warning", recs[0]["name"],
                  f"Table name exists in several schemas ({where}); the plan uses bare names, so these "
                  f"cannot be told apart (Execution Order lists it "
                  f"{sum(1 for r in (exec_t['rows'] if exec_t else []) if _bare(r[_col(exec_t,'object name')]).lower()==nl)} time(s), "
                  f"metadata has {len(recs)} tables).")

    # ---- Key Identification -------------------------------------------------
    if key_t:
        ct, cc, ck = _col(key_t, "table"), _col(key_t, "column"), _col(key_t, "key type")
        plan_keys = defaultdict(set)
        for r in key_t["rows"]:
            tn, cn, kt = _bare(r[ct]).lower(), r[cc], r[ck]
            recs = by_name.get(tn)
            if not recs:
                continue                                   # already flagged as unknown_table
            cols = {c.lower() for rec in recs for c in rec["columns"]}
            if cn.lower() not in cols:
                F.add("unknown_column", "error", f"{r[ct]}.{cn}",
                      f"Column '{cn}' on '{r[ct]}' (Key Identification) does not exist in the metadata.")
                continue
            if kt.lower().startswith("primary"):
                plan_keys[tn].add(cn.lower())
                pks = {rec["primary_key"] for rec in recs if rec["primary_key"]}
                if cn.lower() not in {p.lower() for p in pks}:
                    F.add("key_type_mismatch", "warning", f"{r[ct]}.{cn}",
                          f"'{r[ct]}.{cn}' is marked Primary; metadata primary key is "
                          f"{', '.join(sorted(pks)) if pks else 'none'}. (Metadata stores one key column, "
                          f"so a real composite key would also appear here.)")
        for t in tables:
            pk = t["primary_key"]
            if pk and pk.lower() not in plan_keys.get(t["name"].lower(), set()):
                F.add("missing_key_row", "error", f"{t['schema']}.{t['name']}.{pk}",
                      f"Primary key '{pk}' of '{t['schema']}.{t['name']}' has no 'Primary' row in Key Identification.")

    # ---- Header totals ------------------------------------------------------
    if hdr_t:
        c0, c1 = 0, 1
        kv = {r[c0].lower(): r[c1] for r in hdr_t["rows"] if len(r) > 1}
        h = model["header"]
        counted = {                     # what the metadata's object list really adds up to
            "total scanned tables": ("total_tables", len(tables)),
            "total columns mapped": ("total_columns", sum(len(t["columns"]) for t in tables)),
            "total views": ("total_views", len(views)),
            "total stored procedures": ("total_procedures", len(procs)),
            "total functions": ("total_functions", len(funcs)),
        }
        for label, (hkey, from_objects) in counted.items():
            # The plan is judged against the metadata's own header when it has one
            # (that is the number the plan generator was given); otherwise the object list.
            expected = h.get(hkey, from_objects)
            if h.get(hkey) is not None and h[hkey] != from_objects:
                F.add("metadata_header_inconsistent", "warning", hkey,
                      f"Metadata header says {hkey}={h[hkey]} but its object list adds up to {from_objects}; "
                      f"the plan can only be as right as the metadata.")
            if label in kv:
                m = re.search(r"-?\d[\d,]*", kv[label])
                shown = int(m.group().replace(",", "")) if m else None
                if shown != expected:
                    F.add("header_count_mismatch", "error", label,
                          f"Plan says '{kv[label]}' for '{label}', metadata has {expected}.")
        for hkey, from_objects in (("total_size_mb", round(sum(t["size_mb"] or 0 for t in tables), 2)),):
            if h.get(hkey) is not None and abs(float(h[hkey]) - from_objects) > 0.5:
                F.add("metadata_header_inconsistent", "warning", hkey,
                      f"Metadata header says {hkey}={h[hkey]} but its tables add up to {from_objects}.")
        if "distinct evaluated schemas" in kv and model["schemas"]:
            plan_s = {s.strip().lower() for s in kv["distinct evaluated schemas"].split(",") if s.strip()}
            real_s = {s.lower() for s in model["schemas"]}
            if plan_s != real_s:
                F.add("header_count_mismatch", "error", "schemas",
                      f"Plan lists schemas {sorted(plan_s)}, metadata has {sorted(real_s)}.")
        for label, field in (("total sizing footprint", "total_size_mb"), ("cumulative row count", "total_row_count")):
            if label in kv and h.get(field) is not None:
                m = re.search(r"-?\d[\d,]*\.?\d*", kv[label])
                if m and abs(float(m.group().replace(",", "")) - float(h[field])) > 0.01:
                    F.add("header_count_mismatch", "error", label, f"Plan says '{kv[label]}', metadata has {h[field]}.")

    # ---- Dependencies -------------------------------------------------------
    meta_edges = {(t["name"].lower(), d.lower()) for t in tables for d in t["dependencies"]}
    if dep_t:
        c0, c1 = _col(dep_t, "object name"), _col(dep_t, "depends on")
        ccol = _col(dep_t, "connection")
        plan_edges = set()
        for r in dep_t["rows"]:
            if r[c1].lower() == "none":
                continue
            child, parent = _bare(r[c0]).lower(), _bare(r[c1]).lower()
            plan_edges.add((child, parent))
            if (child, parent) not in meta_edges and child in by_name and parent in by_name:
                F.add("dependency_invented", "error", f"{r[c0]} -> {r[c1]}",
                      f"Plan says '{r[c0]}' depends on '{r[c1]}', but the metadata has no such dependency.")
            if ccol is not None and r[ccol].lower() != "none" and child in by_name:
                cols = {c.lower() for rec in by_name[child] for c in rec["columns"]}
                if r[ccol].lower() not in cols:
                    F.add("unknown_column", "error", f"{r[c0]}.{r[ccol]}",
                          f"Connection column '{r[ccol]}' on '{r[c0]}' (Dependency Mapping) does not exist in the metadata.")
        for child, parent in sorted(meta_edges - plan_edges):
            F.add("dependency_missing", "error", f"{child} -> {parent}",
                  f"Metadata says '{child}' depends on '{parent}', but the Dependency Mapping table omits it.")

    # cycles in the metadata graph (Tarjan-free: iterative DFS on small graph)
    graph = defaultdict(set)
    for child, parent in meta_edges:
        graph[child].add(parent)
    cycles = _find_cycles(graph)
    plan_says_none = any(b["text"].lower().startswith("none detected") and "circular" in b["group"].lower()
                         for b in layout["bullets"])
    for cyc in cycles:
        pretty = " -> ".join(cyc + [cyc[0]])
        if plan_says_none:
            F.add("circular_dependency_missed", "error", pretty,
                  f"Metadata contains a circular dependency ({pretty}) but the plan's 'Circular Dependencies' says none detected.")
        else:
            F.add("circular_dependency_present", "info", pretty, f"Circular dependency in metadata: {pretty}.")

    # ---- Execution order ----------------------------------------------------
    if exec_t:
        co, cn = _col(exec_t, "execution order"), _col(exec_t, "object name")
        order = {}
        for r in exec_t["rows"]:
            try:
                order.setdefault(_bare(r[cn]).lower(), int(r[co]))
            except ValueError:
                F.add("execution_order_violation", "warning", r[cn], f"Execution order '{r[co]}' for '{r[cn]}' is not a number.")
        for child, parent in sorted(meta_edges):
            if child in order and parent in order and order[child] <= order[parent]:
                F.add("execution_order_violation", "error", f"{child} after {parent}",
                      f"'{child}' (step {order[child]}) must come after the table it depends on, "
                      f"'{parent}' (step {order[parent]}).")

    # ---- Batch placement and counts ----------------------------------------
    dependent = {t["name"].lower() for t in tables if t["dependencies"]} | {p for _, p in meta_edges}
    has_deps = {t["name"].lower() for t in tables if t["dependencies"]}
    for label, g in batches.items():
        if g["kind"] != "table":
            continue
        for n in g["names"]:
            nl = n.lower()
            if nl not in by_name:
                continue
            if g["independent"] and nl in has_deps:
                F.add("batch_misplaced", "error", n, f"'{n}' has dependencies but is in '{label}'.")
            if not g["independent"] and nl not in has_deps:
                F.add("batch_misplaced", "warning", n, f"'{n}' has no dependencies but is in '{label}'.")

    if batch_t:
        cs, cb = _col(batch_t, "scope"), _col(batch_t, "batch name")
        real_counts = {
            "table_independent": sum(1 for t in tables if not t["dependencies"]),
            "table_dependent": sum(1 for t in tables if t["dependencies"]),
            "view": len(views), "procedure": len(procs), "function": len(funcs),
        }
        for r in batch_t["rows"]:
            m = re.match(r"\s*(\d+)\s+(.*)", r[cs])
            bm = re.match(r"batch\s+(\d+)", r[cb], re.I)
            if not (m and bm):
                continue
            shown, desc, n = int(m.group(1)), m.group(2).lower(), int(bm.group(1))
            real = (real_counts["table_independent"] if "independent" in desc
                    else real_counts["table_dependent"] if "highly" in desc
                    else 0 if "medium" in desc and False
                    else real_counts["view"] if "view" in desc
                    else real_counts["procedure"] if "procedure" in desc
                    else real_counts["function"] if "function" in desc else None)
            if real is not None and shown != real:
                F.add("batch_count_mismatch", "error", r[cb], f"{r[cb]} says {shown} ({m.group(2)}), metadata has {real}.")
            listed = [g for g in batches.values() if g["batch"] == n]
            if listed:
                got = sum(len(g["names"]) for g in listed)          # raw count; duplicates flagged separately
                if got != shown and "volume" not in desc:
                    F.add("batch_count_mismatch", "warning", r[cb],
                          f"{r[cb]} says {shown} but its bullet list has {got} entries.")

    # ---- Size category consistency (threshold-free) ------------------------
    if size_t:
        c, cz = _col(size_t, "table"), _col(size_t, "size")
        rank = {"small": 0, "medium": 1, "large": 2}
        # Thresholds are unknown, so only flag when NO sensible ordering explains the
        # labels: a bigger-category table must not be smaller than a lower-category
        # one by MB, and (separately) by row count. Flagged only if both orderings break.
        by_mb, by_rows = defaultdict(list), defaultdict(list)
        for r in size_t["rows"]:
            recs = by_name.get(_bare(r[c]).lower())
            cat = r[cz].lower()
            if recs and cat in rank:
                if recs[0]["size_mb"] is not None:
                    by_mb[cat].append((recs[0]["size_mb"], r[c]))
                rc = recs[0].get("row_count")
                if rc is not None:
                    by_rows[cat].append((rc, r[c]))
        for lo, hi in (("small", "medium"), ("medium", "large"), ("small", "large")):
            if not (by_mb[lo] and by_mb[hi]):
                continue
            mb_bad = max(by_mb[lo])[0] > min(by_mb[hi])[0]
            rows_bad = bool(by_rows[lo] and by_rows[hi]) and max(by_rows[lo])[0] > min(by_rows[hi])[0]
            if mb_bad and (rows_bad or not (by_rows[lo] and by_rows[hi])):
                a, b = max(by_mb[lo]), min(by_mb[hi])
                F.add("size_category_inconsistent", "warning", a[1],
                      f"Size categories overlap: '{a[1]}' ({a[0]} MB) is '{lo}' but '{b[1]}' ({b[0]} MB) is '{hi}'.")

    return _summarise(F.items)


def _find_cycles(graph: dict) -> list:
    """Returns one representative cycle per strongly-connected component of size > 1
    (or self-loop), as a list of names."""
    index, low, on, stack, idx, comps = {}, {}, set(), [], [0], []

    def strong(v):
        index[v] = low[v] = idx[0]; idx[0] += 1
        stack.append(v); on.add(v)
        for w in graph.get(v, ()):
            if w not in index:
                strong(w); low[v] = min(low[v], low[w])
            elif w in on:
                low[v] = min(low[v], index[w])
        if low[v] == index[v]:
            comp = []
            while True:
                w = stack.pop(); on.discard(w); comp.append(w)
                if w == v:
                    break
            if len(comp) > 1 or v in graph.get(v, ()):
                comps.append(sorted(comp))

    for v in list(graph):
        if v not in index:
            strong(v)
    return comps


def _summarise(findings: list) -> dict:
    by_check = defaultdict(lambda: {"error": 0, "warning": 0, "info": 0})
    for f in findings:
        by_check[f["check"]][f["severity"]] += 1
    errors = sum(1 for f in findings if f["severity"] == "error")
    warnings = sum(1 for f in findings if f["severity"] == "warning")
    return {
        "findings": findings,
        "summary": {k: v for k, v in sorted(by_check.items())},
        "error_count": errors,
        "warning_count": warnings,
        "passed": errors == 0,
    }


def format_plan_checks(result: dict, title: str = "Migration Plan Checks") -> str:
    L = [f"=== {title} ===",
         f"Errors: {result['error_count']}   Warnings: {result['warning_count']}   "
         f"Result: {'PASS' if result['passed'] else 'FAIL'}"]
    for sev, head in (("error", "ERRORS"), ("warning", "WARNINGS"), ("info", "INFO")):
        items = [f for f in result["findings"] if f["severity"] == sev]
        if not items:
            continue
        L += ["", f"{head} ({len(items)}):"]
        grouped = defaultdict(list)
        for f in items:
            grouped[f["check"]].append(f)
        for check, fs in grouped.items():
            L.append(f"  [{check}] x{len(fs)}")
            for f in fs[:8]:
                L.append(f"    - {f['message']}")
            if len(fs) > 8:
                L.append(f"    ... and {len(fs) - 8} more")
    return "\n".join(L)
