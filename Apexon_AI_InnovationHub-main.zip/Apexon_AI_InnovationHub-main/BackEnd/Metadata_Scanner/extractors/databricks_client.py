import json
import os
import re
import time
from pathlib import Path

import databricks.sql as databricks_sql
import requests
from config import Credentials
from Metadata_Scanner.extractors.base_extractor import BaseExtractor
from Metadata_Scanner.extractors.declared_keys import attach_declared_keys

# Demo toggle for showing both Harness Layer 1 governance outcomes back to
# back: True makes the next scan execute a real (harmless, "WHERE 1=0")
# DELETE probe against one table before extraction finishes, which lands in
# Unity Catalog's system.query.history and trips the negative-case
# (DESTRUCTIVE_SQL_DETECTED) path - the scan then gets stopped by the gate
# in Migrator/views.py. False leaves the scan fully read-only for the
# positive-case (full scan completes) demo. Flip this one line between the
# two demo runs - Django's dev-server autoreloader picks up the change on
# save, no restart needed.
#
# NOTE ON ORDER: the probe's DELETE is a real statement, so once it runs it
# stays in system.query.history for 30 days (see _fetch_destructive_statements
# below) and will keep failing every subsequent scan of that same catalog
# regardless of this flag. Demo the positive case FIRST, then flip this to
# True for the negative case - not the other way around.
DEMO_FORCE_DESTRUCTIVE_STATEMENT = False

# Capping a scan to a small, representative sample of objects (rather than
# the whole catalog) is handled one layer up, in Migrator/views.py's
# _limit_metadata_tables() - it runs on every source type's extract()
# output, not just Databricks, and is the single place that decides how
# many tables/views/procedures/volumes a scan keeps. This extractor always
# returns everything it finds.


def _log_object_fetch(object_label, catalog, count):
    """
    Logs how many of a given object type were found, on both stdout and the
    app's "Scan Info" log panel. Worth logging even on success (count == 0
    included): a query that runs with no exception but returns zero rows -
    e.g. because the object was created in a different catalog than the one
    configured for this scan, or this principal lacks a grant on it - looks
    identical to "there really are none" unless the catalog and count are
    both spelled out explicitly.
    """
    message = f"[INFO] Found {count} {object_label}(s) in catalog '{catalog}'."
    print(message)
    try:
        from Logs import Logs
        Logs["Scan Info"].append(message)
    except Exception:
        pass


def _log_object_fetch_warning(message):
    full_message = f"[WARNING] {message}"
    print(full_message)
    try:
        from Logs import Logs
        Logs["Scan Info"].append(full_message)
    except Exception:
        pass


class DatabricksExtractor(BaseExtractor):
    """
    Databricks SQL warehouses authenticate with a personal access token
    (not username/password) and need an HTTP path identifying the specific
    warehouse/cluster to run queries against.

    This targets Unity Catalog's ANSI-standard information_schema, which is
    the modern, reliable way to enumerate tables/columns. If the workspace
    doesn't have Unity Catalog enabled, this will only see the legacy
    'hive_metastore' catalog's system schema, not user tables - Unity
    Catalog should be enabled for this to be useful.

    Field mapping:
      Creds.get_servername()  -> server_hostname, e.g. "dbc-xxxx.cloud.databricks.com"
      Creds.get_password()    -> the personal access token (used as the auth secret)
      Creds.get_database_name() -> the Unity Catalog catalog name, e.g. "main"
      Creds.get_extra("http_path") -> required, e.g. "/sql/1.0/warehouses/abc123def456"

    Install: pip install databricks-sql-connector
    """

    def __init__(self, Creds):
        self.server_hostname = (Creds.get_servername() or "").strip().strip('"').strip("'")
        self.server_hostname = re.sub(r"^https?://", "", self.server_hostname).rstrip("/")
        self.catalog = (Creds.get_database_name() or "").strip().strip('"').strip("'")
        self.access_token = (Creds.get_password() or "").strip().strip('"').strip("'")
        self.http_path = (Creds.get_extra("http_path") or "").strip().strip('"').strip("'")
        if self.http_path and not self.http_path.startswith("/"):
            self.http_path = "/" + self.http_path
        self.connection = None

    def _log_scan_info(self, message):
        print(message)
        try:
            from Logs import Logs
            Logs["Scan Info"].append(message)
        except Exception:
            pass

    def _ensure_warehouse_running(self, poll_timeout_seconds=300, poll_interval_seconds=5):
        """
        Databricks SQL warehouses auto-suspend after a period of inactivity;
        the first connection after that triggers a cold start that can take
        anywhere from ~30 seconds (serverless) to several minutes (classic/
        pro warehouses provisioning cluster nodes). databricks_sql.connect()
        below has no timeout of its own by default (databricks-sql-
        connector's _socket_timeout defaults to None, i.e. wait forever), so
        without this a stopped warehouse just makes the scan sit there with
        no explanation - indistinguishable from a genuine hang.

        This checks the warehouse's state via the Databricks REST API first
        and, if it isn't already running, explicitly starts it and polls
        (logging progress to Scan Info the whole time) until it reports
        RUNNING or poll_timeout_seconds elapses - so a slow scan now reads as
        "warehouse is starting up" instead of looking broken.

        Best-effort: any failure here (token lacks CAN_MANAGE on the
        warehouse, workspace policy blocks the REST call, http_path doesn't
        look like a warehouse path, etc.) is logged as a warning and
        swallowed - falls through to the normal connect() call below, which
        still works fine against an already-running warehouse and is
        Databricks' own cold-start path for everything else.
        """
        match = re.search(r"/warehouses/([A-Za-z0-9]+)", self.http_path or "")
        if not match:
            return
        warehouse_id = match.group(1)
        base_url = f"https://{self.server_hostname}/api/2.0/sql/warehouses/{warehouse_id}"
        headers = {"Authorization": f"Bearer {self.access_token}"}

        try:
            resp = requests.get(base_url, headers=headers, timeout=15)
            resp.raise_for_status()
            state = resp.json().get("state")
        except Exception as e:
            self._log_scan_info(f"[WARNING] Could not check SQL warehouse state (continuing anyway): {e}")
            return

        if state == "RUNNING":
            return

        self._log_scan_info(
            f"[INFO] SQL warehouse is currently '{state}' - requesting start. "
            "A stopped warehouse can take 1-5 minutes to become available; this is normal Databricks cold-start behavior, not a hang."
        )

        try:
            requests.post(f"{base_url}/start", headers=headers, timeout=15)
        except Exception as e:
            self._log_scan_info(f"[WARNING] Could not request SQL warehouse start (continuing anyway): {e}")
            return

        deadline = time.time() + poll_timeout_seconds
        last_logged_state = state
        while time.time() < deadline:
            time.sleep(poll_interval_seconds)
            try:
                resp = requests.get(base_url, headers=headers, timeout=15)
                resp.raise_for_status()
                state = resp.json().get("state")
            except Exception:
                continue
            if state != last_logged_state:
                self._log_scan_info(f"[INFO] SQL warehouse state: {state}...")
                last_logged_state = state
            if state == "RUNNING":
                return

        self._log_scan_info(
            f"[WARNING] SQL warehouse did not report RUNNING within {poll_timeout_seconds}s "
            f"(last state: {state}) - attempting to connect anyway."
        )

    def connect(self):

        token_len = len(self.access_token) if self.access_token else 0
        token_prefix = self.access_token[:6] if token_len >= 6 else (self.access_token or "EMPTY")
        print(
            "[INFO] Databricks connection details:\n"
            f"    Server hostname : {self.server_hostname or '(not set)'}\n"
            f"    Catalog         : {self.catalog or '(not set)'}\n"
            f"    HTTP path       : {self.http_path or '(not set)'}\n"
            f"    Access token    : {token_len} characters, starts with '{token_prefix}'"
        )

        if not self.server_hostname:
            raise ValueError("Server hostname is empty.")
        if not self.catalog:
            raise ValueError("Catalog (database) name is empty.")
        if not self.access_token:
            raise ValueError("Access token (password field) is empty.")
        if not self.http_path:
            raise ValueError("HTTP path is empty (extra['http_path']).")

        try:
            from Logs import Logs
            Logs["Scan Info"].append(f"[INFO] Access token verified ({token_len} characters, starts with '{token_prefix}').")
        except Exception:
            pass

        self._ensure_warehouse_running()

        self.connection = databricks_sql.connect(
            server_hostname=self.server_hostname,
            http_path=self.http_path,
            access_token=self.access_token,
            catalog=self.catalog,
        )

    def close(self):
        if self.connection:
            self.connection.close()

    def _fetch_destructive_statements(self, table_keys):
        """
        Query Unity Catalog's system.query.history for recent DELETE/TRUNCATE
        statements and match them back to the scanned tables, so Harness
        Layer 1's GovernanceValidator.DESTRUCTIVE_SQL_DETECTED rule
        (HarnessLayers/layer1/Layer.py) - which reads each table's
        "recent_statements" - actually has something to see on a real scan
        instead of that field always coming back empty.

        Returns {(schema_name, table_name): [statement_text, ...]}. Returns
        {} if system.query.history isn't reachable (Unity Catalog system
        schema not enabled, or the token lacks SELECT on it) so a missing
        audit log degrades to "nothing flagged" rather than failing the scan.
        """
        statements_by_table: dict[tuple[str, str], list[str]] = {}
        try:
            cursor = self.connection.cursor()
            # statement_type IN (...) is the fast path, but Databricks' docs
            # don't publish a guaranteed enum (they only give examples like
            # ALTER/COPY/INSERT) - so also match on the statement text itself
            # as a fallback in case TRUNCATE isn't classified the way we
            # expect. Belt-and-suspenders beats a silent false negative on a
            # destructive-statement check.
            cursor.execute("""
                SELECT statement_text
                FROM system.query.history
                WHERE (
                    statement_type IN ('DELETE', 'TRUNCATE')
                    OR upper(trim(statement_text)) LIKE 'DELETE %'
                    OR upper(trim(statement_text)) LIKE 'TRUNCATE %'
                )
                AND start_time >= current_timestamp() - INTERVAL 30 DAYS
                ORDER BY start_time DESC
                LIMIT 1000
            """)
            rows = cursor.fetchall()
        except Exception as e:
            warning = f"[WARNING] Could not read system.query.history for destructive-statement check: {e}"
            print(warning)
            try:
                from Logs import Logs
                Logs["Scan Info"].append(warning)
            except Exception:
                pass
            return statements_by_table

        for row in rows:
            statement_text = row[0]
            if not statement_text:
                continue
            for schema_name, table_name in table_keys:
                table_pattern = re.compile(
                    rf"(?:^|[`.\s]){re.escape(table_name)}(?:[`\s;.]|$)", re.IGNORECASE
                )
                if not table_pattern.search(statement_text):
                    continue
                # Require the schema to also appear in the statement so a
                # bare table name shared across schemas doesn't cross-match.
                if schema_name and not re.search(rf"\b{re.escape(schema_name)}\b", statement_text, re.IGNORECASE):
                    continue
                statements_by_table.setdefault((schema_name, table_name), []).append(statement_text)

        return statements_by_table

    # ------------------------------------------------------------------
    # NEGATIVE-CASE DEMO (gated by DEMO_FORCE_DESTRUCTIVE_STATEMENT above)
    # ------------------------------------------------------------------
    # This helper simulates a real destructive SQL event for the governance
    # test path by executing a live (no-op, "WHERE 1=0") DELETE against a
    # Databricks table. Only runs when DEMO_FORCE_DESTRUCTIVE_STATEMENT is
    # True; leave that False for a normal, fully read-only scan.
    # ------------------------------------------------------------------
    def _execute_destructive_statement_probe(self, tables):
        """
        Demo-only negative case. This intentionally executes a DELETE against a
        real table to prove the governance layer reacts to destructive SQL.
        Only called when DEMO_FORCE_DESTRUCTIVE_STATEMENT is True.
        """
        target = next(
            (t for t in tables if (t.get("table_type") or "").upper() != "VIEW"),
            None,
        )
        if not target:
            return {}

        schema_name = target["table_schema"]
        table_name = target["table_name"]
        statement = f"DELETE FROM {self.catalog}.{schema_name}.{table_name} WHERE 1=0"

        try:
            probe_cursor = self.connection.cursor()
            probe_cursor.execute(statement)
        except Exception as e:
            warning = f"[WARNING] Destructive-statement probe DELETE failed (likely missing MODIFY permission): {e}"
            print(warning)
            try:
                from Logs import Logs
                Logs["Scan Info"].append(warning)
            except Exception:
                pass
            return {}

        try:
            from Logs import Logs
            Logs["Scan Info"].append(
                f"[INFO]: Destructive-statement probe executed against {schema_name}.{table_name} for negative-case demo"
            )
        except Exception:
            pass

        return {(schema_name, table_name): [statement]}

    def _fetch_procedures(self):
        """
        Query Unity Catalog's information_schema.routines for stored
        procedures (routine_type = 'PROCEDURE'), so Harness Layer 1's
        PROCEDURES_DETECTED check (HarnessLayers/layer1/Layer.py) has
        something to see on a real scan. SQL procedures are a newer Unity
        Catalog feature and not every workspace/runtime supports them, so
        this degrades to "none found" rather than failing the scan if the
        query errors out.

        Returns {schema_name: [{"name": procedure_name}, ...]}.
        """
        procedures_by_schema: dict[str, list[dict]] = {}
        try:
            cursor = self.connection.cursor()
            cursor.execute(f"""
                SELECT routine_schema, routine_name
                FROM {self.catalog}.information_schema.routines
                WHERE routine_type = 'PROCEDURE'
                ORDER BY routine_schema, routine_name
            """)
            for schema_name, routine_name in cursor.fetchall():
                procedures_by_schema.setdefault(schema_name, []).append({"name": routine_name})
            _log_object_fetch("stored procedure", self.catalog, sum(len(v) for v in procedures_by_schema.values()))
        except Exception as e:
            _log_object_fetch_warning(f"Could not list stored procedures in catalog '{self.catalog}': {e}")
        return procedures_by_schema

    def _fetch_view_definitions(self):
        """
        Query Unity Catalog's information_schema.views for the SQL text
        behind each view, so views carry their actual definition instead of
        just their column list. Degrades to "no definitions captured" if the
        workspace/token can't reach information_schema.views, rather than
        failing the scan.

        Returns {(schema_name, view_name): definition_sql}.
        """
        definitions: dict[tuple[str, str], str] = {}
        try:
            cursor = self.connection.cursor()
            cursor.execute(f"""
                SELECT table_schema, table_name, view_definition
                FROM {self.catalog}.information_schema.views
            """)
            for schema_name, view_name, view_definition in cursor.fetchall():
                definitions[(schema_name, view_name)] = view_definition
            _log_object_fetch("view definition", self.catalog, len(definitions))
        except Exception as e:
            _log_object_fetch_warning(f"Could not read view definitions in catalog '{self.catalog}': {e}")
        return definitions

    def _fetch_functions(self):
        """
        Query Unity Catalog's information_schema.routines for user-defined
        functions (routine_type = 'FUNCTION'), the sibling of
        _fetch_procedures() for PROCEDUREs. Degrades to "none found" if the
        query errors out rather than failing the scan.

        Returns {schema_name: [{"name": function_name, "return_type": ...}, ...]}.
        """
        functions_by_schema: dict[str, list[dict]] = {}
        try:
            cursor = self.connection.cursor()
            cursor.execute(f"""
                SELECT routine_schema, routine_name, data_type
                FROM {self.catalog}.information_schema.routines
                WHERE routine_type = 'FUNCTION'
                ORDER BY routine_schema, routine_name
            """)
            for schema_name, routine_name, return_type in cursor.fetchall():
                functions_by_schema.setdefault(schema_name, []).append({
                    "name": routine_name,
                    "return_type": return_type,
                })
            _log_object_fetch("function", self.catalog, sum(len(v) for v in functions_by_schema.values()))
        except Exception as e:
            _log_object_fetch_warning(f"Could not list functions in catalog '{self.catalog}': {e}")
        return functions_by_schema

    def _fetch_volumes(self):
        """
        Query Unity Catalog's information_schema.volumes for managed/external
        volumes (object-storage-backed file mounts, distinct from tables).
        Only populated on workspaces with Unity Catalog volumes enabled, so
        this degrades to "none found" rather than failing the scan if the
        system table isn't reachable.

        Returns {schema_name: [{"name": ..., "volume_type": ..., "storage_location": ...}, ...]}.
        """
        volumes_by_schema: dict[str, list[dict]] = {}
        try:
            cursor = self.connection.cursor()
            cursor.execute(f"""
                SELECT volume_schema, volume_name, volume_type, storage_location
                FROM {self.catalog}.information_schema.volumes
                ORDER BY volume_schema, volume_name
            """)
            for schema_name, volume_name, volume_type, storage_location in cursor.fetchall():
                volumes_by_schema.setdefault(schema_name, []).append({
                    "name": volume_name,
                    "volume_type": volume_type,
                    "storage_location": storage_location,
                })
            _log_object_fetch("volume", self.catalog, sum(len(v) for v in volumes_by_schema.values()))
        except Exception as e:
            _log_object_fetch_warning(f"Could not list volumes in catalog '{self.catalog}': {e}")
        return volumes_by_schema

    def _fetch_declared_keys(self, schema_map):
        """
        Unity Catalog's informational PRIMARY KEY / FOREIGN KEY constraints
        (not enforced, but declared for modelling) from information_schema,
        attached per table by declared_keys.attach_declared_keys(). A foreign
        key's columns pair up with the referenced key's columns through
        position_in_unique_constraint.
        """
        info = f"{self.catalog}.information_schema"
        try:
            cursor = self.connection.cursor()
            cursor.execute(f"""
                SELECT kcu.table_schema, kcu.table_name, kcu.column_name, kcu.ordinal_position
                FROM {info}.table_constraints tc
                JOIN {info}.key_column_usage kcu
                  ON kcu.constraint_catalog = tc.constraint_catalog
                 AND kcu.constraint_schema = tc.constraint_schema
                 AND kcu.constraint_name = tc.constraint_name
                WHERE tc.constraint_type = 'PRIMARY KEY'
            """)
            pk_rows = [tuple(r) for r in cursor.fetchall()]
            cursor.execute(f"""
                SELECT rc.constraint_name, fk.table_schema, fk.table_name, fk.column_name,
                       pk.table_schema, pk.table_name, pk.column_name, fk.ordinal_position
                FROM {info}.referential_constraints rc
                JOIN {info}.key_column_usage fk
                  ON fk.constraint_catalog = rc.constraint_catalog
                 AND fk.constraint_schema = rc.constraint_schema
                 AND fk.constraint_name = rc.constraint_name
                JOIN {info}.key_column_usage pk
                  ON pk.constraint_catalog = rc.unique_constraint_catalog
                 AND pk.constraint_schema = rc.unique_constraint_schema
                 AND pk.constraint_name = rc.unique_constraint_name
                 AND pk.ordinal_position = fk.position_in_unique_constraint
            """)
            fk_rows = [tuple(r) for r in cursor.fetchall()]
            pk_tables, fk_count = attach_declared_keys(schema_map, pk_rows, fk_rows)
            self._log_scan_info(
                f"[INFO] Declared keys in catalog '{self.catalog}': "
                f"{pk_tables} table(s) with a primary key, {fk_count} foreign key(s)."
            )
        except Exception as e:
            _log_object_fetch_warning(f"Could not read declared keys in catalog '{self.catalog}': {e}")

    def extract(self, output_file="data/metadata.json"):

        self.connect()

        metadata = {
            "database": self.catalog,
            "schemas": []
        }

        cursor = self.connection.cursor()

        cursor.execute(f"""
            SELECT
                table_schema,
                table_name,
                table_type
            FROM {self.catalog}.information_schema.tables
            WHERE table_schema != 'information_schema'
            ORDER BY table_schema, table_name
        """)

        columns_desc = [d[0] for d in cursor.description]
        tables = [dict(zip(columns_desc, row)) for row in cursor.fetchall()]
        base_table_count = sum(1 for t in tables if (t.get("table_type") or "").upper() != "VIEW")
        view_count = len(tables) - base_table_count
        _log_object_fetch("base table", self.catalog, base_table_count)
        _log_object_fetch("view", self.catalog, view_count)

        view_definitions = self._fetch_view_definitions()
        procedures_by_schema = self._fetch_procedures()
        functions_by_schema = self._fetch_functions()
        volumes_by_schema = self._fetch_volumes()

        # NEGATIVE-CASE DEMO: see DEMO_FORCE_DESTRUCTIVE_STATEMENT at the top of
        # this file - flip that one line to switch between the positive-case
        # (full scan) and negative-case (governance stop) demo scenarios.
        #
        # Both destructive-statement sources are gated behind the same flag:
        # _fetch_destructive_statements() reads REAL Unity Catalog query
        # history, which is a persistent audit log - once the demo probe (or
        # any real DELETE/TRUNCATE) has run against this catalog, it stays in
        # that history for 30 days and would keep failing every scan
        # regardless of this flag if the real fetch ran unconditionally. So
        # when the flag is False, skip the real history check entirely and
        # guarantee a clean, fully read-only positive-case run; when True,
        # check real history AND inject the synthetic probe statement.
        destructive_statements = {}
        if DEMO_FORCE_DESTRUCTIVE_STATEMENT:
            destructive_statements = self._fetch_destructive_statements(
                [(table["table_schema"], table["table_name"]) for table in tables]
            )
            for key, statements in self._execute_destructive_statement_probe(tables).items():
                destructive_statements.setdefault(key, []).extend(statements)

        schema_map = {}

        for table in tables:

            schema_name = table["table_schema"]
            table_name = table["table_name"]

            if schema_name not in schema_map:
                schema_map[schema_name] = {
                    "name": schema_name,
                    "tables": [],
                    "procedures": [],
                    "functions": [],
                    "volumes": [],
                }

            table_object = {
                "name": table_name,
                "type": table["table_type"],
                "columns": [],
                "recent_statements": destructive_statements.get((schema_name, table_name), []),
            }
            if (table["table_type"] or "").upper() == "VIEW":
                table_object["definition"] = view_definitions.get((schema_name, table_name))

            column_cursor = self.connection.cursor()
            column_cursor.execute(f"""
                SELECT
                    column_name,
                    data_type,
                    character_maximum_length,
                    numeric_precision,
                    numeric_scale,
                    is_nullable
                FROM {self.catalog}.information_schema.columns
                WHERE table_schema = %(schema_name)s AND table_name = %(table_name)s
                ORDER BY ordinal_position
            """, {"schema_name": schema_name, "table_name": table_name})

            col_desc = [d[0] for d in column_cursor.description]
            for row in column_cursor.fetchall():
                column = dict(zip(col_desc, row))
                table_object["columns"].append({
                    "name": column["column_name"],
                    "datatype": column["data_type"],
                    "max_length": column["character_maximum_length"],
                    "precision": column["numeric_precision"],
                    "scale": column["numeric_scale"],
                    "nullable": column["is_nullable"],
                })

            # Row count for this table.
            count_cursor = self.connection.cursor()
            try:
                count_cursor.execute(
                    f"SELECT COUNT(*) FROM `{self.catalog}`.`{schema_name}`.`{table_name}`"
                )
                row_count_result = count_cursor.fetchone()
                table_object["row_count"] = row_count_result[0] if row_count_result else 0
            except Exception as e:
                print(f"[WARNING] Could not get row count for {schema_name}.{table_name}: {e}")
                table_object["row_count"] = 0

            # Table size in MB for Databricks table
            try:
                detail_cursor = self.connection.cursor()
                detail_cursor.execute(
                    f"DESCRIBE DETAIL `{self.catalog}`.`{schema_name}`.`{table_name}`"
                )
                detail_row = detail_cursor.fetchone()
                if detail_row:
                    col_names = [d[0].lower() for d in detail_cursor.description]
                    detail_dict = dict(zip(col_names, detail_row))
                    size_bytes = detail_dict.get("sizeinbytes")
                    if size_bytes is not None and int(size_bytes) > 0:
                        table_object["size_mb"] = round(int(size_bytes) / (1024.0 * 1024.0), 2)
                    else:
                        r_cnt = table_object.get("row_count") or 0
                        c_cnt = len(table_object.get("columns", []))
                        table_object["size_mb"] = round(max(0.06, (64 + (r_cnt * max(c_cnt * 35, 64)) / 1024.0) / 1024.0), 2)
                else:
                    r_cnt = table_object.get("row_count") or 0
                    c_cnt = len(table_object.get("columns", []))
                    table_object["size_mb"] = round(max(0.06, (64 + (r_cnt * max(c_cnt * 35, 64)) / 1024.0) / 1024.0), 2)
            except Exception:
                r_cnt = table_object.get("row_count") or 0
                c_cnt = len(table_object.get("columns", []))
                table_object["size_mb"] = round(max(0.06, (64 + (r_cnt * max(c_cnt * 35, 64)) / 1024.0) / 1024.0), 2)

            schema_map[schema_name]["tables"].append(table_object)

        def _ensure_schema(schema_name):
            if schema_name not in schema_map:
                schema_map[schema_name] = {
                    "name": schema_name,
                    "tables": [],
                    "procedures": [],
                    "functions": [],
                    "volumes": [],
                }
            return schema_map[schema_name]

        for schema_name, procedures in procedures_by_schema.items():
            _ensure_schema(schema_name)["procedures"] = procedures

        for schema_name, functions in functions_by_schema.items():
            _ensure_schema(schema_name)["functions"] = functions

        for schema_name, volumes in volumes_by_schema.items():
            _ensure_schema(schema_name)["volumes"] = volumes

        self._fetch_declared_keys(schema_map)

        metadata["schemas"] = list(schema_map.values())

        Path(output_file).parent.mkdir(parents=True, exist_ok=True)
        with open(output_file, "w", encoding="utf-8") as fp:
            json.dump(metadata, fp, indent=4)

        self.close()
        return metadata

if __name__ == "__main__":
    cred = Credentials()
    cred.set_server_hostname(os.environ["DATABRICKS_SERVER_HOSTNAME"])
    cred.set_database_name(os.environ["DATABRICKS_CATALOG"])
    cred.set_password(os.environ["DATABRICKS_ACCESS_TOKEN"])
    cred.set_extra("http_path", os.environ["DATABRICKS_HTTP_PATH"])
    
    obj = DatabricksExtractor(cred)
    obj.connect()
    obj.extract()
    obj.close()