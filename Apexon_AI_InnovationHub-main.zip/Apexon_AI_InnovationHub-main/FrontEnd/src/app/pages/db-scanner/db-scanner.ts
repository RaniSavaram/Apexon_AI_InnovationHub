import { Component, inject, ChangeDetectorRef, ViewChild, ElementRef, AfterViewChecked, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { Scanner, SavedConnectionProfile, ConnectionDetails } from '../../services/scanner/scanner';
import { ErDiagram } from '../../components/er-diagram/er-diagram';

@Component({
  selector: 'app-db-scanner',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ErDiagram
  ],
  templateUrl: './db-scanner.html',
  styleUrl: './db-scanner.css'
})

export class DbScannerComponent implements OnInit, AfterViewChecked, OnDestroy {

  @ViewChild('terminalBody') private terminalBody!: ElementRef;
  @ViewChild('fabricTerminalBody') private fabricTerminalBody?: ElementRef;

  fabricLiveLogs: string[] = [];
  private fabricLogInterval: any = null;

  //=========================================================
  // SERVICE
  //=========================================================

  private scanner = inject(Scanner);

  private cdr = inject(ChangeDetectorRef);

  private sanitizer = inject(DomSanitizer);

  private route = inject(ActivatedRoute);

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const sourceParam = params['source'];
      const connectParam = params['connect'];

      if (sourceParam) {
        this.source = sourceParam;
        this.sourceChanged();
        this.showConnection = true;
      } else if (connectParam === '1' || connectParam === 'true') {
        if (!this.source) {
          this.source = 'sqlserver';
        }
        this.sourceChanged();
        this.showConnection = true;
      }
    });
  }

  //=========================================================
  // DROPDOWNS
  //=========================================================

  source = '';

  destination = 'Fabric';

  //=========================================================
  // PAGE STATUS
  //=========================================================

  loading = false;

  connected = false;

  scanCompleted = false;
  scanFailed = false;

  showConnection = false;

  connecting = false;

  showLogsDialog = false;
  showArtifactsDialog = false;
  generatingFabric = false;
  artifactsTab: 'overview' | 'tables' | 'logs' = 'overview';
  fabricArtifactsResult: any = null;

  activeTab: 'logs' | 'harness1' | 'harness2' | 'er' | 'output' = 'logs';

  lastScanSource = '';

  showScanCompletedDialog = false;

  showScanFailedDialog = false;

  scanFailedMessage = '';

  showConnectionSuccessDialog = false;

  connectionSuccessMessage = '';

  backendCompleted = false;

  backendResponse: any;

  scanInterval: any;
  scanStatusTimeout: any;
  private pollErrorCount = 0;

  metadataFile = '/output/Assesment%20Report.docx';

  migrationFile = '/output/AI_Migration_Plan.docx';

  metadataReportDownloadName = 'Metadata Report.docx';

  migrationPlanDownloadName = 'Migration Plan.docx';

  /** Fabric metadata JSON of the completed scan - the ER Diagrams tab is built from it. */
  erMetadataFile?: string;

  get safeMetadataUrl() {
    return this.sanitizer.bypassSecurityTrustUrl(this.metadataFile);
  }

  get safeMigrationUrl() {
    return this.sanitizer.bypassSecurityTrustUrl(this.migrationFile);
  }

  viewDocument(url: string) {
    window.open(`${url}${url.includes('?') ? '&' : '?'}view=1`, '_blank', 'noopener');
  }

  getFormatSourceForFilename(source: string): string {
    if (!source) return 'Database';
    const s = source.toLowerCase();
    if (s === 'sqlserver' || s === 'sql server') return 'SQL Server';
    if (s === 'databricks') return 'Databricks';
    if (s === 'synapse') return 'Azure Synapse';
    if (s === 'snowflake') return 'Snowflake';
    if (s === 'dynamics365' || s === 'dynamics 365' || s === 'd365') return 'Dynamics 365';
    if (s === 'sqlite') return 'SQLite';
    if (s === 'oracle') return 'Oracle';
    if (s === 'mysql') return 'MySQL';
    if (s === 'postgres' || s === 'postgresql') return 'PostgreSQL';
    if (s === 'sap') return 'SAP';
    return source.charAt(0).toUpperCase() + source.slice(1);
  }


  //=========================================================
  // SCAN STATUS
  //=========================================================

  progress = 0;
  displayProgress = 0;
  targetProgress = 0;
  private progressAnimationId: any = null;

  scanStatus = 'Select a database to begin';

  //=========================================================
  // STATUS MESSAGES
  //=========================================================

  statusMessages: string[] = [

    'Select a database to begin'

  ];

  //=========================================================
  // HARNESS LAYER 1 & 2
  //=========================================================

  harness1Messages: string[] = [

    'Harness Layer 1 information will appear here.'

  ];

  harness2Messages: string[] = [

    'Harness Layer 2 information will appear here.'

  ];

  harness1Feedback = '';

  //=========================================================
  // TOKEN INFORMATION
  //=========================================================

  tokenInfo = {

    total: 0,

    prompt: 0,

    completion: 0,

    cost: '-'

  };

  //=========================================================
  // CONNECTION DETAILS
  //=========================================================

  connection: ConnectionDetails = {

    server: '',

    database: '',

    username: '',

    password: '',

    httpPath: '',

    tenantId: '',

    clientId: '',

    clientSecret: '',

    account: '',

    warehouse: '',

    role: '',

    token: ''

  };

  // Dynamics 365 only: 'secret' = app registration (client-credentials
  // flow), 'password' = the user's own sign-in (resource-owner-password
  // flow) - the latter needs no client secret, for free/developer accounts
  // that don't have an app registration set up.
  dynamicsAuthMode: 'secret' | 'password' = 'secret';

  // Snowflake only: 'token' = Programmatic Access Token, PAT (no username or
  // password needed - Snowflake identifies the session from the token
  // itself), 'password' = classic username + password login.
  snowflakeAuthMode: 'token' | 'password' = 'token';

  rememberMe = false;

  savedConnectionOptions: SavedConnectionProfile[] = [];

  selectedSavedConnection = '__new__';

  private readonly REMEMBERED_CONNECTION_KEY = 'dbscanner.rememberedConnections';

  //=========================================================
  // DATABRICKS: SAVED-CONNECTION DROPDOWNS
  //=========================================================

  // 'select' shows Server/Catalog/Token/HTTP Path as dropdowns built from
  // saved profiles; 'new' falls back to plain editable inputs (used when
  // there's nothing saved yet, or the user picks "+ Add new connection").
  databricksMode: 'select' | 'new' = 'new';

  databricksConnections: SavedConnectionProfile[] = [];

  databricksServerOptions: string[] = [];

  databricksCatalogOptions: string[] = [];

  databricksHttpPathOptions: string[] = [];

  databricksTokenOptions: { value: string; label: string }[] = [];

  readonly NEW_DATABRICKS_CONNECTION = '__new__';

  //=========================================================
  // CONNECTION PAYLOAD
  //=========================================================

  connectionPayload: any = {};

  //=========================================================
  // OUTPUT FILES
  //=========================================================

  fabricReport =
    'https://app.fabric.microsoft.com/groups/bae3b540-d044-45e0-8c52-3cf4ee3dcb31/reports/1538985c-066f-425d-83bd-2530d449d259/1810ae00cc79e99923aa?experience=fabric-developer';

  // These files are generated by the backend under
  // BackEnd/AI_Agent_Pipeline/output and exposed through the Django output
  // route.

  //=========================================================
  // SOURCE CHANGED
  //=========================================================

  private getRememberedConnectionKey(source: string): string {
    return `${this.REMEMBERED_CONNECTION_KEY}.${(source || '').trim()}`;
  }

  getSavedProfileKey(profile: SavedConnectionProfile): string {
    return [
      profile.server ?? '',
      profile.database ?? '',
      profile.username ?? '',
      profile.password ?? '',
      profile.extra?.http_path ?? '',
      profile.extra?.tenant_id ?? '',
      profile.extra?.client_id ?? '',
      profile.extra?.client_secret ?? '',
      profile.extra?.account ?? '',
      profile.extra?.warehouse ?? '',
      profile.extra?.role ?? '',
      profile.extra?.token ?? '',
    ].join('|');
  }

  private readSavedProfiles(): SavedConnectionProfile[] {
    if (!this.source) {
      return [];
    }

    try {
      const key = this.getRememberedConnectionKey(this.source);
      const raw = localStorage.getItem(key);
      if (!raw) {
        return [];
      }

      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed as SavedConnectionProfile[];
      }
      if (parsed && Array.isArray(parsed.profiles)) {
        return parsed.profiles as SavedConnectionProfile[];
      }
      if (parsed && parsed.connection) {
        return [parsed.connection as SavedConnectionProfile];
      }
      return [];
    } catch {
      return [];
    }
  }

  private loadRememberedConnection() {
    this.savedConnectionOptions = this.readSavedProfiles();
    this.selectedSavedConnection = '__new__';
    this.rememberMe = this.savedConnectionOptions.length > 0;

    this.connection = {
      server: '',
      database: '',
      username: '',
      password: '',
      httpPath: '',
      tenantId: '',
      clientId: '',
      clientSecret: '',
      account: '',
      warehouse: '',
      role: '',
      token: '',
    };
  }

  private saveRememberedConnection() {
    if (!this.source) {
      return;
    }

    const key = this.getRememberedConnectionKey(this.source);
    const extra: { http_path?: string; tenant_id?: string; client_id?: string; client_secret?: string; account?: string; warehouse?: string; role?: string; token?: string } = {};
    if (this.connection.httpPath) extra.http_path = this.connection.httpPath;
    if (this.connection.tenantId) extra.tenant_id = this.connection.tenantId;
    if (this.connection.clientId) extra.client_id = this.connection.clientId;
    if (this.connection.clientSecret) extra.client_secret = this.connection.clientSecret;
    if (this.connection.account) extra.account = this.connection.account;
    if (this.connection.warehouse) extra.warehouse = this.connection.warehouse;
    if (this.connection.role) extra.role = this.connection.role;
    if (this.connection.token) extra.token = this.connection.token;

    const profile: SavedConnectionProfile = {
      server: this.connection.server,
      database: this.connection.database,
      username: this.connection.username,
      password: this.connection.password,
      extra,
    };

    if (!this.rememberMe) {
      localStorage.removeItem(key);
      this.savedConnectionOptions = [];
      this.selectedSavedConnection = '__new__';
      return;
    }

    const existing = this.readSavedProfiles();
    const next = existing.filter(
      item => this.getSavedProfileKey(item) !== this.getSavedProfileKey(profile)
    );
    next.push(profile);
    this.savedConnectionOptions = next;
    localStorage.setItem(key, JSON.stringify(next));
  }

  onSavedConnectionChange() {
    if (this.selectedSavedConnection === '__new__') {
      this.connection = {
        server: '',
        database: '',
        username: '',
        password: '',
        httpPath: '',
        tenantId: '',
        clientId: '',
        clientSecret: '',
        account: '',
        warehouse: '',
        role: '',
        token: '',
      };
      return;
    }

    const profile = this.savedConnectionOptions.find(
      item => this.getSavedProfileKey(item) === this.selectedSavedConnection
    );

    if (!profile) {
      return;
    }

    this.connection = {
      server: profile.server ?? '',
      database: profile.database ?? '',
      username: profile.username ?? '',
      password: profile.password ?? '',
      httpPath: profile.extra?.http_path ?? '',
      tenantId: profile.extra?.tenant_id ?? '',
      clientId: profile.extra?.client_id ?? '',
      clientSecret: profile.extra?.client_secret ?? '',
      account: profile.extra?.account ?? '',
      warehouse: profile.extra?.warehouse ?? '',
      role: profile.extra?.role ?? '',
      token: profile.extra?.token ?? '',
    };
    if (this.source === 'dynamics365') {
      this.dynamicsAuthMode = profile.extra?.client_secret ? 'secret' : 'password';
    }
    if (this.source === 'Snowflake') {
      this.snowflakeAuthMode = profile.extra?.token ? 'token' : 'password';
    }
  }

  sourceChanged() {

    if (!this.source) {

      return;

    }

    if (this.connected) {

      return;

    }

    this.connection = {

      server: '',

      database: '',

      username: '',

      password: '',

      httpPath: '',

      tenantId: '',

      clientId: '',

      clientSecret: '',

      account: '',

      warehouse: '',

      role: '',

      token: ''

    };

    this.snowflakeAuthMode = 'token';

    this.loadRememberedConnection();

    this.progress = 0;

    this.scanCompleted = false;
    this.scanFailed = false;
    this.fabricArtifactsResult = null;
    this.erMetadataFile = undefined;

    this.showScanCompletedDialog = false;

    const selectedDb = this.getFormatSourceForFilename(this.source);
    this.scanStatus = this.source ? `Waiting to connect to ${selectedDb}` : 'Select a database to begin';

    this.statusMessages = [

      this.scanStatus

    ];

    this.harness1Messages = [

      'Harness Layer 1 information will appear here.'

    ];

    this.harness2Messages = [

      'Harness Layer 2 information will appear here.'

    ];

    this.tokenInfo = {

      total: 0,

      prompt: 0,

      completion: 0,

      cost: '-'

    };

    this.showConnection = true;

    if (this.source === 'Databricks') {
      this.loadDatabricksConnections();
      return;
    }

    this.databricksMode = 'new';
    this.databricksConnections = [];

    if (!this.rememberMe) {
      this.scanner.getSavedConnection(this.source).subscribe({
        next: (response) => {
          if (response.found && response.connection) {
            this.connection = {
              server: response.connection.server ?? '',
              database: response.connection.database ?? '',
              username: response.connection.username ?? '',
              password: response.connection.password ?? '',
              httpPath: response.connection.extra?.http_path ?? '',
              tenantId: response.connection.extra?.tenant_id ?? '',
              clientId: response.connection.extra?.client_id ?? '',
              clientSecret: response.connection.extra?.client_secret ?? '',
              account: response.connection.extra?.account ?? '',
              warehouse: response.connection.extra?.warehouse ?? '',
              role: response.connection.extra?.role ?? '',
              token: response.connection.extra?.token ?? '',
            };
            if (this.source === 'dynamics365') {
              this.dynamicsAuthMode = response.connection.extra?.client_secret ? 'secret' : 'password';
            }
            if (this.source === 'Snowflake') {
              this.snowflakeAuthMode = response.connection.extra?.token ? 'token' : 'password';
            }
            this.cdr.detectChanges();
          }
        },
        error: () => {
          // No saved connection yet, or lookup failed - not fatal, just
          // leave the form blank for manual entry.
        },
      });
    }

  }

  //=========================================================
  // DATABRICKS: LOAD SAVED CONNECTIONS
  //=========================================================

  loadDatabricksConnections() {

    this.scanner.getSavedConnections('Databricks').subscribe({
      next: (response) => {
        this.databricksConnections = response.connections ?? [];

        if (this.databricksConnections.length === 0) {
          this.databricksMode = 'new';
          this.cdr.detectChanges();
          return;
        }

        this.databricksMode = 'select';
        this.buildDatabricksOptions();

        // Default to the most recently saved profile.
        const latest = this.databricksConnections[this.databricksConnections.length - 1];
        this.connection = {
          server: latest.server ?? '',
          database: latest.database ?? '',
          username: latest.username ?? '',
          password: latest.password ?? '',
          httpPath: latest.extra?.http_path ?? '',
        };

        this.cdr.detectChanges();
      },
      error: () => {
        // No saved connections yet, or lookup failed - fall back to a
        // blank, manually-entered connection.
        this.databricksMode = 'new';
        this.databricksConnections = [];
        this.cdr.detectChanges();
      },
    });

  }

  //=========================================================
  // DATABRICKS: BUILD DROPDOWN OPTIONS
  //=========================================================

  buildDatabricksOptions() {

    const uniq = (values: (string | undefined)[]) =>
      Array.from(new Set(values.filter((v): v is string => !!v)));

    this.databricksServerOptions = uniq(this.databricksConnections.map(c => c.server));
    this.databricksCatalogOptions = uniq(this.databricksConnections.map(c => c.database));
    this.databricksHttpPathOptions = uniq(this.databricksConnections.map(c => c.extra?.http_path));

    this.databricksTokenOptions = uniq(this.databricksConnections.map(c => c.password))
      .map(token => ({ value: token, label: this.maskToken(token) }));

  }

  //=========================================================
  // DATABRICKS: MASK TOKEN FOR DROPDOWN DISPLAY
  //=========================================================

  maskToken(token: string): string {

    if (!token) {
      return '';
    }

    if (token.length <= 10) {
      return token;
    }

    return `${token.slice(0, 6)}••••${token.slice(-4)}`;

  }

  //=========================================================
  // DATABRICKS: SERVER DROPDOWN CHANGED
  //=========================================================

  onDatabricksServerChange() {

    if (this.connection.server === this.NEW_DATABRICKS_CONNECTION) {
      this.startNewDatabricksConnection();
      return;
    }

    const match = this.databricksConnections.find(c => c.server === this.connection.server);

    if (match) {
      this.connection.database = match.database ?? '';
      this.connection.password = match.password ?? '';
      this.connection.httpPath = match.extra?.http_path ?? '';
    }

  }

  //=========================================================
  // DATABRICKS: SWITCH TO MANUAL ENTRY
  //=========================================================

  startNewDatabricksConnection() {

    this.databricksMode = 'new';

    this.connection = {
      server: '',
      database: '',
      username: '',
      password: '',
      httpPath: '',
    };

  }

  //=========================================================
  // DATABRICKS: BACK TO SAVED-CONNECTION DROPDOWNS
  //=========================================================

  useSavedDatabricksConnection() {

    if (this.databricksConnections.length === 0) {
      return;
    }

    this.databricksMode = 'select';

    const latest = this.databricksConnections[this.databricksConnections.length - 1];
    this.connection = {
      server: latest.server ?? '',
      database: latest.database ?? '',
      username: latest.username ?? '',
      password: latest.password ?? '',
      httpPath: latest.extra?.http_path ?? '',
    };

  }

  //=========================================================
  // SNOWFLAKE: AUTH MODE CHANGED
  //=========================================================

  onSnowflakeAuthModeChange() {
    // Username stays in both modes - Snowflake validates a PAT against the
    // login name it was issued for, so only the password/token field
    // toggles.
    if (this.snowflakeAuthMode === 'token') {
      this.connection.password = '';
    } else {
      this.connection.token = '';
    }
  }

  //=========================================================
  // CONNECT DATABASE
  //=========================================================

  connectDatabase() {

    const isDatabricks = this.source === 'Databricks';
    const isDynamics365 = this.source === 'dynamics365';
    const isSnowflake = this.source === 'Snowflake';

    // Dynamics 365 has no database field - it authenticates to Dataverse
    // either via an Azure AD app registration (org URL + tenant/client
    // id/secret) or, for free/developer accounts with no app registration,
    // via the user's own username/password (no client secret needed).
    const missingFields = isDynamics365
      ? (
          this.connection.server.trim() === '' ||
          (this.dynamicsAuthMode === 'secret'
            ? (
                (this.connection.tenantId ?? '').trim() === '' ||
                (this.connection.clientId ?? '').trim() === '' ||
                (this.connection.clientSecret ?? '').trim() === ''
              )
            : (
                this.connection.username.trim() === '' ||
                this.connection.password.trim() === ''
              ))
        )
      // Snowflake connects via account identifier + warehouse rather than a
      // host - the "Server" field isn't shown to the user, it's derived
      // from the account identifier below since the backend still requires
      // it to be non-empty. Username is required in both auth modes -
      // Snowflake validates a PAT against the login name it was issued for.
      : isSnowflake
      ? (
          (this.connection.account ?? '').trim() === '' ||
          this.connection.database.trim() === '' ||
          (this.connection.warehouse ?? '').trim() === '' ||
          this.connection.username.trim() === '' ||
          (this.snowflakeAuthMode === 'token'
            ? (this.connection.token ?? '').trim() === ''
            : this.connection.password.trim() === '')
        )
      : (
          this.connection.server.trim() === '' ||
          this.connection.database.trim() === '' ||
          (!isDatabricks && this.connection.username.trim() === '') ||
          this.connection.password.trim() === '' ||
          (isDatabricks && (this.connection.httpPath ?? '').trim() === '')
        );

    if (missingFields) {

      alert('Please fill all mandatory fields.');

      return;

    }

    if (isSnowflake) {
      this.connection.server = this.connection.account ?? '';
    }

    this.connecting = true;

    this.scanner.connectDatabase(
      this.source,
      this.connection,
      this.rememberMe
    ).subscribe({

      next: (response: any) => {

        this.connected = true;

        const connectedDb = this.getFormatSourceForFilename(this.source);
        this.scanStatus = `Connected to ${connectedDb}. Starting scan...`;
        this.statusMessages = [this.scanStatus];

        this.saveRememberedConnection();

        this.showConnection = false;

        this.connecting = false;

        this.showConnectionSuccessDialog = false;

        this.connectionPayload = {

          source: this.source,

          destination: this.destination,

          connection: {

            server: this.connection.server,

            database: this.connection.database,

            username: this.connection.username,

            password: this.connection.password,

            httpPath: this.connection.httpPath

          },

          status: 'Connected',

          connectedTime: new Date()

        };

        this.statusMessages.push(
          'Database Connected Successfully.'
        );

        this.connectionSuccessMessage = response.message ?? 'Connection successful.';
        this.cdr.detectChanges();

        // Immediately start the scan based on the selected source
        this.startScan();

      },

      error: (err) => {

        this.connected = false;

        this.connecting = false;

        this.cdr.detectChanges();

        this.statusMessages.push(
          'Database Connection Failed.'
        );

        console.error(err);

        alert(err.error?.message ?? 'Connection Failed');

      }

    });

  }

  //=========================================================
  // CANCEL CONNECTION
  //=========================================================

  cancelConnection() {

    this.showConnection = false;

    this.connected = false;

    this.source = '';

  }

  //=========================================================
  // START SCAN
  //=========================================================

  startScan() {

    if (!this.connected) {

      if (!this.source) {
        this.source = 'sqlserver';
      }
      this.sourceChanged();
      this.showConnection = true;
      this.cdr.detectChanges();
      return;

    }

    this.lastScanSource = this.source;

    this.loading = true;

    this.scanCompleted = false;
    this.scanFailed = false;
    this.fabricArtifactsResult = null;
    this.erMetadataFile = undefined;

    this.showScanCompletedDialog = false;
    const activeDb = this.getFormatSourceForFilename(this.source);
    this.scanStatus = `Starting ${activeDb} scan`;
    this.statusMessages = [];
    this.statusMessages.push(`Starting ${activeDb} scan`);
    this.backendCompleted = false;
    this.backendResponse = null;
    this.pollErrorCount = 0;

    this.openLogsDialog();

    this.progress = 5;
    this.displayProgress = 5;
    this.targetProgress = 5;
    this.startDynamicProgress();

    if (this.scanInterval) {
      clearInterval(this.scanInterval);
    }

    this.scanner.startScan(
      this.source,
      this.destination,
      this.connection
    ).subscribe({
      next: (response: any) => {
        if (response.scan_id) {
          this.pollScanStatus(response.scan_id);
        }
      },
      error: (err) => {
        this.stopProgressAnimation();
        this.loading = false;
        this.progress = 0;
        this.targetProgress = 0;
        this.scanFailed = true;
        this.scanStatus = 'Scan Failed';
        this.statusMessages.push('Database Scan Failed.');
        console.error(err);
        alert(err.error?.message ?? 'Scan Failed');
        this.cdr.detectChanges();
      }
    });

  }

  private pollScanStatus(scanId: string) {
    this.scanner.getScanStatus(scanId).subscribe({
      next: (status) => {
        this.pollErrorCount = 0;
        this.applyScanLogs(status.Logs);
        
        // Dynamically update target progress milestone from backend scan stage
        if (status.progressbar !== undefined && status.progressbar !== null) {
          if (status.progressbar > this.targetProgress) {
            this.targetProgress = Math.min(98, status.progressbar);
          }
        }
        this.scanStatus = status.scan_status_message || this.scanStatus;

        if (status.status === 'Running') {
          this.scanStatusTimeout = setTimeout(() => this.pollScanStatus(scanId), 1000);
          this.cdr.detectChanges();
          return;
        }

        if (status.status === 'Failed') {
          this.stopDynamicProgress();
          this.loading = false;
          this.progress = 0;
          this.displayProgress = 0;
          this.targetProgress = 0;
          this.scanFailed = true;
          this.scanStatus = 'Scan Failed';
          this.scanFailedMessage = status.error ?? 'Database Scan Failed.';
          this.statusMessages.push(this.scanFailedMessage);
          this.showScanFailedDialog = true;
          this.activeTab = 'logs';
          this.cdr.detectChanges();
          return;
        }

        this.backendCompleted = true;
        this.backendResponse = {
          ...status,
          ...(status.result ?? {}),
          Logs: status.Logs,
        };
        this.targetProgress = 100;
        
        // Fluidly finish when 100% reached
        const finishChecker = setInterval(() => {
          if (this.progress >= 99.2) {
            clearInterval(finishChecker);
            this.progress = 100;
            this.displayProgress = 100;
            this.cdr.detectChanges();
            setTimeout(() => {
              this.stopDynamicProgress();
              this.completeScanProgress();
              this.cdr.detectChanges();
            }, 300);
          }
        }, 40);
      },
      error: () => {
        this.pollErrorCount++;
        if (this.pollErrorCount >= 4) {
          this.stopProgressAnimation();
          this.loading = false;
          this.progress = 0;
          this.targetProgress = 0;
          this.scanFailed = true;
          this.scanStatus = 'Scan session interrupted (server reloaded). Please click Scan to restart.';
          this.statusMessages.push('Scan session interrupted (server reloaded). Please click Scan to restart.');
          this.cdr.detectChanges();
          return;
        }
        this.scanStatusTimeout = setTimeout(() => this.pollScanStatus(scanId), 3000);
      },
    });
  }

  private applyScanLogs(logs: Record<string, any> | undefined) {
    if (!logs) return;
    this.statusMessages = logs['Scan Info'] ?? this.statusMessages;
    this.harness1Messages = logs['Harness Layer1'] ?? this.harness1Messages;
    if (logs['Harness Layer2']?.length) {
      this.harness2Messages = logs['Harness Layer2'];
    }
    const tokenEntries = logs['Token Info'];
    if (tokenEntries?.length) {
      const latest = tokenEntries[tokenEntries.length - 1];
      this.tokenInfo = {
        total: latest.total ?? 0,
        prompt: latest.prompt ?? 0,
        completion: latest.completion ?? 0,
        cost: latest.cost ?? '-',
      };
    }
  }

  //=========================================================
  // COMPLETE SCAN PROGRESS
  //=========================================================

  completeScanProgress() {
    this.stopDynamicProgress();
    this.loading = false;
    this.scanCompleted = true;
    this.progress = 0;
    this.displayProgress = 0;
    this.targetProgress = 0;

    this.source = this.lastScanSource || this.source;

    this.connected = false;

    const completedSource = this.lastScanSource || this.source;
    const formattedSource = this.getFormatSourceForFilename(completedSource);
    const completedMsg = this.backendResponse?.scan_status_message 
      || `${formattedSource} scan completed successfully.`;

    this.scanStatus = completedMsg;

    if (!this.statusMessages.includes(completedMsg)) {
      this.statusMessages.push(completedMsg);
    }

    if (this.backendResponse) {

      this.connectionPayload.scanStatus = 'Completed';

      this.connectionPayload.completedTime = new Date();

      this.connectionPayload.scanResult = this.backendResponse;

      const logs = this.backendResponse.Logs;
      const outputFiles = this.backendResponse.output_files;
      if (outputFiles?.assessment_report) {
        this.metadataFile = `/output/${encodeURIComponent(outputFiles.assessment_report)}?t=${Date.now()}`;
      }
      if (outputFiles?.migration_plan) {
        this.migrationFile = `/output/${encodeURIComponent(outputFiles.migration_plan)}?t=${Date.now()}`;
      }
      this.erMetadataFile = outputFiles?.fabric_migration_metadata;

      const selectedSource = this.lastScanSource || this.source || 'Database';
      const formattedSource = this.getFormatSourceForFilename(selectedSource);
      this.metadataReportDownloadName = `${formattedSource} Assessment Report.docx`;
      this.migrationPlanDownloadName = `${formattedSource} Migration Plan.docx`;

      //----------------------------------------------------
      // Backend Logs
      //----------------------------------------------------

      if (logs) {

        this.statusMessages = logs['Scan Info'] ?? this.statusMessages;

      }

      else {

        this.statusMessages = [

          'Metadata Collection Completed',

          'Schema Validation Completed',

          'Migration Assessment Completed',

          'AI Agents Executed',

          'Output Documents Generated Successfully'

        ];

      }

      //----------------------------------------------------
      // Harness Layer 1
      //----------------------------------------------------

      if (logs && logs['Harness Layer1'] && logs['Harness Layer1'].length > 0) {

        this.harness1Messages = logs['Harness Layer1'];

      }

      else {

        this.harness1Messages = [

          'Bronze Layer Generated',

          'Silver Layer Generated',

          'Gold Layer Generated',

          'Migration Assessment Completed'

        ];

      }

      //----------------------------------------------------
      // Harness Layer 2
      //----------------------------------------------------

      if (logs && logs['Harness Layer2'] && logs['Harness Layer2'].length > 0) {
        this.harness2Messages = logs['Harness Layer2'];
      }

      //----------------------------------------------------
      // Token Usage
      //----------------------------------------------------

      if (logs && logs['Token Info'] && logs['Token Info'].length > 0) {

        const latestTokenEntry = logs['Token Info'][logs['Token Info'].length - 1];

        this.tokenInfo = {

          total: latestTokenEntry.total ?? 0,

          prompt: latestTokenEntry.prompt ?? 0,

          completion: latestTokenEntry.completion ?? 0,

          cost: latestTokenEntry.cost ?? '-'

        };

        for (const entry of logs['Token Info']) {

          this.statusMessages.push(

            `Token Usage — Total: ${entry.total ?? 0}, ` +

            `Prompt: ${entry.prompt ?? 0}, ` +

            `Completion: ${entry.completion ?? 0}, ` +

            `Cost: $${entry.cost ?? '-'}`

          );

        }

      }

    }

    this.showScanCompletedDialog = true;

    this.cdr.detectChanges();

  }

  //=========================================================
  // CLOSE SCAN COMPLETED DIALOG
  //=========================================================

  closeScanCompletedDialog() {

    this.showScanCompletedDialog = false;

  }

  //=========================================================
  // CLOSE / EXPAND SCAN FAILED DIALOG
  //=========================================================

  closeScanFailedDialog() {

    this.showScanFailedDialog = false;

  }

  openLogsDialogFromScanFailed() {

    this.showScanFailedDialog = false;

    this.showLogsDialog = true;

    this.activeTab = 'logs';

    this.cdr.detectChanges();

  }

  closeConnectionSuccessDialog() {
    this.showConnectionSuccessDialog = false;
  }

  //=========================================================
  // OPEN SCAN COMPLETED DIALOG FROM LOGS
  //=========================================================

  openScanCompletedDialogFromLogs() {

    this.showLogsDialog = false;

    this.showScanCompletedDialog = true;

    this.cdr.detectChanges();

  }

  //=========================================================
  // RETRY CONSTRAINT HARNESS LAYER (HARNESS 1) - ACTION REMOVED
  //=========================================================

  retryHarness1() {
    // Action removed per user request
  }

  //=========================================================
  // SUBMIT CONSTRAINT HARNESS LAYER (HARNESS 1) - ACTION REMOVED
  //=========================================================

  submitHarness1() {
    // Action removed per user request
  }

  //=========================================================
  // OPEN LOGS DIALOG
  //=========================================================

  openLogsDialog() {

    this.showLogsDialog = true;

    this.activeTab = 'logs';

  }

  //=========================================================
  // CLOSE LOGS DIALOG
  //=========================================================

  closeLogsDialog() {

    this.showLogsDialog = false;

  }

  //=========================================================
  // GENERATE ARTIFACTS DIALOG & EXECUTION (SQL_2_FABRIC)
  //=========================================================

  isDatabricksSource(): boolean {
    const src = (this.source || this.lastScanSource || '').toLowerCase();
    return src.includes('databricks');
  }

  isDynamics365Source(): boolean {
    const src = (this.source || this.lastScanSource || '').toLowerCase();
    return src.includes('dynamics') || src === 'd365';
  }

  isSnowflakeSource(): boolean {
    const src = (this.source || this.lastScanSource || '').toLowerCase();
    return src.includes('snowflake');
  }

  getActiveSourceDisplayName(): string {
    if (this.isDatabricksSource()) return 'Databricks';
    if (this.isDynamics365Source()) return 'Dynamics 365';
    if (this.isSnowflakeSource()) return 'Snowflake';
    return 'SQL Server';
  }

  getActiveReportDocName(): string {
    if (this.isDatabricksSource()) return 'databricks_Assessment_Report.docx';
    if (this.isDynamics365Source()) return 'dynamics365_Assessment_Report.docx';
    if (this.isSnowflakeSource()) return 'snowflake_Assessment_Report.docx';
    return 'sqlserver_Assessment_Report.docx';
  }

  // Matches fabric_generator_core.py's SOURCE_LAKEHOUSE_MAP - every source
  // has its own pre-provisioned Fabric Lakehouse. Only used before a
  // generation result is back; after that getLakehouseName() shows the
  // real displayName the backend read from Fabric.
  getActiveTargetLakehouse(): string {
    if (this.isDatabricksSource()) return 'Databricks_Lakehouse';
    if (this.isDynamics365Source()) return 'Dynamics365_Lakehouse';
    if (this.isSnowflakeSource()) return 'Snowflake_Lakehouse';
    return 'SQL_Lakehouse';
  }

  // Each source routes through its own thin *2_fabric.py entry point
  // (databricks2_fabric.py / sqlserver2_fabric.py / dynamics3652_fabric.py /
  // snowflake2_fabric.py) - all backed by the same
  // fabric_generator_core.Generator(), only the filename (and therefore
  // which pre-provisioned Lakehouse it resolves) differs. This is the
  // filename expected for the *currently selected* source, independent of
  // whatever a stale cached result says.
  private getExpectedGeneratorScript(): string {
    if (this.isDatabricksSource()) return 'databricks2_fabric.py';
    if (this.isDynamics365Source()) return 'dynamics3652_fabric.py';
    if (this.isSnowflakeSource()) return 'snowflake2_fabric.py';
    return 'sqlserver2_fabric.py';
  }

  getActiveGeneratorScript(): string {
    if (this.fabricArtifactsResult?.generator_script) {
      return this.fabricArtifactsResult.generator_script;
    }
    return this.getExpectedGeneratorScript();
  }

  openArtifactsDialog() {
    if (!this.scanCompleted) {
      alert('Please complete a database scan first.');
      return;
    }
    this.showArtifactsDialog = true;
    const expectedScript = this.getExpectedGeneratorScript();
    const currentScript = this.fabricArtifactsResult?.generator_script;

    if ((!this.fabricArtifactsResult || currentScript !== expectedScript) && !this.generatingFabric) {
      this.generateFabricArtifacts();
    }
    this.cdr.detectChanges();
  }

  closeArtifactsDialog() {
    this.showArtifactsDialog = false;
    if (this.fabricLogInterval) {
      clearInterval(this.fabricLogInterval);
      this.fabricLogInterval = null;
    }
  }

  generateFabricArtifacts() {
    if (!this.scanCompleted) {
      alert('Please complete a database scan first.');
      return;
    }

    if (this.fabricLogInterval) {
      clearInterval(this.fabricLogInterval);
      this.fabricLogInterval = null;
    }

    this.generatingFabric = true;
    const script = this.getActiveGeneratorScript();
    const sourceName = this.getActiveSourceDisplayName();
    const reportDoc = this.getActiveReportDocName();
    const targetLakehouse = this.getActiveTargetLakehouse();

    // Seed with exact initial backend execution header
    this.fabricLiveLogs = [
      `Routing Generate Artifacts to: ${script} for source: ${sourceName}`,
      `[INFO] Target Lakehouse: ${targetLakehouse}`,
      `[INFO] Using assessment report: ${reportDoc}`,
      `[INFO] Target Workspace: bae3b540-d044-45e0-8c52-3cf4ee3dcb31`
    ];
    this.cdr.detectChanges();

    const pendingHeaderLines = [
      `[INFO] Authenticated Identity: Service Principal (ID: 8e82282c-30c4-474c-9925-d233b3f18ed8, Tenant: 61aa10dd-0f65-4088-8028-6766e4da079e)`,
      `[INFO] Target workspace: bae3b540-d044-45e0-8c52-3cf4ee3dcb31`
    ];

    let headerIdx = 0;
    this.fabricLogInterval = setInterval(() => {
      if (headerIdx < pendingHeaderLines.length && this.generatingFabric) {
        this.fabricLiveLogs.push(pendingHeaderLines[headerIdx]);
        headerIdx++;
        this.cdr.detectChanges();
        setTimeout(() => this.scrollFabricLogsToBottom(), 30);
      }
    }, 400);

    const selectedSource = this.source || this.lastScanSource || '';

    this.scanner.generateFabricArtifacts(selectedSource).subscribe({
      next: (res) => {
        if (this.fabricLogInterval) {
          clearInterval(this.fabricLogInterval);
          this.fabricLogInterval = null;
        }

        const serverLogs: string[] = res?.logs || [];

        // If backend returned the full logs, stream them dynamically so user sees every table and sync status
        if (serverLogs.length > 0) {
          // Find where serverLogs continue from what we already displayed
          let startIndex = 0;
          for (let i = 0; i < serverLogs.length; i++) {
            if (serverLogs[i].includes('===') || serverLogs[i].includes('cards.') || serverLogs[i].includes('dbo.')) {
              startIndex = i;
              break;
            }
          }

          if (startIndex === 0 && serverLogs.length > this.fabricLiveLogs.length) {
            startIndex = Math.min(this.fabricLiveLogs.length, serverLogs.length - 1);
          }

          let logCursor = startIndex;
          const logStreamer = setInterval(() => {
            if (logCursor < serverLogs.length) {
              // Push 1-2 lines per tick for dynamic streaming effect
              this.fabricLiveLogs.push(serverLogs[logCursor]);
              logCursor++;
              if (logCursor < serverLogs.length && (serverLogs[logCursor].startsWith('  ') || serverLogs[logCursor].includes('->'))) {
                this.fabricLiveLogs.push(serverLogs[logCursor]);
                logCursor++;
              }
              this.cdr.detectChanges();
              this.scrollFabricLogsToBottom();
            } else {
              clearInterval(logStreamer);
              setTimeout(() => {
                this.generatingFabric = false;
                this.fabricArtifactsResult = res;
                this.cdr.detectChanges();
                setTimeout(() => this.scrollFabricLogsToBottom(), 80);
              }, 400);
            }
          }, 20);
        } else {
          this.generatingFabric = false;
          this.fabricArtifactsResult = res;
          this.cdr.detectChanges();
        }
      },
      error: (err) => {
        if (this.fabricLogInterval) {
          clearInterval(this.fabricLogInterval);
          this.fabricLogInterval = null;
        }
        this.generatingFabric = false;
        const msg = err.error?.message || err.message || 'Failed to deploy Fabric artifacts.';
        this.fabricLiveLogs.push(`[ERROR] ${msg}`);
        this.fabricArtifactsResult = {
          status: 'error',
          message: msg,
          errors: [msg],
          logs: [...this.fabricLiveLogs],
          generator_script: this.getExpectedGeneratorScript()
        };
        this.cdr.detectChanges();
        setTimeout(() => this.scrollFabricLogsToBottom(), 100);
      }
    });
  }

  getArtifactsStatusTitle(): string {
    const status = this.fabricArtifactsResult?.status;
    if (status === 'success') return 'Fabric Artifacts Generated & Synced Successfully';
    if (status === 'warning') return 'Assessment Report Notice';
    if (status === 'partial') return 'Partial Artifacts Deployment';
    return 'Artifacts Deployment Details';
  }

  // Matches fabric_generator_core.py's SOURCE_LAKEHOUSE_MAP - each source
  // has its own pre-provisioned Fabric Lakehouse (same "Fabric Insights"
  // workspace, fixed id per source). Prefers the id from the generation
  // result once one is back.
  getLakehouseUrl(): string {
    const realLakehouseId = this.fabricArtifactsResult?.target?.lakehouse_id;
    const lakehouseId = realLakehouseId && !String(realLakehouseId).startsWith('<')
      ? realLakehouseId
      : this.isDatabricksSource()
      ? 'bc94c085-a651-46a6-96a1-0c1183ef78f9'
      : this.isDynamics365Source()
      ? 'efa4494d-ab51-4902-85cb-6fb074d9201d'
      : this.isSnowflakeSource()
      ? '1fef9fdf-9c8c-47f2-9b08-4fa690a8b754'
      : '87ddccfe-cfa3-47d6-92ab-b638ce379319';
    return `https://app.fabric.microsoft.com/groups/bae3b540-d044-45e0-8c52-3cf4ee3dcb31/lakehouses/${lakehouseId}?experience=fabric-developer`;
  }

  getLakehouseName(): string {
    // The backend reads the Lakehouse's real displayName from Fabric -
    // show exactly that once a generation result is back.
    return this.fabricArtifactsResult?.lakehouse_name || this.getActiveTargetLakehouse();
  }

  getWorkspaceUrl(): string {
    return 'https://app.fabric.microsoft.com/groups/bae3b540-d044-45e0-8c52-3cf4ee3dcb31/list?experience=fabric-developer';
  }

  startDynamicProgress() {
    this.stopDynamicProgress();
    let lastTime = performance.now();

    const frameLoop = (now: number) => {
      if (!this.loading) {
        this.stopDynamicProgress();
        return;
      }

      const delta = Math.min(0.08, (now - lastTime) / 1000);
      lastTime = now;

      if (this.progress < this.targetProgress) {
        // Smoothly and gradually advance towards the backend target milestone
        const dist = this.targetProgress - this.progress;
        // Paced velocity: 2.5% to 8.0% per second - never races ahead
        const speed = Math.max(2.5, Math.min(8.0, dist * 0.9));
        this.progress = Math.min(this.targetProgress, this.progress + speed * delta);
      } else if (this.loading && this.progress < Math.min(98, this.targetProgress + 1.5)) {
        // Very subtle micro-motion (0.15% / sec) while waiting for the next backend log,
        // strictly anchored to the current backend stage so it NEVER rushes ahead to 95%
        this.progress = this.progress + 0.15 * delta;
      }

      // Display updates dynamically in natural multi-percent steps, never 1 by 1 percent
      const rounded = Math.round(this.progress);
      if (Math.abs(rounded - this.displayProgress) >= 2 || rounded >= 99 || (this.targetProgress === 100 && rounded === 100)) {
        this.displayProgress = Math.min(100, rounded);
      }

      this.cdr.detectChanges();
      this.progressAnimationId = requestAnimationFrame(frameLoop);
    };

    this.progressAnimationId = requestAnimationFrame(frameLoop);
  }

  stopDynamicProgress() {
    if (this.progressAnimationId) {
      cancelAnimationFrame(this.progressAnimationId);
      this.progressAnimationId = null;
    }
  }

  startProgressAnimation() {
    this.startDynamicProgress();
  }

  stopProgressAnimation() {
    this.stopDynamicProgress();
  }

  getDisplayProgress(): number {
    return this.displayProgress;
  }

  ngOnDestroy() {
    this.stopDynamicProgress();
    if (this.scanStatusTimeout) {
      clearTimeout(this.scanStatusTimeout);
    }
    if (this.fabricLogInterval) {
      clearInterval(this.fabricLogInterval);
      this.fabricLogInterval = null;
    }
  }

  getLogLineClass(log: string): string {
    if (!log) return 'log-default';
    if (log.includes('[SUCCESS]') || log.includes('successfully') || log.includes('PASSED')) return 'log-success';
    if (log.includes('[ERROR]') || log.includes('[Err]') || log.includes('[FAILED]')) return 'log-error';
    if (log.includes('[WARN]')) return 'log-warn';
    if (log.includes('[INFO]')) return 'log-info';
    return 'log-default';
  }

  scrollFabricLogsToBottom() {
    try {
      if (this.fabricTerminalBody) {
        this.fabricTerminalBody.nativeElement.scrollTop = this.fabricTerminalBody.nativeElement.scrollHeight;
      }
    } catch {
      // Ignore scroll errors
    }
  }

  isTableSynced(t: any): boolean {
    if (!this.fabricArtifactsResult?.tables) return false;
    const key = `${t.schema}.${t.table}`;
    return this.fabricArtifactsResult.tables.some((s: string) => s.startsWith(key));
  }

  // Combines Tables, Volumes, Views and Stored Procedures into one list so
  // the "Synced Tables" tab reflects every artifact type fabric_generator_core.py's
  // Generator() can sink, not just Delta tables.
  getSyncedArtifactsRows(): { category: string; schema: string; name: string; detail: string; synced: boolean }[] {
    const result = this.fabricArtifactsResult;
    const rows: { category: string; schema: string; name: string; detail: string; synced: boolean }[] = [];
    if (!result) return rows;

    const categoryLabel = (kind: string): string => kind === 'Procedure' ? 'Stored Procedure' : (kind || 'Object');

    for (const t of result.tables_info || []) {
      rows.push({
        category: 'Table',
        schema: t.schema,
        name: t.table,
        detail: `${t.columns_count} columns`,
        synced: this.isTableSynced(t)
      });
    }

    for (const v of result.volumes?.created || []) {
      const [schema, name] = String(v).split('/');
      rows.push({ category: 'Volume', schema: schema || '', name: name || v, detail: 'OneLake Files/ folder', synced: true });
    }
    for (const e of result.volumes?.errors || []) {
      const [schema, name] = String(e.volume || '').split('.');
      rows.push({ category: 'Volume', schema: schema || '', name: name || e.volume || 'unknown', detail: e.error || 'Sync failed', synced: false });
    }

    for (const c of result.warehouse?.created || []) {
      const [kind, qualified] = String(c).split(' ');
      const [schema, name] = (qualified || '').split('.');
      rows.push({
        category: categoryLabel(kind),
        schema: schema || '',
        name: name || qualified || '',
        detail: `Placeholder in Warehouse '${result.warehouse?.name || ''}'`,
        synced: true
      });
    }
    for (const e of result.warehouse?.errors || []) {
      const objStr = e.object || '';
      if (!objStr) {
        // No object name means the Warehouse connection itself failed
        // before reaching any specific View/Procedure - not a real synced
        // artifact, and it has no Category/Name of its own to show. It's
        // already surfaced in the Sync Notice(s) box above the table, so
        // skip adding a misleading row here.
        continue;
      }
      const [kind, qualified] = objStr.split(' ');
      const [schema, name] = (qualified || '').split('.');
      rows.push({
        category: categoryLabel(kind),
        schema: schema || '',
        name: name || objStr || 'unknown',
        detail: e.error || 'Sync failed',
        synced: false
      });
    }

    // The Lakehouse itself - the OneLake container every Table/Volume row
    // above actually lands in (see resolve_artifact_lakehouse() in
    // fabric_generator_core.py).
    if (result.lakehouse_name) {
      rows.push({
        category: 'Lakehouse',
        schema: '',
        name: result.lakehouse_name,
        detail: `Fabric Lakehouse in workspace '${result.target?.workspace_id || 'unknown'}' hosting the synced tables & volumes above`,
        synced: true
      });
    }

    // The shared Fabric Warehouse itself (FIXED_WAREHOUSE_CONNECTION_STRING
    // in fabric_generator_core.py) - distinct from the per-View/Procedure
    // placeholder rows above, which live inside it.
    if (result.warehouse?.name) {
      const wh = result.warehouse;
      const hasFailure = !!(wh.errors && wh.errors.length) && !(wh.created && wh.created.length);
      rows.push({
        category: 'Warehouse',
        schema: '',
        name: wh.name,
        detail: `Fabric Warehouse backing the placeholder Views/Stored Procedures for Lakehouse '${result.lakehouse_name || 'unknown'}'`,
        synced: !hasFailure
      });
    }

    // The Fabric Data Pipeline scaffolded to mirror the plan's execution
    // order (see fabric_pipeline_builder.py) - one Copy activity per table
    // synced above, source connections left to configure in Fabric Studio.
    if (result.pipeline) {
      const p = result.pipeline;
      rows.push({
        category: 'Pipeline',
        schema: '',
        name: p.name,
        detail: p.error
          ? p.error
          : `${p.activities} Copy activit${p.activities === 1 ? 'y' : 'ies'} scaffolded for Lakehouse '${result.lakehouse_name || 'unknown'}' (source connections still need configuring)`,
        synced: !p.error
      });
    }

    return rows;
  }

  //=========================================================
  // UPDATE PROGRESS
  //=========================================================

  updateProgress(

    percent: number,

    status: string

  ) {

    this.progress = percent;

    this.scanStatus = status;

    this.statusMessages.push(status);

  }

  //=========================================================
  // DOWNLOAD METADATA REPORT
  //=========================================================

  downloadMetadata() {

    window.open(this.metadataFile, '_blank');

  }

  //=========================================================
  // DOWNLOAD MIGRATION REPORT
  //=========================================================

  downloadMigration() {

    window.open(this.migrationFile, '_blank');

  }

  //=========================================================
  // VIEW OUTPUT
  //=========================================================

  viewOutput() {

    this.activeTab = 'output';

  }

  //=========================================================
  // VIEW ANALYSIS
  //=========================================================

  viewAnalysis() {

    window.open(

      this.fabricReport,

      '_blank'

    );

  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  private scrollToBottom() {
    try {
      if (this.terminalBody) {
        this.terminalBody.nativeElement.scrollTop = this.terminalBody.nativeElement.scrollHeight;
      }
    } catch (err) {}
  }

}  
