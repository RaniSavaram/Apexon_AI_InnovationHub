import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class Auth {
  // Not wired to any backend endpoint yet - placeholder for future auth work.
}
