import {
  createFlowDiagram,
  styles_default
} from "./chunk-E4W7WABZ.js";
import "./chunk-BOLQXGRK.js";
import "./chunk-PRC2ZWTU.js";
import "./chunk-NGFV6AY7.js";
import "./chunk-BGJSXCS7.js";
import "./chunk-LBJPG67E.js";
import "./chunk-SQQQTI7S.js";
import "./chunk-YPEZKEDE.js";
import "./chunk-UPQV7CKI.js";
import "./chunk-NQHWUMDZ.js";
import "./chunk-D6CNMITU.js";
import "./chunk-QV6KZPOZ.js";
import "./chunk-MMN5CWGT.js";
import "./chunk-2K55ANF6.js";
import "./chunk-QFSQWCKN.js";
import "./chunk-WYBVO62Q.js";
import "./chunk-7LIFYXBP.js";
import "./chunk-XCV4XYNT.js";
import "./chunk-NE4NAECH.js";
import {
  __name
} from "./chunk-GVZPJYKG.js";
import "./chunk-46DXP6YY.js";

// node_modules/mermaid/dist/chunks/mermaid.core/swimlanesDiagram-VR7AAH4N.mjs
var getStyles = __name((options) => `${styles_default(options)}
  .swimlane.cluster rect {
    stroke: ${options.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`, "getStyles");
var styles_default2 = getStyles;
var diagram = createFlowDiagram({ defaultLayout: "swimlane", styles: styles_default2 });
export {
  diagram
};
//# sourceMappingURL=swimlanesDiagram-VR7AAH4N-BV5KVG3S.js.map
