import {
  parse
} from "./chunk-MKBM2T4P.js";
import "./chunk-GMMV2ZZA.js";
import "./chunk-T7B4VNZC.js";
import "./chunk-BB5T6UFF.js";
import "./chunk-L7X5JTYQ.js";
import "./chunk-YYPCLYET.js";
import "./chunk-PJA5OMJY.js";
import "./chunk-MC5OVXGH.js";
import "./chunk-BZPVYYC6.js";
import "./chunk-MWAKMYYM.js";
import "./chunk-J77FHDU3.js";
import "./chunk-665BUJ6V.js";
import "./chunk-MH6GTLG7.js";
import "./chunk-DFFRANZH.js";
import "./chunk-DAVIFLGC.js";
import "./chunk-PWDGWINW.js";
import "./chunk-ATF6HM7W.js";
import {
  selectSvgElement
} from "./chunk-NNZAFW7G.js";
import {
  configureSvgSize
} from "./chunk-XCV4XYNT.js";
import {
  log
} from "./chunk-NE4NAECH.js";
import {
  __name
} from "./chunk-GVZPJYKG.js";
import "./chunk-46DXP6YY.js";

// node_modules/mermaid/dist/chunks/mermaid.core/infoDiagram-27XIBGKW.mjs
var parser = {
  parse: __name(async (input) => {
    const ast = await parse("info", input);
    log.debug(ast);
  }, "parse")
};
var DEFAULT_INFO_DB = {
  version: "11.17.2" + (true ? "" : "-tiny")
};
var getVersion = __name(() => DEFAULT_INFO_DB.version, "getVersion");
var db = {
  getVersion
};
var draw = __name((text, id, version) => {
  log.debug("rendering info diagram\n" + text);
  const svg = selectSvgElement(id);
  configureSvgSize(svg, 100, 400, true);
  const group = svg.append("g");
  group.append("text").attr("x", 100).attr("y", 40).attr("class", "version").attr("font-size", 32).style("text-anchor", "middle").text(`v${version}`);
}, "draw");
var renderer = { draw };
var diagram = {
  parser,
  db,
  renderer
};
export {
  diagram
};
//# sourceMappingURL=infoDiagram-27XIBGKW-CPGB6LVA.js.map
