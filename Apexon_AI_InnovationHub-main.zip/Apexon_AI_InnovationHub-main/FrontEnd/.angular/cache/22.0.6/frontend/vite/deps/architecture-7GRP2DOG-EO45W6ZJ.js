import {
  ArchitectureModule,
  createArchitectureServices
} from "./chunk-MH6GTLG7.js";
import "./chunk-ATF6HM7W.js";
import "./chunk-46DXP6YY.js";
export {
  ArchitectureModule,
  createArchitectureServices
};
