import {
  StateDB,
  stateDiagram_default,
  stateRenderer_v3_unified_default,
  styles_default
} from "./chunk-EKBK6RZP.js";
import "./chunk-PRC2ZWTU.js";
import "./chunk-NGFV6AY7.js";
import "./chunk-BGJSXCS7.js";
import "./chunk-SQQQTI7S.js";
import "./chunk-YPEZKEDE.js";
import "./chunk-UPQV7CKI.js";
import "./chunk-NQHWUMDZ.js";
import "./chunk-D6CNMITU.js";
import "./chunk-QV6KZPOZ.js";
import "./chunk-MMN5CWGT.js";
import "./chunk-2K55ANF6.js";
import "./chunk-QFSQWCKN.js";
import "./chunk-WYBVO62Q.js";
import "./chunk-7LIFYXBP.js";
import "./chunk-XCV4XYNT.js";
import "./chunk-NE4NAECH.js";
import {
  __name
} from "./chunk-GVZPJYKG.js";
import "./chunk-46DXP6YY.js";

// node_modules/mermaid/dist/chunks/mermaid.core/stateDiagram-v2-MP3YSRHH.mjs
var diagram = {
  parser: stateDiagram_default,
  get db() {
    return new StateDB(2);
  },
  renderer: stateRenderer_v3_unified_default,
  styles: styles_default,
  init: __name((cnf) => {
    if (!cnf.state) {
      cnf.state = {};
    }
    cnf.state.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};
export {
  diagram
};
//# sourceMappingURL=stateDiagram-v2-MP3YSRHH-ULI4YANO.js.map
