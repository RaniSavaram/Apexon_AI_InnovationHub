import {
  __name
} from "./chunk-GVZPJYKG.js";

// node_modules/mermaid/dist/chunks/mermaid.core/chunk-5VM5RSS4.mjs
var getIconStyles = __name(() => `
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`, "getIconStyles");

export {
  getIconStyles
};
//# sourceMappingURL=chunk-BOLQXGRK.js.map
